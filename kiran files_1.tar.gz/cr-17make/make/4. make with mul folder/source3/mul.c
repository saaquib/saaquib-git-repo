#include "header.h"

int mul (int num1, int num2) {
        return (num1 * num2);
}
