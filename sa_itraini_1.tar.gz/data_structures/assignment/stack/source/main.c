#include<header.h>

void main()

{	
	char num[MAX];
	int option;

	printf("Select operation\n");
	printf("1.PUSH\t 2.POP\t 3.Display All Elements\t 4.Exit\n");
	fgets(num,MAX,stdin);
	rem_enter(num);
	option = isvalid(num);
	
	switch (option)
	{
		case 1 :printf("Your option is PUSH\n");
			push();
			printf("Element at the top = %d\n\n",stack[top - 1]);
			main();
			break;

		case 2 :printf("Your option is POP\n");
			pop();
			main();
			break;
	
		case 3 :printf("Your option is Display\n");
			display();
			main();
			break;

	 	case 4 :printf("Your option is EXIT\n");
			exit (0);

		default :printf("Wrong option\n");
			 exit (0);
	}
}
