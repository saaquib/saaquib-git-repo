#include<header.h>

void display()
{
	int i = 0;

	if(top - 1 < 0)
	{
		printf("Stack is Empty\n\n");
	}
	else
	{
		for(i = top - 1; i >= 0; i--)
		{
			printf("Value of stack[%d] = %d \n",i,stack[i]);		
		}
	}
}
