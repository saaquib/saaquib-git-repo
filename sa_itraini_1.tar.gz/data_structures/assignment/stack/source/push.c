#include<header.h>

void push()
{
	char num2[MAX];
	int element;

	if(top == LIMIT)
	{
		printf("Stack is Full\n\n");	
	}
	else
	{	
		printf("Enter the value to PUSH : ");
		fgets(num2,MAX,stdin); 
		rem_enter(num2);
		element = isvalid(num2);

		stack[top] = element;
		top++;
	}
}
	


