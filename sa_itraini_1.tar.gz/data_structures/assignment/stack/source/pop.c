#include<header.h>

void pop()
{
	if((top - 1) < 0 )
		printf("Stack is empty \n\n");
	else
		printf("Element poped = %d \n\n",stack[top - 1]);
		top--;
} 
