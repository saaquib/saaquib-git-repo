#include"stdio.h"
#include"stdlib.h"

#define ONE 1
#define MAX 32

struct node 
{
	int data;
	struct node *next;
};

struct node *head;

void display(void);

int str_len ( char * );

void rem_enter(char *);

int isvalid( char * );

/* Insert operations */

void insert(void);

void insert_end(void);

void insert_beg(void);

void insert_pos(void);

/*n Delete operations */

void delete_node();

void delete_end(void);

void delete_beg(void);

void delete_pos(void);










