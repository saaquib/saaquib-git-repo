#include"header.h"

void delete_beg() {

	struct node *temp = (struct node *)malloc(sizeof(struct node));

	temp = head;
	if(NULL == head) {
		printf("List is already Empty \n");
		return;
	}
	
	head = head->next;
	free(temp);

}
	
