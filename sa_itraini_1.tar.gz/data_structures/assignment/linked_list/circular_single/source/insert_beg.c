#include"header.h"

void insert_beg()
{
	char num[MAX];
	struct node *new = NULL;
	struct node *temp = NULL;

	new = (struct node *) malloc(sizeof(struct node ));

	printf("Enter value in new node : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	new->data = isvalid(num);

	if(NULL == head) {

		head = new;
		new->next = new;      
		return;
	}	
	else {	
		new->next = head;
		head = new;	
		temp = head;

		while(temp->next != head)
			temp = temp->next;
	
		temp->next = new;	
	}
}
	
