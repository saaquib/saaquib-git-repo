#include"header.h"

void delete_at_pos() {

	char num[MAX];
	int pos;
	struct node *temp = NULL;
	struct node *temp2 = NULL;

	printf("Enter position : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	pos = isvalid(num);

	temp = (struct node *) malloc(sizeof(struct node *));
	temp = head;
	
	if(pos == 1) {       
		
		head = temp->next;
        	free(temp);                                          
		return;                                                             
	}                                                                           
	
	else {
                                                                   
		while((--pos) != 1 ) {
                                                                       
			temp = temp->next; 
			                                                
		}
		temp2 = temp->next;
		temp->next = (temp->next)->next;
		free(temp2);
		                                                     
	}
}
