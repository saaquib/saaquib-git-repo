#include"header.h"

void insert_end()
{
	char num[MAX];
	struct node *new = NULL;
	struct node *temp = NULL;

	new = (struct node *) malloc(sizeof(struct node *));

	printf("Enter value in new node : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	new->data = isvalid(num);
	new->next = NULL;
	
	if(head == NULL)                                                           
	{                                                                           
		head = new;
		new->next = head;                                                              
	}                                                                           
	
	else                                                                        
	{                                                                           
		temp = head;                                                            
		
		while( temp->next != NULL )                                             
		{                                                                       
			temp = temp->next;                                                  
		} 

		temp->next = new;
		new->next = head;
		                                                     
	}                                                                           
			                                                                                
}

