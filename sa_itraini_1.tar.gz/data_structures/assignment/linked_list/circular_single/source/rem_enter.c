#include"header.h"

void rem_enter(char *str)
{
	str [ str_len( str ) - 1 ] = '\0';
}
