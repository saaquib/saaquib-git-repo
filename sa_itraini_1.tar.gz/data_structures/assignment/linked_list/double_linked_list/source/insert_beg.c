#include"header.h"

void insert_beg()
{
	char num[MAX];
	struct node *new = NULL;

	new = (struct node *) malloc(sizeof(struct node *));
	
	new->prev = NULL;
	new->next = head;
	head = new;

	printf("Enter value in new node : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	new->data = isvalid(num);
	count++;

}
	
