#include"header.h"

void insert_pos()
{
	char num[MAX];
	int pos;
	char num2[MAX];
	struct node *new = NULL;
	struct node *temp = NULL;


	printf("Enter position : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	pos = isvalid(num);

	if( ((count + 1) < pos) || (pos <= 0))                                      
    {                                                                           
        printf("Can't insert , position dosen't exist");                        
        return;                                                                 
    } 

	new = (struct node *) malloc(sizeof(struct node *));

	printf("Enter value in new node : ");
	fgets(num2,MAX,stdin);
	rem_enter(num2);
	new->data = isvalid(num2);

	if(pos == 1)                                                           
	{       
		new->next = head;
		new->prev = NULL;                                                          
		head = new;
		count++; 
		return;                                                            
	}                                                                           
	
	else                                                                        
	{   
		temp = head;                                                            
		
		while((--pos) != 1 )                                             
		{                                                                       
			temp = temp->next; 
			                                                
		}
		new->prev = temp; 
		new->next = temp->next;
		temp->next = new;
		count++;
	}
}
