#include"header.h"

void display(struct node * temp3)
{
		if( temp3 == NULL )                                             
			return;
    
		display(temp3->next);  
		printf("%d\t",temp3->data);
      
	 
}                                                             
