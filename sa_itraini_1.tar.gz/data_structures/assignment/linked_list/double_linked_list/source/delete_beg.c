#include"header.h"

void delete_beg() {

	struct node *temp = NULL;
	temp = head;

	if(NULL == head) {
		printf("List is already Empty \n");
		return;
	}
	
	head = head->next;
	head->prev = NULL;
	free(temp);

}
	
