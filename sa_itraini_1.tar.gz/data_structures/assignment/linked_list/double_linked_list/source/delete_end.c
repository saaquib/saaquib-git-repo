#include"header.h"

void delete_end() {

	struct node *temp = NULL;
	struct node *temp2 = NULL;
	temp = head;
	
	if(head == NULL) {       
		printf("List is already Empty \n");
		return;                                                         
	}                                                                        
	
	else if(NULL == head->next) {

		head = NULL;
		free(temp);
		count--;
		return;
	}

	else {                                                                                                                   
		
		while( (temp->next)->next != NULL )                                             
		{                                                                       
			temp = temp->next;                                                  
		} 
		count--;
		temp2 = temp->next;
		temp->next = NULL;
		free(temp2);
		                                                     
	}                                                                           
			                                                                                
}

