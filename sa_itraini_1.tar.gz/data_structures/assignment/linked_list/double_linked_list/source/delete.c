#include"header.h"

void delete_node()
{
	char num[MAX];                                                              
	int option;  

	printf("Select your option in Insertion\n\
			1. Delete at the beginning\n\
			2. Delete at the end\n\
			3. Delete at a given position\n\
			4. Delete middle\n\
			5.Exit\n\n");
	
	fgets(num,MAX,stdin);                                                       
	rem_enter(num);                                                             
	option = isvalid(num);

	switch(option)                                                              
		    {                                                                           
				case 1 : delete_beg();                                                                                                  
						 break;                                                        

				case 2 : delete_end();                                                                                                    
						 break;                               

				case 3 : delete_at_pos();                                                                 
						 break;                                                        
				case 4 : delete_middle();
						 break;
				case 5 : printf("Terminating\n");                                     
						  exit(ONE);                                                       
				
				default : printf("Wrong option Select again");                          
						  insert();																												
			} 

}
