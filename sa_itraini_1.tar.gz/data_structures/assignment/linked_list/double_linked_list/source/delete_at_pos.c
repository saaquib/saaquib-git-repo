#include"header.h"

void delete_at_pos() {

	char num[MAX];
	int pos;
	struct node *temp = NULL;
	struct node *temp2 = NULL;

	printf("Enter position : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	pos = isvalid(num);

	temp = head;
	
	if(pos == 1) {       
		
		head = temp->next;
		head->prev = NULL;
        free(temp);
		count--;                                          
		return;                                                             
	}                                                                           
	
	else {
                                                                   
		while((--pos) != 0 ) {
                                                                       
			temp = temp->next; 
			                                                
		}
		if(temp->next != NULL) {
			count--;
			temp2 = temp;
			(temp->prev)->next = temp->next;
			(temp->next)->prev = temp->prev; 
			free(temp2);
		}
		else 
			delete_end();                                             
	}
}
