#include"header.h"

void delete_middle()
{
	struct node *current = NULL;
	struct node *del = 	NULL;
	current = head;
	int i;
	int c = ((count + 2)/2) ;

	printf(" pos = %d",c);
	
	if(head == NULL)
	{
		printf("list is empty\n");
		return;
	}

	if((c == 0) || (c == 1))
	{
		printf(" can't delete because list doesn't have middle node\n");
		return;
	}

	for(i = 1; i < (c - 1); i++)
	{
		current = current->next;
	}
	count--;
	del = current->next;
	current->next = (current->next)->next;
	(current->next)->prev = current;
	free(del);
}
 

