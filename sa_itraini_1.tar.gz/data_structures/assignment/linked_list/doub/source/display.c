#include"header.h"

void display()
{
	struct node *temp = NULL;
	temp = (struct node *) malloc(sizeof(struct node *));

	if(head == NULL)                                                           
	{                                                                           
		printf("List is Empty\n\n");                                                             
	}                                                                           
	
	else                                                                        
	{                                                                           
		temp = head;                                                            

		while( temp->next != NULL )                                             
		{    
			printf("%d\t",temp->data);
			temp = temp->next;                                                  
		}

		printf("%d\t",temp->data);
		printf("\n\n");      
	} 
}                                                             
