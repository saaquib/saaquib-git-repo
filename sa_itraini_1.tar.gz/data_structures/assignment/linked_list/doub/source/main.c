#include"header.h"

int main()
{
	char num[MAX];
	int option;

	printf("Select your option\n1.Insertion\t2.Deletion\t3.Display\t4.Exit\n\n");
	fgets(num,MAX,stdin);
	rem_enter(num);
	option = isvalid(num);

	switch(option)
	{
		case 1 : insert();
				 main();
				 break;

		case 2 : delete_node();                                                      
				 main();                                                        
				 break;

		case 3 : display();                                                      
				 main();                                                        
				 break;
		
		case 4 : printf("Terminating\n");
				 exit(0);

		default : printf("Wrong option Select again");
				  main();
	}
	return 0;
}

