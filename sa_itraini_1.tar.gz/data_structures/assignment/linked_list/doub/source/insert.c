#include"header.h"

void insert()
{
	char num[MAX];                                                              
	int option;  

	printf("Select your option in Insertion\n\
			1. Insert at the beginning\n\
			2. Insert at the end\n\
			3. Insert at a given position\n\
			4.Exit\n\n");
	
	fgets(num,MAX,stdin);                                                       
	rem_enter(num);                                                             
	option = isvalid(num);

	switch(option)                                                              
		    {                                                                           
				case 1 : insert_beg();                                                                                                  
						 break;                                                        

				case 2 : insert_end();                                                                                                    
						 break;                               

				case 3 : insert_pos();                                                                 
						 break;                                                        

				case 4 : printf("Terminating\n");                                     
						  exit(ONE);                                                       
				
				default : printf("Wrong option Select again");                          
						  insert();																												
			}                      
}
