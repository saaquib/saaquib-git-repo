#include"stdio.h"
#include"stdlib.h"

#define ONE 1
#define MAX 32

struct node 
{
	int data;
	struct node *next;
};

struct node *head;

void display(void);

int str_len ( char * );

void rem_enter(char *);

int isvalid( char * );

/* Insert operations */

void insert(void);

void insert_end(void);

void insert_beg(void);

void insert_pos(void);

void insert_bef_pos(void);

void insert_aft_pos(void);

void insert_pen(void);

void insert_aft_num(void);

void insert_bef_num(void);

void insert_mid(void);

/*n Delete operations */

void delete_node();

void delete_end(void);

void delete_beg(void);

void delete_pos(void);

void delete_bef_pos(void);

void delete_aft_pos(void);

void delete_pen(void);

void delete_aft_num(void);

void delete_bef_num(void);

void delete_mid(void);









