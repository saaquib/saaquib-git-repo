#include"header.h"

void delete_node()
{
	char num[MAX];                                                              
	int option;  

	printf("Select your option in Insertion\n\
			1. Delete at the beginning\n\
			2. Delete at the end\n\
			3. Delete at a given position\n\
			4. Delete before a given position\n\
			5. Delete after a given position\n\
			6. Delete before a given number\n\
			7. Delete after a given number\n\
			8. Delete at the middle\n\
			9. Delete at penultinate node\n\
			10.Exit\n\n");
	
	fgets(num,MAX,stdin);                                                       
	rem_enter(num);                                                             
	option = isvalid(num);

	switch(option)                                                              
		    {                                                                           
				case 1 : delete_beg();                                                                                                  
						 break;                                                        

				case 2 : delete_end();                                                                                                    
						 break;                               

				case 3 : delete_at_pos();                                                                 
						 break;                                                        
				
				case 4 : delete_bef_pos();
						 break;

				case 5 : delete_aft_pos();
						 break;

				case 6 : delete_bef_num();
						 break;

				case 7 : delete_aft_num();
						 break;

				case 8 : delete_mid();
						 break;

				case 9 : delete_pen();
						 break;

				case 10 : printf("Terminating\n");                                     
						  exit(ONE);                                                       
				
				default : printf("Wrong option Select again");                          
						  insert();																												
			} 

}
