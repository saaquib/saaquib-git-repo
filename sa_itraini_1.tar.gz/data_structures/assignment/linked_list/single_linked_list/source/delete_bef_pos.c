#include"header.h"

void delete_bef_pos() {

	char num[MAX];
	int pos;
	struct node *temp = NULL;
	struct node *temp2 = NULL;

	printf("Enter position : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	pos = (isvalid(num) - 1);

	temp = (struct node *) malloc(sizeof(struct node *));
	temp2 = (struct node *) malloc(sizeof(struct node *));

	temp = head;

	if(NULL == head) {

		printf("List is empty \n");
		return;
	}
	if(pos < 1)	{

		printf("Cannot delete\n");
		return;
	}

	if(pos == 1) {
                                                                                
		head = temp->next;                                                      
		free(temp);                                                             
		return;
	}                                                                           
	
	else {

		while((--pos) != 1 ) {
                                                                       
			temp = temp->next; 
			                                                
		}
		temp2 = temp->next;
		temp->next = (temp->next)->next;
		free(temp2);
		                                                     
	}

}


