#include"header.h"

void delete_aft_num() {

	char num[MAX];
	int number;
	struct node *temp = NULL;
	struct node *temp2 = NULL;

	temp = (struct node *) malloc(sizeof(struct node *));
	temp2 = (struct node *) malloc(sizeof(struct node *));

	temp = head; 

	if(NULL == head) {
		
		printf("Can't Delete, List is empty");
		return;
	}
	
	else if(NULL == temp->next)	{
		
		printf("List has only one node, Can't Delete \n");
		return;
	}

	printf("Enter number : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	number = isvalid(num);

	while(temp->next != NULL) {
		
		if(number == temp->data) {
			
			temp2 = temp->next;                                                 
			temp->next = (temp->next)->next; 
			free(temp2);
			break;                                                              
		}                                                                       
		else                           
			
			temp = temp->next;                                                  
	}    

}

