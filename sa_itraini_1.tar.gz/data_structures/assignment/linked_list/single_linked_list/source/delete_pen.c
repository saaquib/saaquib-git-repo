#include"header.h"

void delete_pen() {

	struct node *temp = NULL;
	struct node *temp2 = NULL;

	temp = (struct node *) malloc(sizeof(struct node *));
	temp2 = (struct node *) malloc(sizeof(struct node *));
	temp = head;

	if(NULL == head) {

		printf("Can't insert List is empty");
		return;
	}
	
	if(temp->next == NULL)	{
	
		printf("There is no penultinate node, Can't delete\n");
		return;
	}

	if(NULL == (temp->next)->next) {
	
		head = temp->next;
		free(temp);
		return;
	}

	while((temp->next)->next != NULL)
	{
		if(NULL == ((temp->next)->next)->next)	{
			
			temp2 = temp->next;
			temp->next = (temp->next)->next;
			free(temp2);
			break;
		}
		else 
			temp = temp->next;
	}

}

