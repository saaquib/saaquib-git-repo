#include"header.h"

void insert_aft_num()
{
	char num[MAX];
	char num2[MAX];
	int number;
	struct node *new = NULL;
	struct node *temp = NULL;

	new = (struct node *) malloc(sizeof(struct node *));
	temp = (struct node *) malloc(sizeof(struct node *));

	printf("Enter number : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	number = isvalid(num);

	printf("Enter value in new node : ");
	fgets(num2,MAX,stdin);
	rem_enter(num2);
	new->data = isvalid(num2);
	
	temp = head;
	if(NULL == head) {

		printf("Can't insert List is empty");
		return;
	}
	else if(head->data == number)
	{
		
		temp->next = new;
		new->next = (temp->next)->next;
		
		return;
	}

	
	while(temp->next != NULL)
	{
		if((temp->next)->data == number)
		{
			new->next = (temp->next)->next;
			(temp->next)->next = new;
			break;
		}
		else 
			temp = temp->next;
	}

}

