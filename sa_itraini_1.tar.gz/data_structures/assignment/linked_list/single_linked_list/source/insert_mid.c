#include"header.h"

void insert_mid()
{
	char num2[MAX];
	int count = 1;
	struct node *new = NULL;
	struct node *temp = NULL;

	new = (struct node *) malloc(sizeof(struct node *));
	temp = (struct node *) malloc(sizeof(struct node *));

	temp = head;

	if(NULL == head)
	{	
		printf("Can't insert List is empty");
		return;
	}

	if(NULL == temp->next) {                                                    
                                                                                
        printf("List has only one node, Can't Insert \n");                      
        return;                                                                 
   	}

	while(temp->next != NULL)
	{
		count++;
		temp = temp->next;		
	}

	printf("%d\n",count);

	printf("Enter value in new node : ");
	fgets(num2,MAX,stdin);
	rem_enter(num2);
	new->data = isvalid(num2);

	count = ( (count + 2) / 2 );
                                                                         
	temp = head;                                                            
		
	while((--count) != 1 ) {                                                                     
	
		temp = temp->next; 
			                                                
	} 

	new->next = temp->next;
	temp->next = new;
		                                                     
	
}

	

	
