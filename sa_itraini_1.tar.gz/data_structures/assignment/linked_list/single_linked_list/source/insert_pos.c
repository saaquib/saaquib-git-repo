#include"header.h"

void insert_pos()
{
	char num[MAX];
	int pos;
	char num2[MAX];
	struct node *new = NULL;
	struct node *temp = NULL;

	printf("Enter position : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	pos = isvalid(num);

	new = (struct node *) malloc(sizeof(struct node *));
	temp = (struct node *) malloc(sizeof(struct node *));

	if(pos < 1)
	{
		printf("Cannot insert\n");
		return;
	}

	printf("Enter value in new node : ");
	fgets(num2,MAX,stdin);
	rem_enter(num2);
	new->data = isvalid(num2);
	
	if(pos == 1)                                                           
	{       
		new->next = head;                                                          
		head = new;                                                             
	}                                                                           
	
	else                                                                        
	{                                                                           
		temp = head;                                                            
		
		while((--pos) != 1 )                                             
		{                                                                       
			temp = temp->next; 
			                                                
		} 
		new->next = temp->next;
		temp->next = new;
		                                                     
	}
}
