#include<header.h>

void dequeue()
{
	if(0 == count)
	{
		printf("Queue is empty \n\n");
	}
	else
	{
		printf("Element Dequeued = %d \n\n",queue[front]);
		front = ((front + 1) % LIMIT);
		count--;
	}
} 
