#include<stdio.h>
#include<stdlib.h>

#define MAX 32
#define LIMIT 5

int front;
int rear;
int count;
int queue[LIMIT];

void enqueue(void);

void dequeue(void);

int str_len( char * );

void rem_enter( char * );

int isvalid( char * );
