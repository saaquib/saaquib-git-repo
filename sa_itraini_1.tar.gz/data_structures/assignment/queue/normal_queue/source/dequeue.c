#include<header.h>

void dequeue()
{
		if(front == rear)
			printf("Queue is empty \n\n");
		else
			printf("Element Dequeued = %d \n\n",queue[front]);
			front++;
} 
