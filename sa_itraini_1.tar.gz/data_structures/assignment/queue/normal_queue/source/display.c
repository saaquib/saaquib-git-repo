#include<header.h>

void display()
{
	int i;

	if(front == rear)
	{
		printf("Queue is Empty\n\n");
	}
	else
	{
		printf("Queue :  ");
		for(i = front; i < rear; i++)
		{
			printf("%d    ",queue[i]);		
		}
	}
}
