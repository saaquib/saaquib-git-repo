#include<header.h>

void enqueue()
{
	char num2[MAX];
	int element;

	if(rear == LIMIT)
	{
		printf("Queue is full \n\n");
	}
	else
	{
		printf("Enter the value to enqueue : ");
		fgets(num2,MAX,stdin); 
		rem_enter(num2);
		element = isvalid(num2);

		queue[rear] = element;
		rear++;
	}
}

