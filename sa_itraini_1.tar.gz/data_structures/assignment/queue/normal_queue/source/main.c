#include<header.h>

void main()

{	
	char num[MAX];
	int option;

	printf("\nSelect operation\n");
	printf("1.Enqueue\t 2.Deque\t 3.Display All Elements\t 4.Exit\n");
	fgets(num,MAX,stdin);
	rem_enter(num);
	option = isvalid(num);
	
	switch (option)
	{
		case 1 :printf("Your option is Enqueue\n");
	   			enqueue();
				main();
				break;

		case 2 :printf("Your option is Dequeue\n");
				dequeue();
				main();
				break;
	
		case 3 :printf("Your option is Display the Queue\n");
				display();
				main();
				break;

	 	case 4 :printf("Your option is EXIT\n");
				exit (0);
	
		default :printf("Wrong option Select again\n");
		 		 main();
	}
}
