#include <stdio.h>
#include <stdlib.h>
#define MAX 64
 
int top;                                                                                                                            
int stack[MAX]; 

int pop();
void push(); 
void display();


