#include"header.h"

int main()
{
	int arr[SIZE];
	char num[MAX];
	int i;
	int n;

	/* enter the number of elements in an array*/
	printf("enter the number of elements in an array:\n");
	if(NULL == (fgets(num, MAX, stdin))) {
		perror("fgets failed");
		exit(EXIT_FAILURE);
	}
	rem_enter(num);
	n = isvalid(num);

	printf("Enter values of array  \n");
	for( i = 0; i < n; i++ )
	{
		printf("arr[%d] :  ",i);
		fgets(num,MAX,stdin);
		rem_enter(num);
		arr[i] = isvalid(num);
	}

	ascending_bubble(arr, n);

	printf("After sorting in ascending order  values of array  \n");                                        
	for( i = 0; i < n; i++ )                                                 
	{                                                                           
		printf(" %d \n",arr[i]);

	}

	descending_bubble(arr, n);	
	
	printf("After sorting in descending order  values of array  \n");                                        
	for( i = 0; i < n; i++ )                                                 
	{                                                                           
		printf(" %d \n",arr[i]);

	}

	return 0;
}
