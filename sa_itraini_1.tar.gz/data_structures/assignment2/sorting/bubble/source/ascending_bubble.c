#include"header.h"

void ascending_bubble(int *ptr, int size)
{
	int count;
	int i;
	int temp;	

	for(count = 0; count < size - 1; count++)
	{
		for(i = 0; i < size; i++)
		{
			if(*(ptr + i) > *(ptr + i + 1))
			{				
				temp = 	*(ptr + i);
				*(ptr + i) = *(ptr + i + 1);
				*(ptr + i + 1) = temp;
			}
		}
	}

}
