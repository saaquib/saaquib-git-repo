#include"stdio.h"
#include"stdlib.h"
#define SIZE 20
#define MAX 32

void ascending_bubble(int *, int);

void descending_bubble(int *, int);

void rem_enter(char *);

int str_len ( char *);

int isvalid( char *);


