#include"header.h"

int main()
{
	int arr[SIZE];
	int n;
	char num[MAX];
	int i;
	
	/* enter the number of elements in an array*/
	printf("enter the number of elements in an array:\n");
	if(NULL == (fgets(num, MAX, stdin))) {
		perror("fgets failed");
		exit(EXIT_FAILURE);
	}
	rem_enter(num);
	n = isvalid(num);

	printf("Enter values of array  \n");

	for( i = 0; i < n; i++ )
	{
		printf("arr[%d] :  ",i);
		if(NULL == (fgets(num, MAX, stdin))) {
			perror("fgets failed\n");
			exit(ONE);
		}
		rem_enter(num);
		arr[i] = isvalid(num);
	}

	quick_sort(arr,0, n - 1);	//function call for quick sort

	printf("Sorted array : ");
	
	for(i = 0; i < n ;i++)
		printf("%d\t", arr[i]);
	
	printf("\n");
	

	return 0;
}
