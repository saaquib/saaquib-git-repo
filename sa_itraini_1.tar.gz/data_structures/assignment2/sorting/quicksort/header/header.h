#include<stdio.h>
#include<stdlib.h>
#define MAX 32
#define SIZE 20
#define ONE 1

void quick_sort(int arr[], int low, int high);

int partition(int arr[],int low,int high);

void rem_enter(char *);

int str_len ( char *);

int isvalid( char *);




