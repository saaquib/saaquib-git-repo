#include"header.h"

void ascending_insertion(int *ptr, int size)
{
	int i;
	int j;
	int tm;
	int temp;	

	for(i = 1; i < size; i++)
	{
		tm = *(ptr + i);
		for(j = i - 1; j >= 0; j--)
		{
			if(tm < *(ptr + j))
			{				
				temp = 	*(ptr + j + 1);
				*(ptr + j + 1) = *(ptr + j);
				*(ptr + j) = temp;
			}
		}
	}

}
