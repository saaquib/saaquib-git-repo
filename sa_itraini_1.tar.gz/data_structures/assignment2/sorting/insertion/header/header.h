#include"stdio.h"
#include"stdlib.h"
#define SIZE 20
#define MAX 32

void ascending_insertion(int *, int);

void descending_insertion(int *, int);

void rem_enter(char *);

int str_len ( char *);

int isvalid( char *);


