#include"header.h"

void ascending_selection(int *ptr,int size)
{
	int min;
	int i;
	int j;
	int temp;	

	for(i = 0; i < size - 1; i++)
	{
		min = i;
		for(j = i + 1; j < size; j++)
		{
			if(*(ptr + min) > *(ptr + j))
				min = j;
		}
		temp = 	*(ptr + min);
		*(ptr + min) = *(ptr + i);
		*(ptr + i) = temp;
	}

}
