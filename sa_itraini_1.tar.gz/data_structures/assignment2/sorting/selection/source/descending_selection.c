#include"header.h"

void descending_selection(int *ptr, int size)
{
	int pos;
	int i;
	int j;
	int temp;	

	for(i = 0; i < size - 1; i++)
	{
		pos = i;
		for(j = i + 1; j < size; j++)
		{
			if(*(ptr + pos) < *(ptr + j))
				pos = j;
		}
		temp = 	*(ptr + pos);
		*(ptr + pos) = *(ptr + i);
		*(ptr + i) = temp;
	}

}
