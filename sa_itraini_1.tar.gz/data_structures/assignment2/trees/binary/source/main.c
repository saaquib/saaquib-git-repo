#include"header.h"

int main()
{	
	char num[MAX];
	int option;

	printf("\nEnter your option \n\
		1.Insert\n\
		2.Display Pre order\n\
		3.Display Post order\n\
		4.Display In order\n\
		5.EXIT\n\n");

	fgets(num,MAX,stdin);
	rem_enter(num);
	option = isvalid(num);
	
	switch( option )
	{
		case 1 : insert();
				 main();
				 break;
		
		case 2 : if(NULL == root)
				 {
					 printf("Tree is empty\n");
					 break;
				 }
				 pre_order(root);
				 main();
				 break;
		
		case 3 : if(NULL == root)                                               
				 {                                                              
					 printf("Tree is empty\n");                                 
					 break;                                                     
				 }
				 post_order(root);                                               
				 main();                                                        
				 break;

		case 4 : if(NULL == root)                                               
				 {                                                              
					 printf("Tree is empty\n");                                 
					 break;                                                     
				 }																                 
				 in_order(root);
				 main();                                                        
				 break;

		case 5 : printf("Terminating\n");
			 exit(1);
		
		default : printf("wrong option \n");
				  main();
	 }

}
