#include"header.h"

void insert()
{
	char num[MAX];
	struct node *new = NULL;

	new = MEM_ALLOC;                                                       
	MEM_VALID(new);

	printf("Enter value to insert : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	new->data = isvalid(num);

	if(NULL == root)
	{
		root = MEM_ALLOC;
		MEM_VALID(root);
		root = new;
	}

	else
	{
		temp = root;
		
		while( 1 )
		{
			if(new->data > temp->data)
			{
				if(NULL == temp->right)
				{
					temp->right = new;
					break;
				}
				else	
					temp = temp->right;
			}
			else
			{
				if(NULL == temp->left)
				{
					temp->left = new;
					break;
				}
				else
					temp = temp->left;
			}
		}
	}
}

	

