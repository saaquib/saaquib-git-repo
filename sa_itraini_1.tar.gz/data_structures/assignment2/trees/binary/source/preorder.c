#include"header.h"

void pre_order(struct node* current)
{
	if(current != NULL)
	{
		printf("%d\t", current->data);
		pre_order(current->left);
		pre_order(current->right);
	}
}
