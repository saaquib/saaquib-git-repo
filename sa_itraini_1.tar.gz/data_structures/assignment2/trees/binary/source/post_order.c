#include"header.h"

void post_order(struct node *current)
{
	    if(current != NULL)
		{
			post_order(current->left);
			post_order(current->right);
			printf("%d\t", current->data);
		}
}

