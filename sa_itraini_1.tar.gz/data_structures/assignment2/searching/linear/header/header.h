#include"stdio.h"
#include"stdlib.h"
#define SIZE 5
#define MAX 32

int linear(int *, int); 

void rem_enter(char *);

int str_len ( char *);

int isvalid( char *);


