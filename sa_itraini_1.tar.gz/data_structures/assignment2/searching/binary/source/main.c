#include"header.h"

int main()
{
	int arr[SIZE];
	char num[MAX];
	int value;
	int i;
	
	printf("Enter values of array  \n");
	for( i = 0; i < SIZE; i++ )
	{
		printf("arr[%d] :  ",i);
		fgets(num,MAX,stdin);
		rem_enter(num);
		arr[i] = isvalid(num);
																			
	}
	
	printf("Enter value to search : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	value = isvalid(num);
	
	printf("Given value found at position : %d \n",binary(arr,value));
	
	return 0;
}
