#include"header.h"

void delete_num()
{
	char num[MAX];
	int value;
	struct node *prev = NULL;
	struct node *current = NULL;

	prev = MEM_ALLOC;                                                       
	MEM_VALID(prev);

	current = MEM_ALLOC;                                                       
	MEM_VALID(current);

	if(NULL == root)
	{
		printf("Empty , cannot delete\n");
		return;
	}        
    
	printf("Enter value to delete : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	value = isvalid(num);

	current = root;
	 printf("%d\n",current->data); 

	while(current->data != value)
	{
		if(current->data < value)
		{
			prev = current;
			current = current->right;
		}
		else
		{
			prev = current;
			current = current->left;
		}
	}

	if(current->left == NULL)
		if(NULL != current->right)
		{
			if(current->data < prev->data)
			{
				prev->left = current->right;
				free(current);
			}
			else 
			{
				prev->right = current->right;
				free(current);
			}
		}
	
	else if(current->right == NULL)
		if(NULL != current->left)                                              
		{                                                                       
			if(current->data < prev->data)                                      
			{                                                                   
				prev->left = current->left;                                    
				free(current);                                                  
			}                                                                   
			else                                                                
			{                                                                   
				prev->right = current->left;                                     
				free(current);                                                  
			}                                                                   
		}
}
