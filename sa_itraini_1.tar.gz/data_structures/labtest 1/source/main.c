#include"header.h"

int main()
{	
	char num[MAX];
	int option;

	printf("\nEnter your option \n\
		1.Insert\n\
		2.Display Pre order\n\
		3.Delete\n\
		4.EXIT\n\n");

	fgets(num,MAX,stdin);
	rem_enter(num);
	option = isvalid(num);
	
	switch( option )
	{
		case 1 : insert();
				 main();
				 break;
		
		case 2 : if(NULL == root)
				 {
					 printf("Tree is empty\n");
					 break;
				 }
				 printf("pre order : ");
				 pre_order(root);
				 main();
				 break;
		
		case 3 : delete_num();                                              
				 main();                                                        
				 break;


		case 4 : printf("Terminating\n");
    			 exit(1);
		
		default : printf("wrong option \n");
				  main();
	 }

}
