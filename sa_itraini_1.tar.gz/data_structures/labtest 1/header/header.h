#include"stdio.h"
#include"stdlib.h"

#define MAX 32

#define MEM_ALLOC (struct node *) malloc(sizeof(struct node))

#define MEM_VALID(name) if(!name) {	printf("memory is not allocated\n"); \
				        exit(1); }

struct node
{
	int data;
	struct node *left;
	struct node *right;
};

struct node *root;
struct node *temp;

void insert(void);

void rem_enter(char *);

int str_len(char *);

int isvalid( char *);

void pre_order(struct node *);

void delete_num(void);
