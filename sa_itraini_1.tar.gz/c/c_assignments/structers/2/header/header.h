#include<stdio.h>

union sample
{
int a:5;
int b:10;
int c:5;
int d:21;
int e;
}e1;
