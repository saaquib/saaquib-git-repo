#include<header.h>

int main()
{
	e1.e = 5;
	printf("Value of a = %d \n",e1.a);
	printf("Value of b = %d \n",e1.b);
	printf("Value of c = %d \n",e1.c);
	printf("Value of d = %d \n",e1.d);
	printf("Value of e = %d \n",e1.e);
}
