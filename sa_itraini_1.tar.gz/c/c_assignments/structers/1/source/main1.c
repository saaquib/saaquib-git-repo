#include<header.h>

int main()
{
	struct frame1 f1;
	struct frame2 f2;
	struct frame3 f3;

	printf("Size of frame1 : %d\n",sizeof(f1));
	printf("Size of frame2 : %d\n",sizeof(f2));
	printf("Size of frame3 : %d\n",sizeof(f3));

	return 0;
}
