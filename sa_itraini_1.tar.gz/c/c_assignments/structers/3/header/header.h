#include<stdio.h>

union endianess
{
	unsigned int num;
	char bit;
}check;

