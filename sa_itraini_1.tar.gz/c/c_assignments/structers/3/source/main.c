#include<header.h>

int main()
{
	check.num = 1;
	
	if( 1 == check.bit )
		printf("System is Little endian \n\n");
	else
		printf("System is Big endian \n\n");

	return 0;
}
