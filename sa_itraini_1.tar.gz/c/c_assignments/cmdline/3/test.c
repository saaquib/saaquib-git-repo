#include<stdio.h>
#include<stdlib.h>

void main(int argc,char *argv[])
{
	
	if(argv[1] == hello)
		printf("Hello\n");
	else 
		printf("Bye\n");
}

