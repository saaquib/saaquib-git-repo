#include<stdio.h>
#include<string.h>


int add(int,int);

int sub(int,int);

int mul(int,int);

int div(int,int);

int isvalid(char *);

int str_len(char *);

int (*ptr)(int,int);



