#include<header.h>

int main( int argc, char *argv[] )
{
	int i;
	argc--;

	printf("Number of C Files in given folder : %d \n\n",argc);
	printf("Files in given folder :- \n");
	
	for ( i = 1; i <= argc; i++ )
	{
		printf("%d \t %s  \n",i,argv[i]);
	}

	return 0;
}
