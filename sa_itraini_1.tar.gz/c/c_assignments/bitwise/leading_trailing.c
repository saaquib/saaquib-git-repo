#include<stdio.h>

void showbits( int );
int cnt_leading_set_bits( int num );
int cnt_leading_cleared_bits( int num );
int cnt_trailing_cleared_bits( int num );
int cnt_trailing_set_bits( int num );

int main()

{
        int num;

        printf("Enter the number : ");
        scanf("%d",&num);
        printf("Number in binary form : ");
        showbits(num);

        printf("Number of leading set bits : %d",cnt_leading_set_bits ( num ) );
	
        printf("\nNumber of leading clear bits : %d",cnt_leading_cleared_bits ( num ) );
	
        printf("\nNumber of trailing clear bits : %d",cnt_trailing_cleared_bits ( num ) );
	
        printf("\nNumber of trailing set bits : %d",cnt_trailing_set_bits( num ) );
        
	return 0;
}

int cnt_leading_set_bits( int num )
{       
        int i;
        int ls = 0;

	for (i=31;i>=0;i--)
        {
        	if ( ( num & ( 1 << i ) ) == 0 )
          		break;
		ls++;
	}

        return ls;
}

int cnt_leading_cleared_bits ( int num )
{
        int i;
        int lc = 0;

        for ( i = 31; i >= 0; i-- )
        { 
	        if ( ( num & ( 1 << i ) ) ) 
       			break;
		lc++;
        }

        return lc;
}

int cnt_trailing_cleared_bits ( int num )
{	
	int i;
	int tc = 0;

	for ( i = 0; i<=31; i++ )
	{
	        if ( ( num & ( 1 << i ) ) )
        		break;
		tc++;
        }

        return tc;
}
 
int cnt_trailing_set_bits ( int num )
{
        int i;
        int ts = 0;

        for ( i = 0; i <= 31; i++ )   
        {
		if ( ( num & ( 1 << i ) ) == 0 )
       			 break;
		ts++;
        }

        return ts;
}


