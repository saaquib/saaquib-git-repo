#include <stdio.h>

void showbits(int );
unsigned int left_rotate_bits (unsigned int num);
unsigned int right_rotate_bits (unsigned int num);
unsigned int left_rotate_n_bits (unsigned int num, int n);
unsigned int right_rotate_n_bits (unsigned int num, int n);
int main()

{

	int num,n;
        printf("Enter the number : ");
	scanf("%d",&num);
        printf("Number in binary form : ");
        showbits(num);
        printf("\nEnter the number of bits to rotate left and right : ");
        scanf("%d",&n);
        //a
	printf("\nAfter left rotate : ");
        showbits(left_rotate_bits (num));
        //b
	printf("\nAfter right rotate : ");
        showbits(right_rotate_bits (num));
        //c
        printf("\nAfter left rotate %d bits : ",n);
        showbits(left_rotate_n_bits (num,n));
        //d
        printf("\nAfter right rotate %d bits : ",n);
        showbits(right_rotate_n_bits (num,n));

	return 0;
}

unsigned int left_rotate_bits (unsigned int num)

{
	num = (num >> 31) | (num << 1) ;
        return num;
}

unsigned int right_rotate_bits (unsigned int num)

{
	num = (num << 31) | (num >> 1) ;
        return num;
}

unsigned int left_rotate_n_bits (unsigned int num, int n)

{
        while(n)
        {
        num = (num >> 31) | (num << 1) ;
        n--;
        }

        return num;
}

unsigned int right_rotate_n_bits (unsigned int num, int n)

{
	while(n)
        {
        num = (num << 31) | (num >> 1) ;
 	n--;
	}
        return num;
}


void showbits(int n)
{
        int i;
        int count = 0;
        for (i = 32;i>=1;i--)
        {
                count++;
                printf("%d", (1&(n>>(i-1))) );
                if(count%8 == 0)
                printf(" ");
        }
}

