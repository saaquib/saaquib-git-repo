#include<stdio.h>
/*
#define a_max(a,b) int m;                                                                                                \
                   for (m=31;m>=0;m--)                                                                                   \
	           {	                                                                                                 \
			if((a^b) & (1<<m))                                                                               \
		        {                                                                                                \
                        (a & (1<<m)) ? printf(" %d is maximum number\n",a) : printf(" %d is maximum number \n",b);       \
			break;                                                                                           \
                        }                                                                                                \
                   }
*/

#if 1

#define b_clear_right(num) int cr;                                                                                       \
                           for (cr=0;cr<=31;cr++)                                                                        \
                           if ( num & (1<<cr)) {                                                                         \
                           showbits ( (num & (~(1<<cr)))); break ; }


#define c_clear_left(num) int cl;                                                                                        \
                          for (cl=31;cl>=0;cl--)                                                                         \
                          if ( num & (1<<cl)) {                                                                          \
                          showbits ( (num & (~(1<<cl)))); break ; }
 
#define d_set_right(num) int sr;                                                                                         \
                         for (sr=0;sr<=31;sr++)                                                                          \
                         if ( (num & (1<<sr)) == 0) {                                                                    \
                         showbits ( (num | (1<<sr))); break ; }

#define e_set_left(num) int sl;                                                                                          \
                        for (sl=31;sl>=0;sl--)                                                                           \
                        if ( (num & (1<<sl)) ==0 ) {                                                                     \
                        showbits ( (num | (1<<sl))); break ; }

#define f_set(num,s,d) int f = -1 ;                                                                                      \
                       f = (s>d) ? (~(f<< ((s-d)+1)) << (d-1) ): (~(f<< ((d-s)+1))<<(s-1));                              \
                       printf("After set bits from s to d : ");                                                          \
                       showbits((num & f) | f);                                                                


#define g_clear(num,s,d) int g = -1 ;                                                                                    \
                         g = (s>d) ? (~(~(g<< ((s-d)+1)) << (d-1))) : (~(~(g<< ((d-s)+1))<<(s-1)));                      \
                         printf("After clear bits from s to d : ");                                                      \
                         showbits((num & g) | g);                                                                


#define h_toggle(num,s,d) int h = -1 ;                                                                                   \
                          h = (s>d) ? (~(h<< ((s-d)+1)) << (d-1) ): (~(h<< ((d-s)+1))<<(s-1));                           \
                          printf("After toggle from s to d : ");                                                         \
                          showbits(num ^ h);                                                                

#if 1

// A:To find maximum and minimum of 2 numbers

int main()

{       
        int num1,num2;
        printf("Enter the first number : ");
        scanf("%d",&num1);
        printf("Enter the second number : ");
        scanf("%d",&num2);
        max(num1,num2);
}

#endif

void showbits(int);
int main()

{       
	int num;
        printf("Enter the number : ");
        scanf("%d",&num);
        showbits(num);

        // b: clear rightmost set bit
        printf("after clearing rightmost set bit : ");
        b_clear_right(num);

   	// c: Clear leftmost set bit
        printf("\nafter clearing leftmost set bit : ");
        c_clear_left(num);
        
	// d: set rightmost clear bit
        printf("after set rightmost clear bit : ");
        d_set_right(num);

	// e: set leftmost clear bit
        printf("after set leftmost clear bit : ");
        e_set_left(num);


	return 0;
}

#endif
void showbits(int n)
{
        int i;
        int count = 0;
        for (i = 32;i>=1;i--)
        {
                count++;
                printf("%d", (1&(n>>(i-1))) );
                if(count%8 == 0)
                printf(" ");
        }
}



#if 1

int main()

{       
        int num;
        int s;
        int d;

        printf("Enter the number : ");
        scanf("%d",&num);
        showbits(num);
        printf("Enter the source position : ");
        scanf("%d",&s);
        printf("Enter the destination position : ");
        scanf("%d",&d);

        // F: To set bits from bit position ‘s’ to bit position ‘d’ in a given number and clear rest of the bits
	f_set(num,s,d);
        
        // G: To clear bits from bit position ‘s’ to bit position ‘d’ in a given number and set rest of the bits
        g_clear(num,s,d);

	// H: To toggle bits from bit position ‘s’ to bit position ‘d’ in a given number
	h_toggle(num,s,d);

	return 0;
}

#endif
