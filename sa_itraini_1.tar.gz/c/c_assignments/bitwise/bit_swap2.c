#include<stdio.h>

extern void showbits ( int );
int bit_swap ( int , int , int , int );

int main ()
{
        int snum;
        int dnum;
        int s;
        int d;

        printf("enter the 1st number snum : ");
        scanf("%d", &snum);
        printf("1st number in binary form :");
        showbits ( snum );

        printf("\nenter the 2nd number dnum : ");
        scanf("%d", &dnum);
        printf("2nd number in binary form :");
        showbits ( dnum );

        printf("\nEnter the position of source in snum :");
        scanf("%d", &s);

        printf("Enter the position of destination in dnum :");
        scanf("%d", &d);

        bit_swap ( snum, dnum, s, d );

	return 0;

}

int bit_swap ( int snum, int dnum, int s, int d )
{
        int s_bit;
	int d_bit;

        s_bit = ( snum & ( 1 << ( s - 1 ) ) ) ? 1 : 0;
        d_bit = ( dnum & ( 1 << ( d - 1 ) ) ) ? 1 : 0;
        
        if ( s_bit != d_bit) 
        {
        	snum = ( snum & ( ~ ( 1 << ( s - 1 ) ) ) ) | ( d_bit << ( s - 1 ) );
        	dnum = ( dnum & ( ~ ( 1 << ( d - 1 ) ) ) ) | ( s_bit << ( d - 1 ) );

                printf("\n1st number after swap :");
        	showbits ( snum );

        	printf("\n2nd number after swap :");
        	showbits ( dnum );
	}
        else 
        	printf(" \nThe source and destination bits are same, no need of swap");

        return 0;
}   



                    
