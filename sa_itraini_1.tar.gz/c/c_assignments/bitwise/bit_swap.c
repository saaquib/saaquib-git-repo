#include<stdio.h>

extern void showbits( int );
int bit_swap ( int , int , int );

int main ()
{
        int num;
        int s;
        int d;

        printf("enter the number : ");
        scanf("%d", &num);

        printf("Given number in binary form :");
        showbits( num );

        printf("\nEnter the position of source :");
        scanf("%d", &s);

        printf("Enter the position of destination :");
        scanf("%d", &d);

        num = bit_swap ( num, s, d );

        printf("Result :");
        showbits( num );

	return 0;
}

int bit_swap ( int n, int s, int d )

{
        int s_bit;
	int d_bit;

	s_bit = ( n & (1 << ( s - 1 ) ) ) ? 1 : 0;
	d_bit = ( n & (1 << ( d - 1 ) ) ) ? 1 : 0;
	
        if( s_bit != d_bit )
        {
		n = ( n & ( ~ ( 1 << ( s - 1 ) ) ) );
       		n = ( n & ( ~ ( 1 << ( d - 1 ) ) ) );
        	n = ( n | ( s_bit << ( d - 1 ) ) );
        	n = ( n | ( d_bit << ( s - 1 ) ) );
        }
        else 
        	printf("\nThe source and destination bits are same, no need of swap \n");
        
	return n;
}

