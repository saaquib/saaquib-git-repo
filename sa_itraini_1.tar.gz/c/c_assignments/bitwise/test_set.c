#include <stdio.h>

#define bit_ts( num, pos ) printf("Value of bit in the given position : %d ",( num & ( 1 << ( pos-1 ) ) ) ? 1 : 0 );             \
		           num = ( num | ( 1 << ( pos-1 ) ) );           /* set the bit in given position*/                      \
		       	   printf("\nAfter set the bit in given position : ");                                                   \
                           showbits( num );


extern void showbits( int );          // prototype of show bits function used to print the input number into binary 

int main()
{
	int num;
	int pos;                      // declaring the variables of input number and position of the bit to test and set
    	
        printf("Enter the number : ");
        scanf("%d", &num);

        printf("Given number in Binary form : ");
        showbits( num );

        printf("\nEnter the position of bit to test and set : ");
        scanf("%d", &pos);

	bit_ts( num, pos );           // calling macro to test and set the bit in given position

	return 0;
}


