#include <stdio.h>

extern void showbits ( int );
int even_bit_toggle ( int );
int odd_bit_toggle ( int );

int main ()
{
	int num;
	int even_tog;
	int odd_tog;

        printf("Enter the number : ");
        scanf("%d", &num);
        printf("Number in binary form : ");
        showbits( num ); 

        even_tog = even_bit_toggle ( num );
        printf("\nAfter even bits toggle : ");
        showbits( even_tog );

        odd_tog = odd_bit_toggle ( num ); 
        printf("\nAfter odd bits toggle : ");
        showbits( odd_tog );

	return 0;
}

int even_bit_toggle ( int num )

{   
	int i;

	for( i = 32; i >= 1; i-- )
        {         
	    	num = ( num ^ ( 1 << ( i-1 ) ) );
        	i--;
        }

        return num;


}

int odd_bit_toggle (int num)

{
        int i;
    	for( i=32; i >= 2; i-- )
	{
		i--;
    		num = ( num ^ ( 1 << ( i-1 ) ) );
	}

    	return num;


}


