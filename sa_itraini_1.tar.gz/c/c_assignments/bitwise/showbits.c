#include <stdio.h>


void showbits(int n)
{
        int i;
        int count = 0;

        for ( i = 32; i >= 1; i-- )
        {
                count++;
                printf("%d", ( 1 & ( n >> ( i-1 ) ) ) );
                if( 0 == count % 8 )
                printf(" ");
        }
}



