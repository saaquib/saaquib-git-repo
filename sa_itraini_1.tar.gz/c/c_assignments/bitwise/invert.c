#include<stdio.h>

void showbits(int);
int invert(int, int, int);
int main()
{
	int num,pos,n;
        printf("Enter number : ");
        scanf("%d",&num);
        printf("Given number in binary form : ");
        showbits(num);
        printf("\nEnter position to start : ");
        scanf("%d",&pos);
        printf("Enter number of bits to invert : ");
        scanf("%d",&n);
	num = invert (num,pos,n);
        printf("After invert : ");
        showbits(num);

	return 0;
}

invert (x,p,n)
{
	int a = -1;
        x = ( x ^ (( ~ (a<<n) ) << (p-n)));
        return x ;    

}

void showbits(int n)
{
        int i;
        int count = 0;
        for (i = 32;i>=1;i--)
        {
                count++;
                printf("%d", (1&(n>>(i-1))) );
                if(count%8 == 0)
                printf(" ");
        }
}




