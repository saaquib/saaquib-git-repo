#include<stdio.h>
#define getbits(x,p,n) int a=-1;                                     \
                       if(n>p)                                       \
                       x = ( x & ((~(a<<n)) << (p-1))) ;        \
                       else  x = ( x & ((~(a<<n)) << p)) >> (n-p) ;  \
		       

void showbits(int);
int main()

{
        int num,p,n;
        printf("Enter the number : ");
        scanf("%d",&num);
        printf("Number in binary form : ");
        showbits(num);
        printf("\nEnter the position :");
        scanf("%d",&p);
        printf("Enter the number of bits to get :");
        scanf("%d",&n);
        getbits(num,p,n);
        printf("bits :");
        showbits(num);        
	return 0;
}


void showbits(int n)
{
        int i;
        int count = 0;
        for (i = 32;i>=1;i--)
        {
                count++;
                printf("%d", (1&(n>>(i-1))) );
                if(count%8 == 0)
                printf(" ");
        }
}



