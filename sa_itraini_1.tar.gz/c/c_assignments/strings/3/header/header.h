#include <stdio.h>
#include <stdlib.h>
#define MAX 32

extern int str_len( char * );

extern char * chr_add_instr(char *, char );

extern void rem_enter( char * );

extern int isvalid( char * );

extern void mem_valid(char * );
