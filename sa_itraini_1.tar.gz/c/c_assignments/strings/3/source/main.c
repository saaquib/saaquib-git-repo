#include <header.h>

int main()
{
	char *sbuf = NULL;
	char ch;
	int size;
	char *ptr;
	char num[MAX];

        printf("\nEnter the size of array : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);

	sbuf = (char *) malloc( sizeof(char) * size );
	mem_valid(sbuf);

	printf("\nEnter the input string : ");
        fgets( sbuf, size, stdin );
	rem_enter(sbuf);

	printf("\nEnter the character to check first occurance : " );
	ch = getchar();
	
	printf("\nStarting address of string : %p \n\n",sbuf);
	ptr = chr_add_instr(sbuf, ch);
	printf("\nAddress of the first occurrence of character : %p \n\n",ptr);
	
	return 0;
}
