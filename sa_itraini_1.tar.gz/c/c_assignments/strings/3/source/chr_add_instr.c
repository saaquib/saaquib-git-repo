#include<header.h>

char * chr_add_instr(char *buf, char ch)
{
	int i;
	for(i = 0;i < str_len( buf ); i++)
	{
		if(*(buf+i) == ch )
		return (buf+i);
	}
}
