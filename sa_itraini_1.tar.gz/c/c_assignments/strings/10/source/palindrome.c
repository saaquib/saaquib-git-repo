#include<header.h>

void ispalindrome( char *str )

{
	int i;
	int count = 0;
	int l = (str_len( str ) - 1);

	for ( i = 0; i < str_len( str ) / 2 ; i++, l-- )
	{
		if ( *(str + i) != *(str + l) )
		{	
			count++;
			break;
		}
	}
	
	if ( count )
		printf("\nGiven string is not palindrome \n \n");
	else
		printf("\nGiven string is palindrome \n \n");

}
