#include <header.h>

int main()
{
        char *str = NULL;
        int size;
	char num[MAX];

        printf("\nEnter the size of array : ");
        fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);

        str = (char *) malloc( sizeof(char) * size );
	mem_valid(str);

        printf("\nEnter the input string : ");
        fgets( str, size, stdin );
        rem_enter(str);

	ispalindrome( str );

	return 0;

}
