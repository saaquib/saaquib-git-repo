#include <stdio.h>

char * snappend (char *str1, char *str2, int n)
{	
	int i = str_len(str2);
	
	while ( n && *str2 )
	{
		*(str2+i) = *(str1++);
		i++;
		n--;
	}

 	return str2;

}
