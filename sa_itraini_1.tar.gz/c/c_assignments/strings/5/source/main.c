#include<header.h>

int main()
{
        char *sbuf = NULL;
        char *dbuf = NULL;
	char num[MAX];
	char num2[MAX];
	int n;
        int size;

        printf("\nEnter the size of array : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);

        sbuf = (char *) malloc( sizeof(char) * size );
	mem_valid(sbuf);
	dbuf = (char *) malloc( sizeof(char) * size );
	mem_valid(sbuf);

        printf("\nEnter the input string 1 : ");
	fgets( sbuf, size, stdin );
        rem_enter(sbuf);
	
        printf("\nEnter the input string 2 : ");
        fgets( dbuf, size, stdin );
        rem_enter(dbuf);

        printf("\nEnter the number of bits to append from string 1 : ");
	fgets(num2,MAX,stdin);
	rem_enter(num2);
	n = isvalid(num2);

	sbuf = snappend ( sbuf, dbuf, n );
	printf("after sappend n bits : %s \n", sbuf);

	return 0;
}
