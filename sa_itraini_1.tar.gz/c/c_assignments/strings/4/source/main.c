#include <header.h>

int main()
{
        char *sbuf = NULL;
        char *dbuf = NULL;
	char num[MAX];
        int size;

        printf("\nEnter the size of array : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);

        sbuf = (char *) malloc( sizeof(char) * size );
	mem_valid(sbuf);
	dbuf = (char *) malloc( sizeof(char) * size );
	mem_valid(sbuf);

        printf("\nEnter the input string 1 : ");
        fgets( sbuf, size, stdin );
  	rem_enter(sbuf);
		
        printf("\nEnter the input string 2 : ");
        fgets( dbuf, size, stdin );
	rem_enter(dbuf);

	sbuf = sappend ( sbuf, dbuf );
	printf("\nafter sappend : %s \n\n", sbuf);


	return 0;
}
