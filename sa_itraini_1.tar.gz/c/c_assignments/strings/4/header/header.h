#include<stdio.h>
#include<stdlib.h>
#define MAX 32

extern char * sappend (char *, char *);

extern int str_len ( char *);

extern void rem_enter( char * );

extern int isvalid( char * );

extern void mem_valid(char * );
