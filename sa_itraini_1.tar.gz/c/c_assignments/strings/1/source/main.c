#include <header.h>

int main()
{	
	int size;
	char num[max];
	char *sbuf = NULL;
	char *dbuf = NULL;

	printf("\nEnter the size of array : ");
	fgets(num,max,stdin);
	rem_enter(num);
	size = isvalid(num);

	sbuf = (char*) malloc(sizeof(char) * size);
	mem_valid(sbuf);

	dbuf = (char*) malloc(sizeof(char) * size);
	mem_valid(dbuf);

	printf("\nEnter the input string : ");
	fgets(sbuf,size,stdin);
	rem_enter(sbuf);
	
	str_cpy(dbuf, sbuf);

        printf("\nSource String sbuf = %s \n\n", sbuf);
        printf("\nAfter copyng string from sbuf to dbuf = %s \n\n", dbuf);
    
	return 0;
}
