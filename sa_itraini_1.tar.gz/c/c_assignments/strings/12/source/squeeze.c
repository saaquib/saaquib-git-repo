#include <stdio.h>

void squeeze ( char *str )
{	
	int i;
	int j;

	for( i = 0; i < str_len(str); i++ )
	{
		if( *(str + i) == *(str + i + 1) )
		{
			j = i;
			while( j < str_len(str) )
			{
				*(str + j) = *(str + j + 1);
				j++;
			}
			i = 0;
		}
	}
}
