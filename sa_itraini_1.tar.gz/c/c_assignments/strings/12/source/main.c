#include<header.h>

int main()
{
    	char *str = NULL;
   	int size;
	char num[MAX];  

    	printf("\nEnter the size of array : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);
    	
    	str = (char *) malloc( sizeof(char) * size );
	mem_valid(str);

    	printf("\nEnter the input string 1 : ");
   	fgets( str, size, stdin );
    	rem_enter(str);

	squeeze ( str );

	printf("\nAfter squeeze : %s \n\n", str);

	return 0;
}
