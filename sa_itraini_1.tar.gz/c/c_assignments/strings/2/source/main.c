#include <header.h>

int main()
{
	char *sbuf = NULL;
	char *dbuf = NULL;
	int size;
	char num1[MAX];
	char num2[MAX];
	int n;
	
	printf("\nEnter the size of array : ");
	fgets(num1,MAX,stdin);
	rem_enter(num1);
	size = isvalid(num1);

	sbuf = (char *) malloc( sizeof(char) * size );
	mem_valid(sbuf);	

        dbuf = (char *) malloc( sizeof(char) * size );
	mem_valid(dbuf);

        printf("\nEnter the input string : ");
        fgets( sbuf, size, stdin );
	rem_enter(sbuf);

	printf("\nEnter number of characters to be copied to dbuf : " );
	fgets(num2,MAX,stdin);
	rem_enter(num2);
	n = isvalid(num2);

	strncopy( sbuf, dbuf, n );

	printf("\nAfter copying n bits from sbuf to dbuf = %s \n\n", dbuf);

	return 0;
}
