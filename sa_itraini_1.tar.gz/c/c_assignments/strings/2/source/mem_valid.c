#include<header.h>

void mem_valid(char *str)
{
	if(str == NULL)
	{
		printf("memory is not allocateed");
		exit(0);
	}
}
