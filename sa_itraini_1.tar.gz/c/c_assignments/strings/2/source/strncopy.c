
void strncopy( char *sbuf, char *dbuf, int n )
{
	
	while( n-- && ( *dbuf++ = *sbuf++ ) );
	
	
}
