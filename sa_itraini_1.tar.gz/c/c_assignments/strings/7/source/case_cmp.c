#include<header.h>

int case_cmp( char *str1, char *str2 )
{
	int i;

	for( i = 0; (*(str1 + i) != '\0' && *(str2 + i) != '\0') ; i++ )
	{
		if( (*(str1 + i) - *(str2 + i) == 0 ) || 
				(*(str1 + i) - *(str2 + i) == 32)   							// comparing the strings are equal or not
				|| (*(str1 + i) - *(str2 + i) == -32 ));

		else 									                                // If the strings are of different case then convert into same
		{																		 
			*(str1 + i) = upper( *(str1 + i) );
			*(str2 + i) = upper( *(str2 + i) );

			if(*(str2 + i) > *(str1 + i))                                       //checking for which string is greater
		    	return -1; 
			if(*(str2 + i) < *(str1 + i)) 
				return 1;
		}
		
	}

	return 0;
}
