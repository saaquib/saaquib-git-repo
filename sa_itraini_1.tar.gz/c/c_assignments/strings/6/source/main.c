#include <header.h>

int main()
{
        char *str1 = NULL;
        char *str2 = NULL;
	signed int n;
	char num[MAX];
        int size;

        printf("\nEnter the size of array : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);

        str1 = (char *) malloc( sizeof(char) * size );
	mem_valid(str1);
	str2 = (char *) malloc( sizeof(char) * size );
	mem_valid(str2);

        printf("\nEnter the input string 1 : ");
        fgets( str1, size, stdin );
        rem_enter(str1);
	
        printf("\nEnter the input string 2 : ");
        fgets( str2, size, stdin );
  	rem_enter(str2);

	n = str_cmp( str1, str2 );
	printf("\nResult = %d ",n);

	if( 0 == n )
		printf("\nString 1 and string 2 are equal \n\n" );
	else if( 1 == n )
		printf("\nString 1 is Greater \n\n");
	else 
		printf("\nString 2 is Greater \n\n");

	return 0;
}
