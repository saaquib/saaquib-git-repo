#include<header.h>

void str_rev( char *str, char *rev )

{
	int i;
	int l = str_len( str ) - 1 ;

	for ( i = 0; i < str_len( str ) ; i++, l-- )
	{
		rev[l] = str[i];
	}
	
	rev[i] = '\0';
	
}
