#include <header.h>

int main()
{
        char *str = NULL;
	char *rev = NULL;    
	char num[MAX];    
	int size;

        printf("\nEnter the size of array : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);

	str = (char *) malloc( sizeof(char) * size );
	mem_valid(str);
	rev = (char *) malloc( sizeof(char) * size );
	mem_valid(rev);

        printf("\nEnter the input string : ");
        fgets( str, size, stdin );
        rem_enter(str);

	rev = (char *) malloc( sizeof(char) * size );
	str_rev( str, rev );
	
	printf("\nReverse of given string : %s \n \n",rev);

	return 0;

}
