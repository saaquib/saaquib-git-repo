
int str_spn (const char *str1, const char *str2)
{	
	int i;
	int j;
	int count = 0;

	for( i = 0; i < str_len( str2 ); i++ )
	{	
		if( count != i )
			return count;

		for( j = 0; j < str_len( str1 ); j++ )
		{	
			if( *(str2 + i) == *(str1 + j) )
			{
				count++;
				break;
			}
			
		}
		
	}

	return count;
}
