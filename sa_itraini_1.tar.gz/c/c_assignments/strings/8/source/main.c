#include <header.h>

int main()
{
        char *buf1 = NULL;
        char *buf2 = NULL;
	char num[MAX];
        int size;
	int n;

        printf("\nEnter the size of array : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);

        buf1 = (char *) malloc( sizeof(char) * size );
	mem_valid(buf1);
	buf2 = (char *) malloc( sizeof(char) * size );
	mem_valid(buf2);

        printf("\nEnter the input string 1 : ");
        fgets( buf1, size, stdin );
        rem_enter(buf1);
	
	printf("\nEnter the input string 2 : ");
	fgets( buf2, size, stdin );
	rem_enter(buf2);

	n = str_spn ( buf1, buf2 );
	
	printf("\nResult = %d \n\n",n);

	return 0;
}
