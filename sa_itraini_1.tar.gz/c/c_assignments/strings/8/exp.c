#include<stdio.h>
#include<string.h>

int main(void)
{
	printf("%d \n",strspn("saikiran","ianshk"));

	return 0;
}
