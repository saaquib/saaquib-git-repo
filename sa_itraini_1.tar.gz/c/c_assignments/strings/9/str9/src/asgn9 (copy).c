#include <header.h>

int main()
{
        char *buf1 = NULL;
        char *buf2 = NULL;
	char *token=NULL;
	char num[MAX];			

        printf("\nEnter the size of array : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);

        buf1 = (char *) malloc( sizeof(char) * size );
	mem_valid(buf1);
	buf2 = (char *) malloc( sizeof(char) * size );
	mem_valid(buf2);
	token = (char *) malloc( sizeof(char) * size );
	mem_valid(token);

        printf("\nEnter the input string 1 : ");
        fgets( buf1, size, stdin );
        rem_enter(buf1);
	
	printf("\nEnter Delimeters : ");
	fgets( buf2, size, stdin );
	rem_enter(buf2);
	
	while (*buf1 !='\0') {
    	token = strto(buf1,buf2);
		printf("%s\n",token);
		buf1 = buf1 + str_len(token)+2;
		}

	return 0;
}
