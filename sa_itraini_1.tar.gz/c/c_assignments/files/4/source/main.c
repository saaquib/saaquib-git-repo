#include<header.h>

void main(int argc, char *argv[]) //Taking file name as argument
{
	FILE *fp;
	char ch;
	int count = 0;

	fp = fopen(argv[1],"r");  // Opening File 
	
	if(fp == NULL)             // Checking file opened or not                   
	{                                                                           
		printf("file does not exist");                                          
		exit (1);                                                               
	}  
 
	printf("Input file : \n");
	while((ch = fgetc(fp)) != EOF )  // Printing input file                                                          
	{                                                                                                         
		putc(ch,stdout);                                                        
	}
	rewind(fp);

	while((ch = fgetc(fp)) != EOF )
	{
		if((ch == '\n') || (ch == ' ')) // Checking how many words are there in file by using space
			count++;
	}

	printf("Number of words in given file : %d\n\n",count);
}
