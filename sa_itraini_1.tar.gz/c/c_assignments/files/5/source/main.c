#include"header.h"

void main()
{
	FILE *fp;
	struct EH array[2];
	int i;
	char type[MAX];
	char machine[MAX];
	char version[MAX];
	char entry[MAX];

	for(i = 0; i < 2; i++)
	{
		printf("Enter array %d details\nEnter array[%d].e_ident[16] : ",i,i);
		fgets(array[i].e_ident,16,stdin);
		rem_enter(array[i].e_ident);

		printf("Enter array[%d].e_type : ",i);
		fgets(type,MAX,stdin);
		rem_enter(type);
		array[i].e_type = isvalid(type);

		printf("Enter array[%d].e_machine : ",i);   
		fgets(machine,MAX,stdin);
		rem_enter(machine);                                                         
		array[i].e_machine = isvalid(machine);

		printf("Enter array[%d].e_version : ",i);    
		fgets(version,MAX,stdin);
		rem_enter(version);                                                         
		array[i].e_version = isvalid(version);

		printf("Enter array[%d].e_entry : ",i);   
		fgets(entry,MAX,stdin);
		rem_enter(entry);                                                         
		array[i].e_entry = isvalid(entry);

	}

	fp = fopen("info.db","w+");
	
	if(fp == NULL)
	{
		printf("File doesn't exist");
		exit (1);
	}

	for(i = 0; i < 2; i++)
	{
		fwrite(&array[i],sizeof(struct EH),1,fp);
	}


}
