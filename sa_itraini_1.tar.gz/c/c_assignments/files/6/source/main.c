#include"header.h"

int main()
{
	FILE *fp;
	struct EH array[2];
	int i;
	
	fp = fopen("info.db","r");
	if(fp == NULL)
	{
		printf("file does not exist\n");
		exit(0);
	}

	for(i = 0; i < 2; i++)
	{
		fread(&array[i],sizeof(struct EH),1,fp);
		printf("values of array[%d]\n%s \n %d \n %d \n %d \n %d \n",i,
				array[i].e_ident,array[i].e_type,array[i].e_machine,
				array[i].e_version,array[i].e_entry);
	}

	fclose(fp);
	return 0;
}

