#include<header.h>

void main(int argc, char *argv[]) //Taking file name as argument
{
	FILE *fp;
	char ch;

	fp = fopen(argv[1],"r+");  // Opening File 
	
	if(fp == NULL)             // Checking file opened or not                   
	{                                                                           
		printf("file does not exist");                                          
		exit (1);                                                               
	}  
 
	printf("Input file : \n");
	
	while((ch = fgetc(fp)) != EOF )  // Printing input file                                                          
	{                                                                                                         
		putc(ch,stdout);                                                        
	}
	rewind(fp);   //Making pointer to point begining of file

	while((ch = fgetc(fp)) != EOF )  
	{
		if((ch >= 'A') && (ch <= 'Z'))	// Checking each character to convert
		{			        // into upper case
			ch = ch + 32;
			fseek(fp,-1,SEEK_CUR);
			fputc(ch,fp);		
		}
	}
	
	rewind(fp);   //Making pointer to point begining of file
	
	printf("After Modifing : \n");

	while((ch = fgetc(fp)) != EOF )  // Printing modified file                                                          
	{                                                                                                         
		putc(ch,stdout);                                                        
	}
	
	fclose(fp);
	
}
