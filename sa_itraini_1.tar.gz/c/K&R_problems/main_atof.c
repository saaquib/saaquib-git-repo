#include<stdio.h>
#include<stdlib.h>

#define MAX 32

int main(void)
{
	char num[MAX];   
	double val;

	printf("Enter float number : ");                                       
	fgets(num,MAX,stdin);                                                       

	printf("Before calling atof : %s \n " , num);

	val = myatof(num);

	printf("After calling atof : %lf \n " , val);

	return 0;
}
