#include"header.h"

signed int strrindex(const char *, char);

int main(void)
{
	int size;
	char *str = NULL;
	char num[MAX];
	char ch;
	signed int temp;

	printf("Enter the size of array : ");
	fgets(num,MAX,stdin);
	rem_enter(num);
	size = isvalid(num);

	str = (char*) malloc(sizeof(char) * size);
	mem_valid(str);
	
	printf("Enter string : ");
	fgets(str,MAX,stdin);    

	printf("Enter the character to search : ");
	ch = getchar();

	temp = strrindex(str,ch);
	
	(temp != -1) ? printf("char found at position %d \n", temp) : 
				   printf("char not found \n");

	return 0;

}

signed int strrindex(const char *s, char t)
{
	int i = str_len(s) - 1;

	for(i; 0 <= i; i--)
	{
		if(t == *(s + i))
			return i;
	}

	return -1;

}
