//#include<header.h>

int str_len (const char *str )

{
	int i = 0;
  
        while ( *(str++) )
		i++;
		
	return i;	
}


