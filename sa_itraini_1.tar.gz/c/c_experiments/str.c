#include<stdio.h>

int main()
{
	char *ptr = "hello";
	printf("%c",*ptr);
}
