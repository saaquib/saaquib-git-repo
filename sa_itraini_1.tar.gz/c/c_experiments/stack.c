#include<stdio.h>
#include<stdlib.h>
int main()
{
	int a[5] = {10,20,30,50,60};
	int (*ptr)[5] = &a;	
	int i;
	for(i = 0;i < 5;i++)
		printf("%d\n",(*ptr)[i]);

	return 0;
}
