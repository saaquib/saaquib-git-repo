#include <stdio.h>
#include <stdlib.h>

struct example 
{
	int num;
	char ch;
	float point;
}*p;

int main()
{
	struct example e1 = {9,'a',9.5};
	p = &e1;
	printf("value num =%p\n",&(p->num));
	printf("value ch  =%p\n",&(p->ch));
	printf("value point = %p\n",&(p->point));
	
	return 0;
}
