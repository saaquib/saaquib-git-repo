#include<stdio.h>

#if 0
void showbits(int);
int main ()
{
        int num;
        printf("enter the number : ");
        scanf("%d",&num);
        printf("binary number :");
        showbits(num);

}
void showbits(int n)
{
        int s,r,i;
        int count = 0;
        for (i = 32;i>=1;i--)
        {
                count++;
                r=(1&(n>>(i-1)));
                printf("%d",r);
                if(count%8 == 0)
                printf(" ");
                if((i==32) && (r==1))
                s=r; 
        }
        
       r==0?printf("\ngiven number is even\n"):printf("\n given number is odd \n");
       s==1?printf("\ngiven number is negetive\n"):printf("\n given number is positive \n");
}

#endif



#if 1

void showbits(int);
int main ()
{
        int num;
        printf("enter the number : ");
        scanf("%d",&num);
        printf("binary number :");
        showbits(num);

}
void showbits(int n)
{
        int s,r,i;
        int count = 0;
        for (i = 32;i>=1;i--)
        {
                count++;
                r=(1&(n>>(i-1)));
                printf("%d",r);
                if(count%8 == 0)
                printf(" ");
                if((i==32) && (r==1))
                s=r;
                
        }

       r==0?printf("\ngiven number is even\n"):printf("\ngiven number is odd \n");
       s==1?printf("\ngiven number is negetive\n"):printf("\ngiven number is positive \n");
       
}

#endif
