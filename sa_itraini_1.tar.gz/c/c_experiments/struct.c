#include<stdio.h>

struct a {
	int a;
	struct b *p;
	char ch;

}x;


int main()
{
	x.ch = 80;
	printf("%c\n",x.ch);
	return 0;
}
