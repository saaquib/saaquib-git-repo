#include <stdio.h>

static int i;

int main(void) {
	int j = 20;
	printf("Hello\n");
	printf("%d\n", j);
	printf("%d\n", i);

	return 0;
}
