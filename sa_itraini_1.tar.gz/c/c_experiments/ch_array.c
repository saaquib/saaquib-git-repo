#include <stdio.h>

int main()
{
	char str[] = "welcome";
	printf("\nbefore change str[0] = %c ",str[0]);
        str[0] = 'e';
	printf("\nafter  change str[0] = %c ",str[0]);
	

	return 0;
}
