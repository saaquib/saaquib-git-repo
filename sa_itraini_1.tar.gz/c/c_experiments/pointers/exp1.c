/*# include <stdio.h>
int main ()
{
	int a[] = { 0001, 0010, 0100, 01000 };
	int i;
	for ( i = 0 ; i < 4 ; i++)
		printf("%o\t", a[i]);
	return 0;
}*/
/*
#include <stdio.h>
#define SIZE 10
void size(int arr[10])
{
	 printf("size of array is:%d\n",sizeof(arr));
	      }
     int main()
	     {
			  int arr[10];
			   size(arr);
			    return 0;
				     }*/
/*
#include<stdio.h>
int main()
{
	float arr[] = {12.4, 2.3, 4.5, 6.7};printf("%d\n", sizeof(arr)/sizeof(arr[0]));
	return 0;
}*/
/*
#include <stdio.h>
int main ()
{
	int a[] = { 0001, 0010, 0100, 01000 };
	int i;
	for ( i = 0 ; i < 4 ; i++)
		printf("%d\t", a[i]);
	return 0;
}*/
/*
#include<stdio.h>
#include<stdio.h> 
int main(void)
{
	   int a[2]; a[1] = 3;
	         printf("a[1] = %d\n",a[1]);
			       printf("1[a] = %d\n",1[a]);
				         return 0;
}*/
/*
#include<stdio.h> 
int main() 
{ 
	        static a[3]={1}; 
			        int b[3]={1}; 
					        printf("%d %d",b[1],b[3]); 
}*/

#include <stdio.h>
 
int main() 
	    {  
							     printf("%d\n", sizeof("saikiran"));
								         return 0; 
		}

