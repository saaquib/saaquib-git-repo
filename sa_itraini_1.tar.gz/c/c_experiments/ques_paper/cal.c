#include<stdio.h>

void main()
{
	int a = 10;
	int b = 5;
	int sum = a + b;
	int sub = a - b;
	int div = a / b;
	int mod = a % b;
	
	printf("a = %d \t b = %d\n",a,b);
	printf("addition of a and b : %d\n",sum );
	printf("subtraction of a and b : %d\n",sub );
	printf("division of a and b : %d\n",div );
	printf("modulo division of a and b : %d\n\n",mod );
}
