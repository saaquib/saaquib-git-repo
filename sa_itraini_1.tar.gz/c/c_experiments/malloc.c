#include<stdio.h>
#include<stdlib.h>
int main()
{

	int *p = NULL;
	int i = 0;

	p = (int *)malloc(sizeof(int));
	p++;
	free(p);
	
/*//	for(i = 0; i < 3; i++)
//		p[i] = i;
	*(p + 3) = 20;
	char *q = NULL;

	q = malloc(10);
	for(i = 0; i < 100; i++)
		printf("%d\t",*(p+i));
//	for(i = 0; i < 3; i++)
//		p[i] = i;

	*q = 's';
//	*(p+4)=6;
//int *s=malloc(0);
	printf("%d",*(q+0));*/
	return 0;
}
	
