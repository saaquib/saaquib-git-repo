#include<iostream>
using namespace std;

int main(void)
{

	cout<<"hello";

	return 0;
}
