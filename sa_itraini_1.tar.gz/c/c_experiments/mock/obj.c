#include<stdio.h>

int main(void)
{
	int a[2] = {5};
	int b = 8;
	int *p = &b;

	a[2] = a[2] + 1;

	*p = *p + 1;

	return 0;
}
