#include <stdio.h>
int main ()
{
	int num,pos;
	printf("enter the number : ");
	scanf("%d",&num);
        printf("enter the common position to set,clear,toggle : ");
        scanf("%d",&pos);
        printf("number after set the %dth bit : %d\n ",pos,num|(1<<pos-1));
        printf("number after clear the %dth bit : %d\n ",pos,(num&(~(1<<(pos-1)))));
        printf("number after toggle the %dth bit : %d\n",pos,num^(1<<(pos-1)));

}
