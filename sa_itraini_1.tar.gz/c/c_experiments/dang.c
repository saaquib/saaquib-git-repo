#include<stdio.h>
#include<stdlib.h>
void fun();
int main()
{
	fun();
	int *p;
	printf("%d\n",*p);
	return 0;
}

void fun()
{
	int a = 5;
	printf("%d\n",a);
}
