#include<stdio.h>

struct batch                                                                
{                                                                         
	char b_id[10];                                                        
	char name[20];                                                      
	int emp_id;                                                             
									                                                                               
};   

int main()

{
	struct batch cr = {"CR-17","SAI KIRAN",30867};
	struct batch br = {"CR-17","SAAQUIB",30860};
	struct batch college[10] = {"CR-17","SHANKAR",30863};

	printf("Cr structure b_id = %s \t name = %s \t emp_id = %d \n\n",cr.b_id,cr.name,cr.emp_id);
	printf("Br structur b_id = %s \t name = %s \t emp_id = %d \n\n",br.b_id,br.name,br.emp_id);
	printf("college[0] structur b_id = %s \t name = %s \t emp_id = %d \n\n",college[0].b_id,college[0].name,college[0].emp_id);
	printf("size of structure cr = %d \n\n",sizeof(cr));

	return 0;

}

