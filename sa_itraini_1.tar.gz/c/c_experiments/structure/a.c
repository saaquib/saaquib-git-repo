#include<stdio.h>
#include<string.h>
int main()
{
	    struct emp
			    {
					        char n;
							        int age;
									    };
		    struct emp e1 = {'a', 23};
			    struct emp e2 = e1;
				printf("%c %d",e2.n,e2.age) ;   
				toupper(e2.n);
					    printf("%c\n", e2.n);
						    return 0;
}
