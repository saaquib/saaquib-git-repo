#include<stdio.h>
int main()
{
		int a=10;
		int b=20;
		printf("%d",b);
		return 0;
}
