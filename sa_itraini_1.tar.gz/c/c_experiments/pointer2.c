#include<stdio.h>

int main ()
{
	int a[3] = {563,78,35};

	printf("\n%p",a);
        printf("\n%p",&a);
        printf("\n%d",a[0]);
        printf("\n%d",*a);
        
        printf("\n%p",(a+1));
        printf("\n%d",a[1]);
	printf("\n%d",*(a+1));

	printf("\n%d",a[2]);
	printf("\n%p",(a+2));
	printf("\n%d",*(a+2));
        
        printf("\n %d",*(a+1)-(*(a+2)));
	return 0;
}
