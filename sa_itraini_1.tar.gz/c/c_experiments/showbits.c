#include<stdio.h>

void showbits(int);
int main ()
{
	int num;
        printf("enter the number : ");
	scanf("%d",&num);
        printf("binary number :");
        showbits(num);
        
}
void showbits(int n)
{
        int r,i;
        int count = 0;
        for (i = 32;i>=1;i--)
	{	
		count++;
		r=(1&(n>>(i-1)));
                printf("%d",r);
                if(count%8 == 0)
                printf(" ");
                
	}
}
