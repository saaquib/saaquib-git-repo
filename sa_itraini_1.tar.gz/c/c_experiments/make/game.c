#include"stdio.h"
extern int a;

//static int b = 5;
int main(int argc, char *argv[])
{
/*	const int c= 5;*/
	int a = 4;
/*	auto int d = 7; 
	register int e = 5;*/
	printf("a = %d a = %d\n",a++,++a);
/*	printf("b = %d",b);
	printf("d = %d",d);
	printf("c = %d",c);
	printf("e = %d",e);*/
		char ch;
	FILE *fp;
		if((fp = fopen(argv[1],"r")) != NULL)
		while(ch != EOF)
		{
			ch = fgetc(fp);
			printf("%c", ch);
		}
		return 0;
}
	

