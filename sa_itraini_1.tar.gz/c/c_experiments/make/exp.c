#include<stdio.h>
hello()
{
	int a = 1;
	printf("%d \n",a);
}
