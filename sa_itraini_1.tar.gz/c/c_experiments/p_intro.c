#include <stdio.h>

                                               /** pointers introduction **/
int main()
{
  	int a;
        int *p = NULL ;
	int **s = NULL; // double pointer
	p = &a;
	s = &p;	
 
        printf("Enter the number : ");
        scanf("%d",&a);
        
	printf("Value in 'a' : %d",a);
        printf("\nAddress of 'a' stored in pointer 'p' :%p ",p);
        printf("\nValue in 'a' through pointer 'p' : %d",*p);
        printf("\nAddress of 'p' pointer : %p",&p);
        printf("\nAddress of pointer 'p' stored in double pointer 's' :%p",*s);
        printf("\nAddress of double pointer 's' : %p",&s);
        printf("\nValue of 'a' through double pointer 's' : %d",**s);
    
	return 0;

}

