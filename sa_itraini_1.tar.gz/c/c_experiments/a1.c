#include<stdio.h>
#if 0

void fun();
void main()

{
        register int reg=78;
        auto int i=10;
     
        printf("\n register : %d",reg);
        printf("\n local in main  : %d",i);
        
        fun();
        fun();
}

void fun()
{
        auto int i=258;
	static stat = 20;
        printf("\n local in fun()  : %d",i);
        printf("\n static value %d ",stat);
        stat ++;
        printf("\n static value after change :%d",stat);
}
#endif
#if 0
void main()
{
	int a = 10;
	int b = 5;
	int l = a<<1;
	int r = a>>1;
	printf("\n left shift of 10 is : %d ",l);
	printf("\n right shift of 10 is : %d ",r);
	printf("\n and operation of 10, 5 is : %d ",a&b);
	printf("\n OR operation of 10, 5 is : %d ",a|b);
	printf("\n XOR operation of 10, 5 is : %d ",a^b);
	printf("\n NOT operation of 10 is : %d \n ",~a);    
}
#endif
#if 0
void main()
{
	int a,b,op;
        printf("enter the first  number :");
 	scanf("%d",&a);
        printf("enter the second  number :");
        scanf("%d",&b);
        
        printf("\n select the operation as follows \n \t 1 for adition \t 2 for subtraction \t 3 for division \t 4 for multiplication \n Your selection is : ");
        scanf("%d",&op);
	switch (op)
{
        case 1:printf("addition result %d\n",a+b);
	break;
        case 2:printf("subtraction  result %d\n",a-b);
        break;
        case 3:printf("division  result %d\n",a/b);
        break;
        case 4:printf("division  result %d\n",a*b);
        break;
        default :printf("you selected wrong option\n");

}
}
#endif

#if 1
// show bits program
void showbits(int );    
void main()
{
	int decimal;
	printf("\n enter the decimal value : ");
	scanf("%d",&decimal);
        showbits(decimal);
        

}
void showbits(int d)
{
	int r;
        int mask= 1;
        int i=32;
        int b[32];
        
 	printf("\n given decimal in binary :  ");       
        while (i)
{       r = d&mask;
        mask = mask<<1;
        b[i-1] = r==0?0:1;
        i--;
}
	for(;i<=31;i++)
	{
        	if((i%8)==0)
        		printf(" ");
		printf("%d",b[i]);
	}
	printf("\n");
}
#endif
      
