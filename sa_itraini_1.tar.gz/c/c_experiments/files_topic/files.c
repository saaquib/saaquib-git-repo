#include<stdio.h>
#include<stdlib.h>

#if 0
int main()
{
	FILE *fp;
	char *ch1 = NULL;

	
	ch1 = (char*) malloc(100);

	fp = fopen("psk.txt","w+");
	
	if(fp != NULL )
		printf("file is created\n");
	else
		perror("file is not created\n");

	printf("enter string :" );
	fgets(ch1,50,stdin);
	fprintf(fp,"%s \n",ch1);
	
	fclose(fp);
	return 0;

}
#endif

#if 1
int main()
{
	int a;
	int b;

	scanf("%d%d",&a,&b);
	printf("%d  %d",a,b);

	return 0;
}


#endif
