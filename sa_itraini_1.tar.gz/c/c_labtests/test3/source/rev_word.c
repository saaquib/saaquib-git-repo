#include<header.h>

void rev_word(char *str, char *rev)
{
	int i = str_len(str);
	int j;
	static int k = 0;
	static int first = 1;
		
	while(i >= 0)
	{
		
		if((' ' == *(str + i)) && (first == 1) )
		{
			first++;

			for(j = i + 1; ( *(str + j ) != '\0' ); j++, k++)
			{
				*(rev + k) = *(str + j);
            }
			*(rev + k) = ' ';
			k++;
			i--;
		}
	      
		if((' ' == *(str + i)) && (first != 1))
		{
			for(j = i+1; *(str + j) != ' '; j++, k++)    
			{                                                               
				*(rev + k) = *(str + j);                                
			}
			*(rev + k) = ' ';
			k++;
			i--;   		
        }
		
		if(0 == i)
		{
			for(j = 0; *(str + j) != ' '; j++, k++)                           
			{                                                                   
				*(rev + k) = *(str + j); 
		    }
		}
		i--;
	}
}	


