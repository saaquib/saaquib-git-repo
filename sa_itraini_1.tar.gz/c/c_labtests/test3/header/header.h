#include<stdio.h>
#include<stdlib.h>

extern void rev_words( char *, char* );
extern int str_len( char * );

