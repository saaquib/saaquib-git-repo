#include<header.h>

char upper( char ch )
{
	if( ch >= 'a' && ch <= 'z' )
		ch = ch - 32;

	return ch;
}
