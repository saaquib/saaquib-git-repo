#include<stdio.h> 
#include<string.h> 
#include <unistd.h> 
#include<stdlib.h> 
#include <sys/types.h>

int main(void)
{
	
//	char msg[10];
	char temp;
	pid_t pid;
	int fd[2];
		        
	if(pipe(fd) < 0)  {

		perror("pipe creation failed ");
		exit(EXIT_FAILURE);
	}

/*	printf("Enter message to send to child using pipe : ");                 
	
	if(NULL == fgets(msg,10,stdin)) {                                       

		perror("fgets failed ");                                            
		exit(EXIT_FAILURE);                                                 
	} 
*/
	pid = fork();
	
	if(-1 == pid ) {
		
		perror("fork failed");
		exit(EXIT_FAILURE);
	}

	if(pid > 0) {  // parent process writing msg into pipe

		printf("******** In Parent process ********** \n");
		close(fd[0]);          /* Close unused read end */
		
	/*	if(0 < */write(fd[1],"hello child \n", 13);
//			printf("Message sent in pipe successfully");
		
	close(fd[1]);
	wait(NULL);
	printf("Exiting parent \n");

	} else {
		
		printf("******** In Child process ********** \n");
		printf("Reading message from pipe : "); 
		close(fd[1]);
		while (read(fd[0], &temp, 1) > 0)
			write(STDOUT_FILENO, &temp, 1);
	//	printf("Reading message from pipe : ");
		printf("\n");
		printf("Exiting Child \n");
		close(fd[0]);
		exit(0);
	}

	return 0;

}

