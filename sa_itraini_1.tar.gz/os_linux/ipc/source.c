#include<stdio.h>                                                               
#include<string.h>                                                              
#include <unistd.h>                                                             
#include<stdlib.h>                                                              
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

int main(void)
{
	int status;
	int fd;
	char str[20];
	
	printf("Enter string to send through pipe : ");

	status = mkfifo("./mypipe",0644);

	if(0 > status) {

		perror("mkfifo failed ");
		exit(EXIT_FAILURE);
	}

	fd = open("./mypipe",O_WRONLY);

	fgets(str,20,stdin);
	write(fd,str,20);

	close(fd);

	unlink("./mypipe");

	return 0;

}

	
		

	
