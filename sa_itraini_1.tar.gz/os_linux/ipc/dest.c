#include<stdio.h>
#include <unistd.h>                                                   
#include<stdlib.h>                                                    
#include <sys/types.h>                                                
#include <sys/stat.h>
#include <fcntl.h>

int main(void)
{
	int fd;
	char str[20];

	fd = open("./mypipe",O_RDONLY);
	
	read(fd,str,20);


	printf("In destination recieved msg in pipe : %s \n",str);
	close(fd);

	return 0;
}
