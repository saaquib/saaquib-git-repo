#include<stdio.h>  
#include<string.h>
#include <unistd.h>                                                             
#include<stdlib.h>                                                              
#include <sys/types.h>                                                          
#include <sys/stat.h>                                                           
#include <fcntl.h>
#include <mqueue.h>
#include <time.h>

#define MAX 100

int main(int argc, char *argv[])
{
	char *send = NULL;
	char *rec = NULL;
	mqd_t status;
	struct mq_attr attr;
	int st;

	if(argc != 2) {
		
		perror("Arguments error");
		exit(1);
	}

	status = mq_open(argv[1],O_CREAT | O_RDWR,0666,NULL);

	if(status == -1) {

		perror("mq_open failed");
		exit(1);
	}

	send = (char *)malloc(MAX);

	mq_getattr(status,&attr);
	rec = (char *)malloc((attr.mq_msgsize) + 1);
	while(1) {	
		
		printf("\n\t\t\tTo Jerry -> ");
		fgets(send,MAX,stdin);

		if(strcmp(send,"bye\n") == 0)
			break;

		st = mq_send(status,send,strlen(send),0);

		if(st == -1) {                                                          
		                                                                                
			perror("mq_send failed");                                               
			exit(1);                                                                
		}

		st = mq_receive(status,rec,(attr.mq_msgsize) + 1,0);
		if(st == -1) {

			perror("mq_receive failed");
			exit(1);
		}
		
		printf("From Jerry : %s \n",rec);

	}
	mq_close(status);

	return 0;
}





