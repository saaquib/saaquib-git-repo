/*shared memory
	-> shm_overview
	-> shm_open - create/open shared memory object
	-> mmap/munmap - map/unmap files/devices into memory
	-> ftruncate - regular file referenced by fd to be truncated to a specific size 
	-> memcpy
	-> time()
*/

#include<stdio.h>
#include<stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include<string.h>
#include<fcntl.h>
#include<semaphore.h>

int main()
{
	int status;
	int fd;
	int a[10];
	int i = 0; 
	sem_t *sem;

	if(-1 == (fd = (shm_open("/myshm",O_RDWR,0777)))) { /*open shared memory object*/
		
		perror("shm_open failed");	
		exit(EXIT_FAILURE);
	}
	
	sem = sem_open("/sem",O_RDWR);
	
	if(sem == SEM_FAILED) {                                                             
		
		perror("sem_open failed");                                              
		exit(EXIT_FAILURE);                                                     
	}

	int *ptr = (int *) mmap(NULL,4096,PROT_READ | PROT_WRITE,MAP_SHARED,fd,0);/*map shared memory into VAS of calling process*/ 
	
	if(ptr == MAP_FAILED) {	
	
		perror("mmap failed");
		exit(EXIT_FAILURE);
	}
	
	sem_wait(sem);

	memcpy(a,ptr,sizeof(a)); 
	
	sem_post(sem); 

	printf("-----------Before-----------\n");
	for(i = 0; i < 10; i++) {

		printf("%d \n",a[i]);
	
	}

	sem_wait(sem);

	memset((void *)ptr,0,sizeof(a));
	memcpy(a,ptr,sizeof(a));
	
	sem_post(sem); 

	printf("------------After------------\n");
	for(i = 0; i < 10; i++) {                                                   
		printf("%d \n",a[i]);                                                   
	}		                                                                                 
				     
	close(fd);

	return 0;

}
