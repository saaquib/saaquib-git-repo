#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

int a = 5;
int main()
{
	int fd;
	printf("%d\n",getpid());
	fd = open("/dev/myChar",O_RDWR);
	if(fd < 0)
		perror("unable\n");
	else
		printf("opened\n");

	printf("before ioctl : %d \n",a);

	ioctl(fd,getpid(),&a);

	printf("after ioctl : %d \n",a);
	getchar();
	close(fd);
	return 0;
}
