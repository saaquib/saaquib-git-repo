#include<stdio.h>
#include<fcntl.h>

int a = 15;
int main()
{
	int fd;
	fd = open("/dev/myChar",O_RDWR);

	printf("address : %p ",&a);
	if(fd<0)
		perror("unable to open the device");
	else
		printf("file opened successfully %d\n", fd);

	ioctl(fd,getpid(),10,&a);	

	close(fd);

	return 0;
}
