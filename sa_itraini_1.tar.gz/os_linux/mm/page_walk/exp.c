#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int j = 15;

int main(void)
{
	int a = 10;
	printf("j = %d",j);
	printf("Hello a = %d\t%x\t %d\n",a,&j,getpid());

	getchar();

	printf("j = %d",j);
	return 0;
}
