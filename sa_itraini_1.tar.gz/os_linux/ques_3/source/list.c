#include"stdio.h"
#include"stdlib.h"

typedef struct link {
	
	struct link *next;
	struct link *prev;
}link;

typedef struct task {
	
	long state;
	int pid;
	int flags;
	int prio;
	unsigned char fpu_counter;
	struct link tasks;
	char rcu_read;
	int tgid;
	char comm[16];
	unsigned int rt_prio;
}task;

int main(void) {

	
	task tk;
	task pk;
	unsigned int p = (&tk.prio);
	unsigned int s = (&tk);
	unsigned int c = (p - s);
	unsigned int e = (&pk.prio);
	unsigned int d = e - c;
	task *obj;

	obj = (task *)d;

	
	
/*	printf(" pk %p\n",&tk);
        printf(" pk.prio %p \n",&tk.prio);*/
	printf(" pk %p\n",&pk);
	printf(" pk.prio %p \n",&pk.prio);
	printf(" diff in tk %p \n",c);
	printf(" address %p ",obj);
	printf(" address %p ",&(obj -> state));
	printf(" address %p ",&(obj -> pid));
//	printf("%p\n",c);
	//printf("address %p \n",/*(&tk.tasks) - */(&tk.tasks) - (&tk));

	printf(" %d \n", getpid());
	getchar();
	return 0;
}
