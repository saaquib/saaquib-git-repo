#include<stdio.h>
#include<stdlib.h>

int main(void)
{
/*	FILE *fp;

	fp = fopen("just.txt","w");
*/
	pid_t pid;

	pid = vfork();
	
	//  wait();
	if(pid > 0)  
	{
	
		printf("....In parent.....\n");	
		printf("pid %d\n",pid);
		printf("get pid %d\n", getpid());
		printf("get ppid %d\n", getppid());

/*		fputs("Global Edge ",fp);
		fclose(fp);
*/		
		getchar();
		printf("Exiting Parent process \n");

	}
	else if(pid == 0)
	{                                                                           
		printf("....In child.....\n");                                      
		printf("pid %d\n",pid);                                             
		printf("get pid %d\n", getpid());
		
/*		fputs("Software ltd. ",fp);                                                    
		fclose(fp);                                                       
*/		
		getchar();                                                              
		printf("Exiting Child Process \n");
	}

	return 0;
}


