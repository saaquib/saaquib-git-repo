#include<stdio.h>

int main(void)
{
	printf("Hi %d\n",getpid());
	getchar();

	return 0;
}
