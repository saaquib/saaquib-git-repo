#include<stdio.h>

int main(void)
{
	int a = 20;
	int b = 40;
	
	if(a>0){
		int	c = 30;
	printf("%d \n",a);
}

	printf("a = %d\n",c);

	return 0;
}

