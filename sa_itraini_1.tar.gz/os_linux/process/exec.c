#include<stdio.h>
#include<stdlib.h>                                                              
#include<unistd.h>
#include<sys/types.h>

int main(void)
{
	int h;
	printf("Hello %d \n ", getpid());

	getchar();
	
	h = execl("./a.out","a.out",NULL);
	printf("h = %d \n ",h);

	return 0;
}
