

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main ()
{
    pid_t pid;
    pid = vfork();
	int a;
	
    if (pid > 0)
    {
        printf ("parent process executing....\n");
        wait (&a);
		printf ("%d\n", a);
    }
    else if(pid == 0)
    {
        printf ("child process executing....\n");
        if(-1 == execlp("ls","shell", NULL)) {// sh is exexcutable name for shell
            printf ("exec failed\n");
            exit (0);
        }
		exit (0);
    }

    else
        printf ("process is not created\n");

}

