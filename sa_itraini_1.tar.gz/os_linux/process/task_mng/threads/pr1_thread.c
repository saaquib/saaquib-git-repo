

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/syscall.h>
void *thread1 (void *arg)
{
    printf ("hiiiiiiii\n");
    printf ("thread1 getpid = %d\t", getpid());
}



int main()
{
    int err;
    pthread_t t_id;

    printf ("we are in main thread\n");

    err = pthread_create (&t_id, NULL, thread1, NULL);
    if (err != 0)
        printf ("thread is not cread\n");
    else
        printf ("thread is created\n");

    printf ("parent getpid= %d\t", getpid());

}
