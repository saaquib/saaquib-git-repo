/*#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <error.h>
*/
#include"header.h"
void *thread_fun(void *arg)
{
	struct sched_param prio;

	int i;
	int p;

	// before setting prio ad policy
	p = pthread_getschedparam(pthread_self(), &i, &prio);
	if(p != 0)
		err_abort(p,"child pthread1 is failed\n");

	if(i == SCHED_OTHER)
		printf("1sed_attr_setinheritschedhed_other\n");
	else if (i == SCHED_FIFO)
		printf ("sched_fifo\n");
	else
		printf ("sched_rr\n");

	printf("3priority %d\n",prio.sched_priority);

	prio.sched_priority = 94;

	p = pthread_setschedparam(pthread_self(), SCHED_RR, &prio);
	if(p != 0)
		err_abort(p,"child pthread2 is failed\n");

	//after setting prio and       
	p = pthread_getschedparam(pthread_self(), &i, &prio);
	if(p != 0)
		err_abort(p,"child pthread2 is failed\n");

	if(i == SCHED_OTHER)
		printf("1sed_attr_setinheritschedhed_other\n");
	else if (i == SCHED_FIFO)
		printf ("sched_fifo\n");
	else
		printf ("sched_rr\n");
	printf("4priority %d\n",prio.sched_priority);

	return NULL;
}

int main()
{
	pthread_t thr;
	pthread_attr_t attr ;
	int j;

	struct sched_param prio;
	int i;

	int p;

	p = pthread_attr_init(&attr);

	if(p != 0)
		err_abort(p,"pthread init is failed\n");



	// policy and prio before set
	p  = pthread_getschedparam(pthread_self(), &i, &prio);
	if(p != 0)
		err_abort(p,"pthread gets is failed\n");
	if(i == SCHED_OTHER)
		printf("1sed_attr_setinheritschedhed_other\n");
	else if (i == SCHED_FIFO)
		printf ("sched_fifo\n");
	else
		printf ("sched_rr\n");
	printf("1priority %d\n",prio.sched_priority);

	prio.sched_priority = 10;//setting prio
	p = pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
	if(p != 0)
		err_abort(p,"pthread inheri is failed\n");

	//setting prio and policy
	p = pthread_attr_setschedpolicy(&attr, SCHED_OTHER);
	if(p != 0)
		err_abort(p,"pthread setpolicy is failed\n");
	p = pthread_attr_setschedparam(&attr, &prio);
	if(p != 0)
		err_abort(p,"pthread setsced is failed\n");

	//policy and prio after setting
/*	p = pthread_getschedparam(pthread_self(), &j, &prio);
	if(p != 0)
		printf("pthread is failed\n");

	if(i == SCHED_OTHER)
		printf("1sed_attr_setinheritschedhed_other\n");
	else if (i == SCHED_FIFO)
		printf ("sched_fifo\n");
	else
		printf ("sched_rr\n");
	printf("2priority %d\n",prio.sched_priority);

*/
	//creation of thread
	p = pthread_create(&thr, &attr, thread_fun, NULL);
	if(p != 0)
		printf("creation of thread is failed\n");


	pthread_exit(NULL);
	return 0;
}
