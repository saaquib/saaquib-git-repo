#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <error.h>

void *thread_fun(void *arg)
{
	pthread_attr_t gattr;
	struct sched_param prio;
	
	int s;
	int i;
	int p;


/* p = pthread_attr_setinheritsched(&gattr, PTHREAD_EXPLICIT_SCHED);
    if(p != 0)
        printf("pthrakhed is failed\n");
*/	
//  p = pthread_setschedparam(pthread_self(), SCHED_FIFO, &prio);

//	s = pthread_getattr_np(pthread_self(), &gattr);

	// before setting prio ad policy
	 s = pthread_getschedparam(pthread_self(), &i, &prio);
    if(i == SCHED_RR)
        printf("3sched_rr\n");
    printf("3priority %d\n",prio.sched_priority);

	 prio.sched_priority = 94;
    
  p = pthread_setschedparam(pthread_self(), SCHED_FIFO, &prio);
  //after setting prio and       
	s = pthread_getschedparam(pthread_self(), &i, &prio);
	if(i == SCHED_FIFO)
		printf("4sched_fifo\n");
	printf("4priority %d\n",prio.sched_priority);

	return NULL;
}

int main()
{
	pthread_t thr;
	pthread_attr_t attr;
	pthread_attr_t *attrp;
	struct sched_param prio;
	int i;
	int j;

	prio.sched_priority ;

	int p;

	attrp = NULL;

	attrp = &attr;
	p = pthread_attr_init(&attr);
	
	if(p != 0)
		printf("pthraed is failed\n");



/*	p = pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
	if(p != 0)
		printf("pthrakhed is failed\n");

*/	
	// policy and prio before set
/*	p  = pthread_getschedparam(pthread_self(), &i, &prio);
    if(i == SCHED_OTHER)
        printf("1sched_other\n");
    printf("1priority %d\n",prio.sched_priority);
*/
	prio.sched_priority = 107;//setting prio
	//setting prio and policy
	p = pthread_setschedparam(pthread_self(), SCHED_RR, &prio);
	//policy and prio after setting
    p = pthread_getschedparam(pthread_self(), &j, &prio);
    if(j == SCHED_RR)
        printf("2sched_rr\n");
    printf("2priority %d\n",prio.sched_priority);

	if(p != 0)
		printf("pthraed is failed\n");

	//creation of thread
	p = pthread_create(&thr, NULL, thread_fun, &p);
	if(p != 0)
		printf("pthread is failed\n");

	
	pthread_exit(NULL);
	return 0;
}
