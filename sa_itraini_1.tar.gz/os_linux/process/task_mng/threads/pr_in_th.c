

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/syscall.h>

void *thread2 (void *arg)
{
	printf ("hii..\n");
	pid_t pid;
	    pid = fork();
    if (pid > 0)
    {
        wait (NULL);
        printf ("parent process in main process...\n");
        printf ("pid = %d\n",pid);
        //wait (NULL);
        printf ("parent = %d\n", getpid());
    }
    else if (pid == 0)
    {
        printf ("child process in main process...\n");
        printf ("child = %d\n", getpid());
    }
    else
        printf ("fork failed\n");

	 printf ("hiiiiiiii\n");
   printf ("thread2 getpid = %d\t", getpid());
    getchar();
}


int main ()
{
	int err;
    pthread_t t_id;
    //pid_t pid;

	err = pthread_create (&t_id, NULL, thread2, NULL);
	pthread_exit(NULL);
    if (err != 0)
        printf ("thread is not cread\n");
    else
        printf ("thread is created in thread...\n");


}
