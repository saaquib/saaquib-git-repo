

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/syscall.h>

void *thread2 (void *arg)                                        
{                                                                       
    printf ("hiiiiiiii\n");
	printf ("thread2 getpid = tgid: %d\t", getpid());
    printf ("thread2 gettid = pid:%ld\t", syscall(SYS_gettid));
    printf ("thread2 getppid = ppid:%d\n", getppid());

	getchar();
}
void *thread1 (void *arg)
{
	int err;
	pthread_t t_id;
	pid_t pid;
/* process creation inthread...*/
	printf ("in thread....");
	pid = fork();
	if (pid > 0)
	{
		wait(NULL);
		printf ("parent proces in thread...\n");
		printf ("thread1 getpid =tgid: %d\t", getpid());
    	printf ("thread1 gettid = pid:%ld\t", syscall(SYS_gettid));
    	printf ("thread1 getppid = ppid:%d\n", getppid());

	}
	else if (pid == 0)
	{
		printf ("child process in thread....\n");
		printf ("thread1 getpid = tgid:%d\t", getpid());
    printf ("thread1 gettid = pid:%ld\t", syscall(SYS_gettid));
    printf ("thread1 getppid = ppid:%d\n", getppid());

	}
	else
		printf ("fork failed\n");
/* thread creation in thread....*/

	getchar();
	err = pthread_create (&t_id, NULL, thread2, NULL);                  
	if (err != 0)                                                       
		printf ("thread is not cread\n");                               
	else                                                                
		printf ("thread is created in thread...\n");  
	pthread_exit(NULL);
}



int main()
{
	int err;
	pthread_t t_id;
	pid_t pid;                                                          
	/* process creation in process.....*/
	
	printf ("main process in executing....\n");

	pid = fork();    
	if (pid > 0)
	{
		wait (NULL);
		printf ("parent process in main process...\n");
		printf ("parent process  getpid = tgid:%d\t", getpid());
    printf ("parent process  = pid:%ld\t", syscall(SYS_gettid));
    printf ("parent process  = ppid:%d\n", getppid());

	}
	else if (pid == 0)
	{
		printf ("child process in main process...\n");
		printf ("child process getpid = tgid:%d\t", getpid());
    	printf ("child process gettid = pid:%ld\t", syscall(SYS_gettid));
  	  	printf (" child process getppid = ppid:%d\n", getppid());

	}
	else
		printf ("fork failed\n");


	getchar();
	err = pthread_create (&t_id, NULL, thread1, NULL);
	if (err != 0)
		printf ("thread is not cread\n");
	else
		printf ("thread is created in process\n");

	pthread_exit(NULL);
	return 0;
}

