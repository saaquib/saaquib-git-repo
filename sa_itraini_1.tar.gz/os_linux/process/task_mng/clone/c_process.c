

/*#include <sched.h>
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
*/

#define SIZE 1024
#include"header.h"
int process(void *p)
{

//	va_list valist;
//	va_start(valist, num);
//	a = va_arg(valist,int);
	

//	a = a + 4;
	printf ("child process\n");
	//va_end(list);
	exit(0);
}


int main()

{
	int a=4;
	int ret;
	void* stack;
    stack = (char *)malloc( SIZE );	
	ret = clone (&process, stack + SIZE,CLONE_VM,NULL);
	if (ret == -1)
		errno_abort("clone failed\n");
	getchar ();
	printf ("main a = %d\n", a);
//	err_abort(ret,"clone faled\n");
	printf ("main process\n");

}



