#include <stdio.h>

int main()
{
	volatile int a = 10;
	int b= 10;

	printf ("%d\t%d\t%d\t%d", ++a,a++,a,++a);
	printf ("%d\t%d\t%d\t%d", ++b,b++,b,++b);

}
