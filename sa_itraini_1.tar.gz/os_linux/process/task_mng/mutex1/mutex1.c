
#include<time.h>
#include"header.h"                                                              
typedef struct insrt_node {                                                      
	char msg[100];                                                              
	int sec;                                                                   
	struct insrt_node *next;                                                     
}NODE;                                                                           

struct mutex_tag {
	pthread_mutex_t lock; 
	pthread_cond_t cond1;
	pthread_cond_t cond2;
	NODE * first;                                                    
}mutex={.lock = PTHREAD_MUTEX_INITIALIZER, .cond1 = PTHREAD_COND_INITIALIZER, .cond2 = PTHREAD_COND_INITIALIZER,.first=NULL};

//mutex.first =NULL;
time_t t;
struct timespec t_out;
int s;

char line[100];                                                             
char str[100];


void insert_node (NODE *new)
{
	NODE *cur = mutex.first;
	// if i am entering 1st node
	if (cur == NULL) {
//		printf("list is empty\n");
		mutex.first = new;
		new->next = NULL;
		s = pthread_cond_signal(&mutex.cond1);                                       
	}
	else {//inserrtting node in ascending order
		while (cur != NULL) {
			if (cur->sec > new->sec ) {
				new->next = cur->next;
				mutex.first = new;
				
				s = pthread_cond_signal(&mutex.cond2);//notify cond2
				break;
			}
			else if (cur->sec < new->sec && cur->next->sec > new->sec){
				new->next = cur->next;
				cur->next = new;
				s = pthread_cond_signal(&mutex.cond2);//notify cond2
				break;
			
			}
			else if (cur->next == NULL) {
				new->next = cur->next;
				cur->next = new;
				break;
			}
			cur = cur->next;
		}

	}	            
	printf ("1st node=%d\n", mutex.first->sec);
}

void thread(void *p)                                                            
{                                                                               
	NODE *cons = NULL;
	NODE *prev = NULL;

	while (1) {
	printf ("thread2\n");
	if (NULL == (prev = (NODE *)malloc (sizeof(NODE)))) {
		errno_abort("maloloc failed\n");	
		exit (0); 
	}
	if (NULL == (cons = (NODE *)malloc (sizeof(NODE)))) {
		errno_abort("maloloc failed\n");	
		exit (0); 
	}

	s = pthread_mutex_lock(&mutex.lock);                                       
	if (s != 0)                                                                 
		err_abort(s,"mutex lock failed\n");                                     

	cons = mutex.first;//assigning 1st node
	//printf ("cons=%d\n",cons->sec);
	printf ("thread3\n");	
	if (cons == NULL){
		printf ("thread4\n");
		pthread_cond_wait(&mutex.cond1, &mutex.lock);
	}
	else {
		
		mutex.first = mutex.first->next;
		
		s = pthread_mutex_unlock(&mutex.lock);                                     
		if (s != 0)                                                                 
			err_abort(s,"mutex unlock failed\n");       
		printf ("else in thread5\n");
		printf ("cons=%d\n",cons->sec);
		t_out.tv_sec = cons->sec;//time calculation 

		printf ("tv_sec= %d\n",t_out.tv_sec);
		
		//deleting the node		
		prev = cons;//assigning 1st node to prev
		printf ("hii\n");//deletetion of 1st node
		free(cons);
		cons = NULL;    

		s = pthread_mutex_lock(&mutex.lock);                                       
		if (s != 0)                                                                 
			err_abort(s,"mutex lock failed\n");        
                             
		s = pthread_cond_timedwait(&mutex.cond2,&mutex.lock,&t_out);
		if (s == ETIMEDOUT)	{
			printf ("[%d] %s\n", prev->sec, prev->msg); 
		}
		else {
			
			s = pthread_mutex_lock(&mutex.lock);                                       
			if (s != 0)                                                                 
			err_abort(s,"mutex lock failed\n");   
                                  
			insert_node(prev);//reinsert the curnode
		}
		s = pthread_mutex_unlock(&mutex.lock);                                     
		if (s != 0)                                                                 
			err_abort(s,"mutex unlock failed\n");       
	}		
	}
}



int main ()                                                                     

{                                                                               
	pthread_t thr;                                                              
	NODE *new = NULL;	


	s = pthread_create(&thr, NULL, thread, NULL);                               
	if (s != 0)                                                                 
		err_abort(s,"thread creation failed\n");                                

	while(1) {                                                                  

		printf ("alaram..");                                                    

		if (NULL ==(fgets(line, sizeof(line), stdin))) {                        
			printf ("fgets failed..\n");                                        
			exit (0);                                                           
		}                                                                       
		if (strlen (line) <= 1) continue;                                       

		if (NULL == (new = (NODE *)malloc (sizeof(NODE)))) {
			errno_abort("maloloc failed\n");	
			exit (0); 
		}

		if (sscanf(line, "%d %64[^\n]", &new->sec, str) < 2)                      
			fprintf (stderr, "bad command\n");     
		strcpy(new->msg,str);
		t = time(NULL);
		printf ("abt=%d\n",t);
		new->sec = t + new->sec;


		s = pthread_mutex_lock(&mutex.lock);                                       
		if (s != 0)
			err_abort(s,"mutex lock failed\n");                                     		
		else {          
			
			insert_node(new);
			printf ("main thread\n");
		}                                                                           
		s = pthread_mutex_unlock(&mutex.lock);                                     
		if (s != 0)
			err_abort(s,"mutex destory failed\n");                                  
	}                                                                           
	return 0;                                                                   

}          
