

#include <signal.h>                                                                                
#include <unistd.h>                                                             
#include<stdio.h>                                                               
#include<stdlib.h>                                                              

void parent(void){
	printf ("parent got signal from child.....\n");
}

//void child (void);                                                            

int main()                                                                      

{                                                                               
	wait(NULL);                                                                 
	pid_t pid;                                                                  
	printf ("hii\n");                                                           
	pid = fork();                                                               

	if (pid > 0) {      
		signal (SIGUSR1, parent);	                                                         
		printf ("pid = %d\n",pid);                                              
		wait (NULL);                                                            
		printf ("parent = %d\n", getpid());                                     
	}                                                                           
	else if (pid == 0) {                                                         
		kill(getppid(), SIGUSR1);                                                                        
		printf ("child = %d\n", getpid());   
	}                                   
	else                                                                        
		printf ("fork failed\n");                                                   
	//  getchar();                                                                  
	return 0;                                                                   
}                          
