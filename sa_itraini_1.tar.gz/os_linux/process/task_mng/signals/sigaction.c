#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
void seg_fault(int a, siginfo_t *ptr, void *K)
{
	printf ("hii\n");
	printf ("%d\n", ptr->si_signo);
	printf ("%p\n", ptr->si_addr);
    printf ("signal number is:%d\n", a);
	printf ("your program is terminataing BYE.....\n");
    exit (1);
}

int main()
{
//	struct siginfo_t *ptr;
  	struct sigaction sig;
	//  sig.sa_handler = &seg_fault;//using handler 
	sig.sa_flags = SA_SIGINFO;    
	sig.sa_sigaction = &seg_fault;
	 
    //signal(SIGSEGV, seg_fault);
	sigaction(SIGSEGV, &sig, NULL);
    int *p = NULL;
    *p = 345;
    return 0;
}


