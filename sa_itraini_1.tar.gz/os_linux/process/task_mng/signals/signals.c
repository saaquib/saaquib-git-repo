
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
void seg_fault(int a)
{
	printf ("your program terminataing.....%d \n",getpid());
	getchar();
	exit (0);
}

int main()
{
	struct sigaction sig;
	sig.sa_handler = &seg_fault;
//	sig.sa_handler = SIGCHLD;
//	signal(SIGSEGV, seg_fault);
	sigaction(SIGSEGV, &sig, NULL);
	int *p = NULL;
	*p = 345;
	return 0;
}
	
