

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/syscall.h>
void *thread1 (void *arg)
{
	printf ("hi thread 1 \n");
	printf ("thread1 getpid = %d\t", getpid());
	printf ("thread1 gettid = %ld\t", syscall(SYS_gettid));
	printf ("thread1 getppid = %d\n", getppid());
	//exit (0);
	getchar();
	exit (0);
 
}
void *thread2 (void *arg)
{
	printf ("hi thread 2 \n");
	printf ("thread2 getpid = %d\t", getpid());
	printf ("thread2 gettid = %ld\t", syscall(SYS_gettid));
	printf ("thread2 getppid = %d\n", getppid());
	getchar();
	//exit (0);
 
}
int main()
{
	int err;
	pthread_t t_id;
	
	printf ("we are in main thread\n");
	
	if(pthread_create (&t_id, NULL, thread1, NULL) != 0) 
	{
		printf ("thread 2 is not created\n");
		exit (0);
	}

	err = pthread_create (&t_id, NULL, thread2, NULL);

	if (err != 0)
		printf ("thread is not cread\n");
	else 
		printf ("thread is created\n");
	
	printf ("parent getpid= %d\t", getpid());
	printf ("parent gettid = %ld\t", syscall(SYS_gettid));
	printf ("parent getppid=%d\n", getppid());
	getchar();
	exit (0);
}
