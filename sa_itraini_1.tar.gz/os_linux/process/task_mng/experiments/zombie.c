#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>

int main()
{
	fork();
	printf("pid = %d",getpid());
	return 0;
}
