

#include"header.h"

int main()

{
	 printf ("hiiiiiiii this is exec...\n");                                                     
    printf ("exec getpid = %d\t", getpid());                                 
    printf ("exec gettid = %ld\t", syscall(SYS_gettid));                     
    printf ("exec getppid = %d\n", getppid());                               
    getchar();   
}
