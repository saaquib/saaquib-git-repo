
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main ()
{
	pid_t pid;
	pid = fork();

	if (pid > 0)
	{
		printf ("parent process executing....\n");
		wait (NULL);
	}
	else if(pid == 0)
	{	
	
		printf ("child process executing....\n");
		if(-1 == execl("/bin/ls","ls", NULL)) {
			printf ("exec failed\n");
			exit (0);
		}
	}
	
	else 
		printf ("process is not created\n");
	
}
