// signal.c

#include<stdio.h>
#include<stdlib.h>
#include<signal.h>

void segfault(int value)
{
	printf ("*** Invalid Memory reference ***\n");
	printf ("*** Segmentation fault Core dumped ***\n");
	printf ("*** Signal value = %d ***\n", value);
	exit(1);
}

int main(void)
{
	signal(SIGSEGV, segfault);

	int *ptr = NULL;

	*ptr = 123;

	return 0;

}
