// fork1.c

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#define SIZE 32

int val = 88;		// global data
int main(void)
{
	pid_t pid;
	int num;		// local data
	char *str = NULL;	// heap data
	FILE *fp;			// session descriptor

	if (NULL == (str = (char *)malloc(sizeof(char)*SIZE))) {
		printf("Malloc failed\n");
		exit(1);	
	}

	printf("Enter a string\n");

	if (NULL == (fgets(str, SIZE, stdin))) {
		printf("Fgets failed\n");
		exit(1);
	}

	fp = fopen("just.txt", "w+");
	perror("just.txt");

	pid = fork();
	num = 6;		

	if (pid > 0) {						// parent process
		printf("p-num1 = %d\n", num);

		num = 13;
		printf("p-num2 = %d\n", num);

		printf("p-val = %d\n", val);

		val = 90;
		printf("p-val2 = %d\n", val);

		printf("p-string : %s", str);

		printf("Enter a p-string\n");
		if (NULL == (fgets(str, SIZE, stdin))) {
			printf("Fgets failed\n");
			exit(1);
		}

		printf("p-string2 : %s", str);

		printf("Parent process pid : %d\n\n", getpid());

		if ((fprintf(fp, "GLOBAL EDGE ")) < 0) {
			printf("fprintf failed\n");
			exit(1);
		}

	} else if (pid == 0) {				// child process
		printf("c-num1 = %d\n", num);

		num = 12;
		printf("c-num2 = %d\n", num);

		printf("c-val = %d\n", val);

		val = 47;		
		printf("c-val2 = %d\n", val);

		printf("c-string : %s", str);

		printf("Enter a c-string\n");
		if (NULL == (fgets(str, SIZE, stdin))) {
			printf("Fgets failed\n");
			exit(1);
		}

		printf("c-string2 : %s", str);

		printf("Child process pid : %d\n", getpid());

		if ((fprintf(fp, "SOFTWARE LIMITED \n")) < 0) {
			printf("fprintf failed\n");
			exit(1);
		}

	} else
		perror ("fork failed");

	getchar();

	free(str);

	return 0;
}
