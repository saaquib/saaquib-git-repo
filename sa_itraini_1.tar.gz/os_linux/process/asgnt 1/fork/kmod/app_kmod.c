#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
	int fd;
	pid_t pd;

	fd = open("/dev/myChar", O_RDWR);

	if (fd < 0)
		perror("Unable to open the device");
	else
		printf("File opened successfully %d\n", fd);

	pd = fork();

	if (pd > 0) {
		printf("parent process\n");
		ioctl (fd, getpid(), 10);
	} else if (pd == 0) {
		printf("child process\n");
		ioctl (fd, getpid(), 10);
	} else
		perror ("fork failed");

	close(fd);

	return 0;
}
