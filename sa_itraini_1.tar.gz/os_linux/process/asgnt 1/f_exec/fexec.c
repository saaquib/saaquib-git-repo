// fexec.c

#include<stdio.h>
#include<unistd.h>

int main(void)
{
	pid_t pid;

	pid = fork();
	wait(NULL);

	if (pid > 0) {
		printf("parent process\n");

	} else if (pid == 0) {
		printf("child process\n");
		execlp("sh", "result", NULL);

	} else
		perror("fork failed\n");

	getchar();	
	return 0;
}
