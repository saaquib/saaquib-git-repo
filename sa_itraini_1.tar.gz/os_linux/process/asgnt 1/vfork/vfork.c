// vfork.c

#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>

int val = 100;

int main(void) 
{
	pid_t pid;
	int num;
	FILE *fp;

	num = 19;
	fp = fopen("just.txt", "w+");
	perror("just.txt");
	pid = vfork();
	
	if (pid > 0) {
		printf("Parent process pid : %d\n", getpid());
		printf("p-num : %d\n", num);

		num = 7;
		printf("p-num1 : %d\n", num);

		printf("p-val : %d\n", val);

		val = 54;
		printf("p-val1 : %d\n", val);

		if ((fprintf(fp, "GLOBAL EDGE ")) < 0) {
			printf("fprintf failed\n");
			exit(1);
		}

		fclose(fp);

	} else if (pid == 0) {
		printf("Child process pid : %d\n", getpid());
		printf("c-num : %d\n", num);

		num = 3;
		printf("c-num1 : %d\n", num);	

		printf("c-val : %d\n", val);

		val = 66;
		printf("c-val1 : %d\n", val);

		if ((fprintf(fp, "SOFTWARE LIMITED \n")) < 0) {
			printf("fprintf failed\n");
			exit(1);
		}
	
		fclose(fp);

		exit(1);

	} else
		perror("vfork failed\n");
	
	return 0;
}
