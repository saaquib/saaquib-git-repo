#include<stdio.h>
#include<stdlib.h>
#define MAX 100

void file_copy(FILE *,FILE *,FILE *);
int main(void)
{
	FILE *fp1;
	FILE *fp2;
	FILE *fp3;

	file_copy(fp1,fp2,fp3);

	printf("Success \n");

	return 0;
}
void file_copy(FILE *fp1,FILE *fp2,FILE *fp3)
{
	char *str = NULL;
	int line = 1;
	int flag = 1;

	str = (char *)malloc(sizeof(char)*MAX); 

	fp1 = fopen("f1.txt","r+");

	if(fp1 == NULL)
	{
		perror("file 1 error");
		exit(EXIT_FAILURE);
	}

	fp2 = fopen("f2.txt","r+");                                                 

	if(fp2 == NULL)                                                             
	{                                                                           
		perror("file 2 error");                                                 
		exit(EXIT_FAILURE);                                                     
	}
	fp3 = fopen("f3.txt","w+");

	if(fp3 == NULL)                                                             
	{                                                                           
		perror("file 3 error");                                                 
		exit(EXIT_FAILURE);                                                     
	}

	while(flag < 3)
	{
		if((line % 2) == 0)
		{
			if(fgets(str,MAX,fp2))
			{
				fprintf(fp3,"%s",str);
				line++;
			}
			else
			{
				flag++;
			}
		}
		if((line % 2) != 0)                                                     
		{                                                                       
			if(fgets(str,MAX,fp1))                                              
			{                                                                   
				fprintf(fp3,"%s",str);                                          
				line++;                                                         
			}                                                                   
			else                                                                
			{                                                                   
				flag++;                                                         
			}                                                                   
		} 
	}
}
