#include <sys/types.h>                                                          
#include <sys/socket.h>                                                         
#include <stdio.h>                                                              
#include <stdlib.h>                                                             
#include <string.h>                                                             
#include <arpa/inet.h>
#include <netinet/in.h>

int main(void)                                                                      
{                                                                               
	int sfd;                                                                 
	int status;                                                                 
	char buff[100];                                                             
	char mesg[100] = "hello client";                                            
	
	struct sockaddr_in my_addr;                                                 
	struct sockaddr_in res_addr;                                                
	
	socklen_t size =  sizeof(struct sockaddr_in);                               

	my_addr.sin_family = PF_INET;                                               
	my_addr.sin_port = htons(7823);                                             
	my_addr.sin_addr.s_addr = inet_addr("172.16.5.238");                                

	sfd = socket(PF_INET,SOCK_DGRAM,IPPROTO_UDP);                                      
	
	if(sfd < 0){                                                             
		perror("socket creation failed");                                                       
		exit(1);                                                                
	}                                                                           

	status = bind(sfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr_in));

	if(status < 0) {                                                            
		perror("bind");                                                         
		exit(1);                                                                
	}                                                                           

	while(1) {                                 

		status = recvfrom(sfd, buff, sizeof(buff), 0, (struct sockaddr *)&res_addr, &size);

		if(status < 0) {                                                        
			perror("recvfrom failed");                                                 
			exit(1);                                                            
		}                                                                       

		printf("request recevied \n");                                          
		printf("		%s\n",buff);                                                

		status = sendto(sfd, mesg, sizeof(mesg), 0, (struct sockaddr *)&res_addr,size);
		if(status < 0) {                                                        
			perror("sendto failed");                                                   
			exit(1);                                                            
		}                                                                       
		memset(buff, '\0', sizeof(buff));                                       

	}                                                                           

	close(sfd);                                                              
	return 0;                                                                   
}   
