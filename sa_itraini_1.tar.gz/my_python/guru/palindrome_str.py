import sys

s = list(input('Enter string : '))
print(''.join(s))


