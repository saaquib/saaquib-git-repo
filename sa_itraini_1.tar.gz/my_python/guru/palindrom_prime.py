
def palindrome(num): 
	for i in range(10,num):
		temp = i
		rev = 0

		while temp > 0 :
			rev = (rev * 10) + (temp % 10) 
			temp //= 10
		if i == rev :     
			prime(i)

		
def prime(i):
	flag = 0
	if i%2 != 0:
		for j in range(1,i+1):                                                  
			if i%j == 0:                                                        
				flag += 1                                                      
	if flag == 2 :                                                         
		print(i)


		 
num = int(input('Enter count : '))
print("prime and pallindrome numbers :")
palindrome(num)

