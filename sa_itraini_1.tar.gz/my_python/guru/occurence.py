

st = list(input("Enter string : "))
print(st)
 
for j in range(len(st))
	

