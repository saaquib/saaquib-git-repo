#! /usr/bin/python

fd = open("a.txt","r+")

st = fd.read()
print st

fd.seek(0)

st = fd.readline()
print st

fd.seek(0)

st = fd.readlines()
print st
