#! /usr/bin/python

import os
import sys

def show():
	global lst
	for i in lst :
		print "   ",i[0],"   ",i[1],"   ",i[2],"\n"


def finish(ch):
	for i in range(0,len(lst)):
		x = 0
		for j in range(0,len(lst[i])) :
			if lst[i][j] == ch :
				x += 1
			else :
				break
		if (x == 3) and (ch == 'X') :
			return True
		if (x == 3) and (ch == 'O') :
			return True

	for i in range(0,len(lst)):
		x = 0
		for j in range(0,len(lst[i])) :
			if lst[j][i] == ch :
				x += 1
			else :
				break
		if (x == 3) and (ch == 'X') :
			return True
		if (x == 3) and (ch == 'O') :
			return True
	x = 0
	for i in range(0,3):
		if lst[i][i] == ch :
			x += 1
		else :        
			break
	if (x == 3) and (ch == 'X') :
		return True
	if (x == 3) and (ch == 'O') :
		return True
	i = 0
	for j in range(2,-1,-1) :
		if lst[i][j] == ch:
			x += 1
			i += 1
			
		else :
			break
	if (x == 3) and (ch == 'X'):
		return True
	if (x == 3) and (ch == 'O'):
		return True
 			


def play(count):
	global lst
	
	while True :
		if count % 2 == 0 :
			val = input("Player 1 enter position : ")
			if lst[val // 3][val % 3] == '_':
				lst[val // 3][val % 3] = 'X'	
				count += 1
				os.system('clear')
                        	show()
				print count
				cd = finish('X')
				if cd == True :
					print "Game over.. Player 1 won"
					return
				if count > 8 :
					print "Game Over... Match withdraw"
					return
			else :
				print "Already filled enter another position"
				play(count)
		if count % 2 != 0 :
			val = input("Player 2 enter position : ") 
			if lst[val // 3][val % 3] == '_':
                        	lst[val // 3][val % 3] = 'O'
				count += 1
				os.system('clear')
				show()
				print count
				cd = finish('O')
				if cd == True :
					print "Game over.. Player 2 won"
					return
				if count > 8 :
					print "Game Over... Match withdraw"
					return
			else :
				print "Already filled enter another position"
				play(count)


lst = [['_','_','_'],['_','_','_'],['_','_','_']]
count = 0
os.system('clear')
print ("<--- Welcome to TIC-TAC-TOE game ---->".center(100,' '))
show()
play(count)


