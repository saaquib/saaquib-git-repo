#! /usr/bin/python

# Variable attached to class

class Employee():
	empcount = 0
	def __init__(self):
		 Employee.empcount += 1
	def displaycount(self):
		print Employee.empcount

emp1 = Employee()
emp1.displaycount()
emp2 = Employee()
emp2.displaycount()
emp1.displaycount()
