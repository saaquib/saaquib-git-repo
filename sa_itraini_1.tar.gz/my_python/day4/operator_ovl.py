#! /usr/bin/python

# Operator Overloading

class Number():
	def __init__(self,start):
		self.data = start
	def __sub__(self,other):
		print "subtraction overloading"
		return Number(self.data - other)
	def __add__(self,other):
		print "addition overloading"
		return Number(self.data + other)
	def displaydata(self):
		return self.data

x = Number(7)
y = x - 4
print y.displaydata()
z = x + 53
print z.displaydata()
