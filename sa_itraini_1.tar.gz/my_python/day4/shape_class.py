#! /usr/bin/python

# Inheritance

class Shape():
	def __init__(self,x,y):
		print "Shape class constructor invoked"
		self.x = x
		self.y = y
	def area(self):
		return self.x * self.y
	def perimeter(self):
		return 2 * (self.x + self.y)
		
class Square(Shape):
	def __init__(self,x):     
		#Shape .__init__(self,x,x)
		print "Square class constructor invoked"
		self.x = x
		self.y = x

class DoubleSquare(Square):   # Multi level Inheritance
	def __init__(self,y):
		print "DoubleSquare class constructor invoked"
		self.x = y
		self.y = 2 * y
	def perimeter(self):
		return (2 * self.x) + (3 * self.y)


mySquare = Square(25)
print type(mySquare)
print mySquare.area()
print mySquare.perimeter() 

myDoubleSquare = DoubleSquare(45)
print myDoubleSquare.area()
print myDoubleSquare.perimeter()



		
