#! /usr/bin/python

lst = [56,66,4,89,4,28,79]
print lst
print lst[2:5]
print lst[:3]
print lst[2:]
print lst[::2]
