

dct = {10:20, 50:99}

print dct

def dcttest(dct2):
	dct2[10] = 100
	dct2[50] += 465
	print dct2
dcttest(dct)
print dct   #
