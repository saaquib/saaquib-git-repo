#! /usr/bin/python

var = 2
var2 = 552

print "var is",var,"var2 is ",var2
