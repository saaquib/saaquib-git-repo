#! /usr/bin/python

#tuple in list
lst = [52,46,85,(23,89,78)] #we can't modify lst[3][0] like this

for i in lst :
	print i

#list in tuple
tup = (5,863,[78,23]) #we can modify tup[2][0] like thi

for i in tup :
	print i
