#! /usr/bin/python

lst = [50,63,55,78]

print lst[0], lst[1], lst[2], lst[3]
print lst[-1], lst[-2], lst[-3], lst[-4]
