#! /usr/bin/python

import socket

class MySocket(socket.socket) :	
	"class derived from socket class. Which is used to create socket"
	
	def soc_create(self) :
		"This method is for taking IP addr, port number and binding to socket "
		try :
			port = input("Enter port number : ")
			self.bind(("172.16.5.238", port))
		except SyntaxError:
			print "\nInvalid input "
			sys.exit(1)

	def communicate(self) :
		"This method is for accepting client request and providing communication"
		try:
			self.listen(5)
			serv, addr = self.accept()
			print 'connected to ',addr
		except socket.error as e:
			print "Error in socket due to ",e
			serv.close()
			sys.exit(1)
		
		while True :
			string = serv.recv(100)
			print string
			if string == "exit":
				print "Terminating connection with client ",addr
				self.communicate()
			try :
				st = raw_input("Enter msg to client : ")
				serv.send(st)
			except SyntaxError:
                        	print "\nInvalid input to message"
		serv.close()
		
sd = MySocket(socket.AF_INET,socket.SOCK_STREAM)
sd.soc_create()
sd.communicate()		

