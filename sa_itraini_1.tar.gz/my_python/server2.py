#! /usr/bin/python

import socket

from socket import socket as soc

sd = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
#host = socket.gethostname()
port = 6546

sd.bind(("172.16.5.238", port))

sd.listen(5)
#addr = socket.inet_aton("172.16.5.238")

serv, addr = sd.accept()
selfprint serv, addr
print 'connected',addr
while True :
        string = serv.recv(100)
        print string

        st = raw_input("Enter msg to client : ")
        serv.send(st)


sd.close()
