#include"stdio.h"
#include"stdlib.h"
#include"stdint.h"
#include <features.h>
#define EI_NIDENT (16)

typedef struct
{
	unsigned char e_ident[EI_NIDENT];                                               
	uint16_t    e_type;                                                         
  	uint16_t    e_machine;                                                      
  	uint32_t    e_version;                                                      
  	uint32_t    e_entry;                                                        
  	uint32_t    e_phoff;                                                        
	uint32_t     e_shoff;                                                        
	uint32_t    e_flags;                                                        
	uint16_t    e_ehsize;                                                       
	uint16_t    e_phentsize;                                                    
	uint16_t    e_phnum;                                                        	
	uint16_t    e_shentsize;                                                    
	uint16_t    e_shnum;                                                        	
	uint16_t    e_shstrndx;

} Elf32_Ehdr;

void type(int);

void machine(int);


typedef struct
{
  uint32_t    sh_name;        /* Section name (string tbl index) */
  uint32_t    sh_type;        /* Section type */
  uint32_t    sh_flags;       /* Section flags */
  uint32_t    sh_addr;        /* Section virtual addr at execution */
  uint32_t 	  sh_offset;      /* Section file offset */
  uint32_t    sh_size;        /* Section size in bytes */
  uint32_t    sh_link;        /* Link to another section */
  uint32_t    sh_info;        /* Additional section information */
  uint32_t    sh_addralign;       /* Section alignment */
  uint32_t    sh_entsize;     /* Entry size if section holds table */
} Elf32_Shdr;

void sec_type(int);


