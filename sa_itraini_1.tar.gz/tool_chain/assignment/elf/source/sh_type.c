#include"myheader.h"

void sec_type(int n)
{
	switch(n)
	{
		case 0 : printf("NULL        \t");
				 break;
		case 1 : printf("PROGBITS    \t");
				 break;
		case 2 : printf("SYMTAB      \t");
				 break;
		case 3 : printf("STRTAB      \t");
				 break;
		case 4 : printf("RELA        \t");
				 break;
		case 5 : printf("HASH        \t");
				 break;
		case 6 : printf("DYNAMIC     \t");
				 break;
		case 7 : printf("NOTE        \t");
				 break;
		case 8 : printf("NOBITS      \t");
				 break;
		case 9 : printf("REL         \t");
				 break;
	 	case 10 : printf("SHLIB      \t");
				  break;
		case 11 : printf("DYNSYM     \t");
				  break;
		case 14 : printf("INIT_ARRAY \t");
				  break;
		case 15 : printf("FINI_ARRAY \t");
				  break;

		case 0x70000000 : printf("LOPROC     \t");
				          break;
		case 0x7fffffff : printf("HIPROC     \t");
						  break;
		case 0x80000000 : printf("LOUSER     \t");
						  break;
		case 0xffffffff : printf("HIUSER     \t");
						  break;
		default : printf("NOT_DEF    \t");
				  break;
	}
}
