#include"myheader.h"

void machine(int n)
{
	switch(n)
	{
		case 0 : printf(" No Machine\n");
				 break;

    	case 1 : printf(" AT&T WE 32100\n");
				 break;
		
		case 2 : printf(" SPARC\n");
				 break;
		case 3 : printf(" Intel 80386\n");
				 break;

		case 4 : printf(" Motorola 68000\n");
				 break;

		case 5 : printf(" Motorola 88000\n");
				 break;

		case 7 : printf(" Intel 80860\n");
				 break;

		case 8 : printf(" MIPS RS3000\n");
				 break;
	}
}
