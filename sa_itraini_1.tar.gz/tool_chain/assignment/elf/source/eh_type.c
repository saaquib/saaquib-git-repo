#include"myheader.h"

void type(int n)
{
	switch(n)
	{
		case 0 : printf(" No file type\n");
				 break;
		case 1 : printf(" Relocatable file\n");
				 break; 
		case 2 : printf(" Executable file\n");
				 break; 
		case 3 : printf(" Shared object file\n");
				 break; 

		default : printf(" Processor-specific\n");
	}
}
