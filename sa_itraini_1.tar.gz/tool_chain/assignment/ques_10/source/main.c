#include"stdio.h"
#include"stdlib.h"

int main(int argc, char *argv[]) {

	FILE *fp;
	char ch;
	char str[10];
	int i = 0;

	if(NULL == (fp = fopen(argv[1],"r"))) {

		perror("file doesn't exist");
		exit (0);
	}
	
/*	while(!feof(fp)) {


		ch = fgetc(fp);
		printf("%c",ch);
	}
	rewind(fp);*/
	while(((ch = fgetc(fp)) != EOF)) {
		
		printf("%c",ch);
	}
		

/*	while((ch = fgetc(fp)) != '-') {
		
		fseek(fp,-1,SEEK_CUR);
		ch = fgetc(fp);
		str[i++] = ch;
	}
	//str[i] = '\0';
	for(i = 0; i < 10; i++)
		printf("%c  ",str[i]);
	printf("\n");

	
*/	
	
	return 0;

}			
