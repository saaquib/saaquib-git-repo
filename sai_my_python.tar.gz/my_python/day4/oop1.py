#! /usr/bin/python

#simple class example with public method
class Employee :
	def __init__(self,name = "Saikiran",sal = 10000): #constructor
		self.name = name
		self.salary = sal
	
	def Details(self):
		print "Employee name : ",self.name
		print "Employee saalry : ",self.salary

	def __del__(self):
		print "Destructor is invoked"
	

# class example with all types of methods
class Operations :
	def __init__(self,a,b):
		self.a = a
		self.b = b
	def myadd(self) :         # Public method
		return self.a + self.b
	def _mysub(self) :		# Semi Private method
		return self.a - self.b
	def __mymul(self) :		# Fully Private method
		return self.a * self.b
	
		
#x = Employee("saaquib",15000)
#x.Details()

y = Operations(10,20)
print type(y)
print y.myadd()
print y._mysub()
print y._Operations__mymul() # like y.__mul() for private methods
			     # not recomended this type

	
