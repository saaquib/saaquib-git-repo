#! /usr/bin/python

# Multiple Inheritance

class A():
	def __init__(self,x):
		print "A class constructor invoked"
		self.x = x
	def fun1(self) :
		print "Class A"
		return self.x * self.x

class B():
	def __init__(self,y):
		print "B class constructor invoked"
		self.x = y
	def fun1(self) :
		print "Class B"
		return self.x ** 3

class C(B,A) :
	def __init__(self,z):
		print "C class constructor invoked"
		self.x = z
		

c = C(5)
print c.fun1()

