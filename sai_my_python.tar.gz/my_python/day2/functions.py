#! /usr/bin/python

# doc comments 
if 0:
	def fun(a = 20, b = 30) :
		"Hello I am function 1 !!"
		print a,b

	x = 50
	fun(x)

# Recursion
if 0:
	def fact(num) :
		if num > 0 :
			print "hello ",num 
			fact(num - 1)
		else :
			print "finish ",num
			return
	
	n = input("Enter number : ")
	fact(n)

# Nested functions
if 1:
	def outs():
		print "outside"
		def ins():        #outs()
			print "inside"
		ins()  #outs()          o/p is same from legb rule
	outs()

# Pass by object








# Keywords and positional arguments
