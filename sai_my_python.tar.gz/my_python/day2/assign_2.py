#! /usr/bin/python

import sys
import math
import os

# User given number in different number systems
if 0 :
	num = input("Enter a number : ")
	print "In hex : ",hex(num)
	print "In oct : ",oct(num)
	print "In bin : ",bin(num)


# Value of pi and sin 90 degrees
if 0 :
	print "Value of PI : ",math.pi
	print "Value of sin(90) : ",math.sin(math.pi/2)

# Changing current directory
if 1:
	os.chdir("/home/saikiran/")
	print os.getcwd()
	
# Clear screen
if 1:
	if os.uname()[0] == 'Linux' :
		os.system('clear')
		print "You are in LINUX.. Successfully cleared screen"

# Print python  version
if 0:
	print "Python version : ",sys.version


# Printing cmd line args
if 1 :
	print len(sys.argv)
	for i in range(0,len(sys.argv)) :
		print sys.argv[i]
