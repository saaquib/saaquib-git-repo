
if 1:
	print "hi"
if 0:
	"jhhu"
