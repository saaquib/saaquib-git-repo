#! /usr/bin/python


import os
import operations as op

def simple():
	"This function is for menu of simple calculator"
	os.system('clear')
	while True :
		print "Simple Calculator".center(50,'-')
		num = input("1.Addition\n2.Subtraction\n3.Multipliction\n4.Division\n5.Clear screen\n6.Go Back\noption : ")
		if num == 1 :
			num1 = input("Enter first num : ")
			num2 = input("Enter second num : ")
			print "Result = ",op.myadd(num1,num2)
		elif num == 2 :
			a = input("Enter first num : ")
                	b = input("Enter second num : ")
                	print "Result = ",op.mysub(num1,num2)
		elif num == 3 :
                        a = input("Enter first num : ")
                        b = input("Enter second num : ")
                        print "Result = ",op.mymul(num1,num2)
		elif num == 4 :
                        a = input("Enter first num : ")
                        b = input("Enter second num : ")
                        print "Result = ",op.mydiv(num1,num2)
		elif num == 5 :
			os.system('clear')
		elif num == 6 :
			return
		else :
			print "wrong option select again"

def scientific() :
        "This function is for menu of scientific calculator"
	os.system('clear')
	while True :
                print "Scientific Calculator".center(50,'-')
		num = input("1.Sine\n2.Cos\n3.Power of\n4.Square root\n5.Clear screen\n6.Go Back\noption : ")
		if num == 1 :
                        a = input("Enter num : ")
                        print "Result = ",operations.sine(a)
                elif num == 2 :
                        a = input("Enter num : ")
                        print "Result = ",operations.cos(a)
                elif num == 3 :
                        a = input("Enter num : ")
                        b = input("Enter power : ")
                        print "Result = ",operations.power(a,b)
                elif num == 4 :
                        a = input("Enter num : ")
                        print "Result = ",operations.root(a)
		elif num == 5 :
			os.system('clear')
                elif num == 6 :
                        return
                else :
                        print "wrong option select again"


while True :
        os.system('clear')
        print "CALCULATOR".center(50,'-')
        choice = input("1.Simple Calculator \n2.Scientific Calculator\n3.Exit\noption : ")

        if choice == 1 :
                simple()
        if choice == 2 :
                scientific()
        if choice == 3 :
                break
        else :
                print "wrong option select again"



