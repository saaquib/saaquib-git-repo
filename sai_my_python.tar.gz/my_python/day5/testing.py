#! /usr/bin/python

def myAverage(a,b):
	"""
	>>>myAverage(10,30)
	20
	>>>myAverage(40,60)
	5
	"""
	return (a+b)/2
import doctest
doctest.testmod()

