#! /usr/bin/python

# experiment on regular expressions

import re

lst = ["abc","dfs","aBc","ABc"]

print re.findall("abc",str(lst))
print re.findall("abc",str(lst),re.I)
print re.sub("abc","mno",str(lst))
print re.sub("abc","mno",str(lst),1)
print re.sub("aBc","mno",str(lst),1,re.I)

