#! /usr/bin/python

n = input("Select experiment : ")

# 2 qn
if n == 2 :
	print 26**100

# 3rd qn
if n == 3:
	sent1 = ['Monty','Python']
	print ['Monty','Python'] * 20
	print 3 * sent1 
			# above 2 operations are same 

# 4th qn
if n == 4:
	text1 = 'kiran'
	print len(set(text1))
	# first step is to divide into characters into list
	# Second is for finding no of eliments in that

# 5th qn
if n == 5:
	my_str = "Saikiran"
	print my_str
	#print my_str+my_str
	print my_str + " " + my_str
	print (my_str + " ") * 3 

# 6th qn
if n == 6:
	st = ["my","str"]
	st = ' '.join(st)
	print st
	st = st.split(' ')
	print st

# 7th qn
if n == 7:
	phase1 = ["hello","hai"]
	phase2 = ["sai","kiran"]
	print phase1+phase2
	print len(phase1+phase2)
	print len(phase1) + len(phase2)


# 14th qn



# 15th qn
if n == 15:
	def percent(word, text):
		c = len(word.split())
		print "Total words ",c
		d = words.count(text)
		print "Given word occured ",d
		return (d * 100)/c
	
	words = "hello sai kiran hello hai hello"
	text = "hello"
	p = percent(words,text)
	print "Percentage is ",p
# 16th qn



# 17th qn
if n == 17:
	s = 'colorless'
	s = s[:-5]+"urless"
	print s

# 18th
if n == 18:
	s = "dishes"
	print s[:-2]
	s = "running"
	print s[:-4]
	s = "nationality"
	print s[:]
	s = "undo"
	print s[:-2]
	s = "preheat"
	print s[:-4]

# 19th


# 20th
if n == 20:
	import urllib
	import re
	ud = urllib.urlopen(raw_input("Enter URL : "),data=None, proxies=None)
	c = ud.read()
	#d = re.findall("<p>(.*)</p>",c,re.I|re.M)
	print c

# 21st qn
if n == 21:
	words = ["sai","kiran","subba rao","neha"]
	srt = sorted(words) # sorted doesn't update
	print srt
	print words
	print words.sort() # This method will update
	print words
	

# 22nd 
if n == 22:
	from test import monty
	print monty
	import test 
	print test.monty



