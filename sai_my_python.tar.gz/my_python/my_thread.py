#! /usr/bin/python

import threading
import time
def details(name,num):
	print "I am in thread ",name
	count = 0
	while count < 5:
		print "count : ",threading.activeCount()
		
		time.sleep(num)
		count += 1
      		print "%s: %s" % ( name, time.ctime(time.time()) )

try:
	threading._start_new_thread( details, ("Thread-1", 2 ) )
	threading._start_new_thread( details, ("Thread-2", 4 ) )
except:
	print "Error: unable to start thread"

print "count : ",threading.activeCount()
time.sleep(1000)
