#! /usr/bin/python

if 0 :

	r = int(input("Enter range : "))

	i = 0
	j = 1
	f = 0
	print "fibonacci series :\n",i,"\n",j

	while f <= r :
		f = i + j
		print f
		i = j
		j = fi



if 1 :

	r = int(input("Enter range : "))
	f = [0,1]
	print f[0]
	print f[1]
	for i in range(r) :
		f.append(f[i] + f[i + 1])
		print f[i + 2]

	
