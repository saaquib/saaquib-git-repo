#! /usr/bin/python

name = raw_input("Enter your name : ")
print "hello ",name
