

# Day 1 - 8/03/2017

#exp no 1
# To check given no by user is less or greater than 100

if 0 :
	x = int(input("Enter a number to check : "))
	if x > 100 :
		print "Given number is greater than 100"
	elif x < 100 :
		print "Given number is less than 100" 
	else :
		print "Given number is equal to 100"

#end of exp 1

#exp no. 2
# Print 1 to 10

if 0 :
	i = 1
	while i <= 10 :
		print i
		i += 1

#end of exp 2

#exp no. 3                                                                      
# Print 1 to 5
if 0 :                                                                          
	i = 1                                                                       
	while i <= 10 :                                                             
		print i                                                                 
		i += 1
		if i > 5 :
			break
#end of exp 3

#exp no 4
if 0 :                                                                          
	i = 1                                                                       
	while i <= 10 :                                                                                                               
		if i == 5 :
			i += 1
			continue 
		print i
		i += 1 
# end of exp 4

#exp 5
#week day

if 5 :
	day = raw_input("Enter day : ")
	if (day == "monday" or day == "tuesday" or day == "wednesday" or \
			day == "thursday" or day == "friday" ):
		print "Today is working day go to office !! "
	elif (day == "saturday" or day == "sunday"):
	 	print "Holiday enjoy !!!"
	else :
	 	print "You entered wrong day"

#end of exp 5

