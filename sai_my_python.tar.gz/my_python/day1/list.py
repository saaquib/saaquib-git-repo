#! /usr/bin/python

# To demonstrate list

lst = [1,45,2,"hello",[5,6]]

#print whole list
print lst,"\n"

#print ele by ele
print "Using for loop \n"

for i in lst :
	print i

print "Using while loop \n"

i = 0
while i < len(lst) :
	print lst[i]
	i += 1

#insert 30 at beg
lst.insert(0,30)
print lst

#insert at end 
lst.append(50)
print lst

#delete at pos 1
lst.pop(1)
print lst

#delete at pos 1 and print it
print lst.pop(1)

#print no.of ele
print len(lst)

#delete ele by value
lst.remove([5,6])
print lst




