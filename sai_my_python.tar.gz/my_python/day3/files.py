#! /usr/bin/python

import sys
import os


# cat implementation
if 0 :
	if len(sys.argv) == 2 :
		if os.path.exists(sys.argv[1]) and os.path.isfile(sys.argv[1]):
			fd = open(sys.argv[1],"r")
			st = fd.read()
			fd.close()
			print st
		else :
			print "No such file"

	else :
		print "Invalid cmd line arguments"

# Implmenting cp(copy)
if 0 :
	if len(sys.argv) == 3 :
		if os.path.exists(sys.argv[1]) and os.path.isfile(sys.argv[1]):
				fd = open(sys.argv[1],"r") 
				fd2 = open(sys.argv[2],"w")

				st = fd.read()
				fd2.write(st)
				fd.close()
				fd2.close()
		else :
			print "No such file"

	else :
		print "Invalid cmd line arguments"


# Implement word count
if 1 :
	import re
	if len(sys.argv) == 2 :
		if os.path.exists(sys.argv[1]) and os.path.isfile(sys.argv[1]):
			fd = open(sys.argv[1],"r")
			st = fd.read()
			print st,"\n"
			print re.split('[ ,:\n]',st)
			print "No.of words : ",len(re.split('[ ,:\n]',st))
			print "No.of characters : ",len(st)
			fd.seek(0)
			print "No.of line : ",len(fd.readlines())
			fd.close()
		else :
			print "No such file"
	else :
		print "Invalid cmd line arguments"
	

# Write abcd in file and read

if 0 :          # without seek
	if len(sys.argv) == 2 :
		if os.path.exists(sys.argv[1]) and os.path.isfile(sys.argv[1]):
				fd = open(sys.argv[1],"w")
				fd.write("abcd")
				fd.close()
				fd = open(sys.argv[1],"r")
				print fd.read()
				fd.close()

		else :
			print "No such file"
	else : 
		print "Invalid cmd line arguments"
					



