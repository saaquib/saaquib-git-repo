#! /usr/bin/python

import math

# Simple Cal operations

def myadd(x,y) :
	return x + y

def mysub(x,y) :
	return x - y

def mymul(x,y) :
	return x * y

def mydiv(x,y) :
	return x / y



# Scientific Cal operations

def sine(x) :
	return math.sin(x * (math.pi/180)) 

def cos(x) :
	return math.cos(math.degrees(x))

def power(x,y) :
	return x**y

def root(x) :
	return math.sqrt(x)


