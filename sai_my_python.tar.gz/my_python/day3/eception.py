#! /usr/bin/python

# Exception handling example

try :
	a = 10
	print a/1
	print "success"

except ZeroDivisionError:
	print "Division by zero"
except NameError:
	print "NameError occured"

finally:
	print "bye"
	
