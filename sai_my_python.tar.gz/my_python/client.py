#! /usr/bin/python

import socket
import sys
class MySocket(socket.socket) :
	"class derived from socket class. Which is used to create socket"
	
        def communicate(self) :
		"""This method is for taking IP addr, port number and binding to socket. 
		   And for providing communication with server"""
		try :
			addr = raw_input("Enter Server IP address : ")
			port = input("Enter Server port number : ")
		except SyntaxError:
			print "\nInvalid input "
			sys.exit(1)
			
		try:
                	self.connect((addr,port))
		except socket.error as e :
			print "Coudn't connect to server due to ",e
			sys.exit(1)

                while True :
			try :
				st = raw_input("Enter msg to server : ")
				self.send(st)
				if st == "bye":
					print "Terminating connection with server"
					break
    				string = self.recv(100)
    				print string
			except socket.error as e:
				print "Cannot send/recieve message due to ",e
				sys.exit(1)
		self.close()


sd = MySocket(socket.AF_INET,socket.SOCK_STREAM)
sd.communicate()
