a = 10
print(a)
del a
print(a)
