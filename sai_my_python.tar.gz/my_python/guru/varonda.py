
doors = int(input('Enter number of doors : '))

for i in range(1,doors):
	for j in range(1,doors + 1):
		if j*j == i :
			print(i)
			break
		
