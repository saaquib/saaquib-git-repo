#include<stdio.h>
#include<stdlib.h>
#define SIZE 64

typedef struct node {
	int data;
	struct node *link;
} snode;

snode *head;

void display(void);
int a_to_i(char numbuf[]);
snode *create(void);
void ins_beg(void);
void del_end(void);
void del_beg(void);
