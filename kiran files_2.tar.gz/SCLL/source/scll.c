// scll.c

// functions to perform single circular linked list operations

#include "header.h"

snode *create(void)
{
	int element;
	char elem[SIZE];
	snode *temp = NULL;

	if (NULL == (temp = (snode*) malloc(sizeof(snode)))) {
		printf("malloc for temp failed\n");
		exit(0);
	}

	printf("list is empty. Enter the element to create a node\n");
	fgets(elem, SIZE, stdin);
	printf("\n");

	element = a_to_i(elem);

	temp -> data = element;
	temp -> link = temp;

	return temp;
}	

void ins_beg(void)
{
	char elem[SIZE];
	int element;
	snode *current = NULL;
	snode *temp = NULL;

	if (NULL == (temp = (snode*) malloc(sizeof(snode)))) {
		printf("malloc for temp failed\n");
		exit(0);
	}

	if (NULL == (current = (snode*) malloc(sizeof(snode)))) {
		printf("malloc for current failed\n");
		exit(0);
	}

	if (head == NULL) {
		head = create();
		main();
	} else {
		printf("Enter the element\n");
		fgets(elem, SIZE, stdin);

		element = a_to_i(elem);

		current = head;
	
		while ((current -> link) != head) {
			current = current -> link;
		}

		temp -> data = element;
		current -> link = temp;
		temp -> link = head;
		head = temp;		

		}
}


void del_end(void)
{
	snode *current = NULL;                                                      
    snode *prev = NULL;                                                         
                                                                                
    if (NULL == (prev = (snode*) malloc(sizeof(snode)))) {                      
        printf("malloc for temp failed\n");                                     
        exit(0);                                                                
    }                                                                           
                                                                                
    if (NULL == (current = (snode*) malloc(sizeof(snode)))) {                   
        printf("malloc for current failed\n");                                  
        exit(0);                                                                
    }                                                                           
                                                                                
    if (head == NULL) {                                                         
        head = create();                                                        
        main();                                                                 
    } else {                                                                    
		current = head;
		prev = current;

		while ((current -> link) != head) {
			prev = current;
			current = current -> link;
		}

		prev -> link = head;
	}
		free(current);
}

void del_beg(void)
{
	snode *temp = NULL;
	snode *current = NULL;    
	
	if (NULL == (temp = (snode*) malloc(sizeof(snode)))) {                      
        printf("malloc for temp failed\n");                                     
        exit(0);                                                                
    }                                                                           
                                                                                
    if (NULL == (current = (snode*) malloc(sizeof(snode)))) {                   
        printf("malloc for current failed\n");                                  
        exit(0);                                                                
    }                                                                           
                                                                                
    if (head == NULL) {                                                         
        printf("List is empty\n");                             
        main();                                                           
    } else {                                                                    
        temp = head;      
		current = head;                                                   

		while (current -> link != head) {
			current = current -> link;
		}
	
		current -> link = temp -> link;
		head = temp -> link;

		free(temp);
	}
}
