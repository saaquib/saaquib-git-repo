// display.c

// function to display the elements in SCLL

#include "header.h"

void display(void)
{
	snode *current = NULL;

	if (NULL == (current = (snode*) malloc(sizeof(snode)))) {
		printf("malloc for current failed\n");
		exit(0);
	}

	current = head;

	if (current == NULL) {
		printf("The list is empty\n");
	} else {
		while ((current -> link) != head) {
			printf("%d\n", current -> data);
			current = current -> link;
		}
	
		printf("%d\n", current -> data);
	}
}
