// main.c

// program to implement single circular linked list operations

#include "header.h"

snode *head = NULL;

int main(void)
{
	int option;
	char opt[SIZE];

	while (1) {

		printf("Enter the option which you wish to perform on SCLL\n");
		printf("1. Insertion at beginning\n");
		printf("2. Deletion at end\n");
		printf("3. Deletion at beginning\n");
		printf("4. Display\n");
		printf("5. Exit\n");

		fgets(opt, SIZE, stdin);
		option = a_to_i(opt);

		printf("\n");
		switch(option) {
			case 1 : ins_beg();
					 printf("\n");
					 break;
			case 2 : del_end();
					 printf("\n");
					 break;
			case 3 : del_beg();
					 printf("\n");
					 break;
			case 4 : display();
					 printf("\n");
					 break;
			case 5 : exit(1);
			default : printf("Please enter the valid option\n");
		}
	}
}
