// atoi.c

// Date of creation : 25/ 11/ 2016

// function to convert string to int value

int a_to_i(char numbuf[])
{
	int i;
	int n = 0;

	for (i = 0; ((numbuf[i] >= '0') && (numbuf[i] <= '9')); i++) {
		n = (10 * n) + (numbuf[i] - 48);
	}

	return n;
}
