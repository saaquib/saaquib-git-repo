package hello_world;

public class TestClass {
	
	public static void main(String[] args) {
	System.out.println("hello world");
	MyName name = new MyName();
	name.print();
	
	}
}
