package hello_world;

public class MyName {
	private String myname;
	
	public void print() {
		myname = "saikiran";
		System.out.println(myname);
	}
}
