package com.kiran.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView getRegisterForm() {
		
		ModelAndView model = new ModelAndView("RegisterForm");
		return model;
		
	}
	
	@RequestMapping(value = "/success", method = RequestMethod.POST)
	public ModelAndView submitRegisterForm(@RequestParam Map<String, String> names){
		
		String fName = names.get("firstname");
		String lName = names.get("lastname");
		ModelAndView model = new ModelAndView("RegisterSuccess");
		model.addObject("msg",fName + " " + lName);
		
		return model;
	}
	
	
	
}
