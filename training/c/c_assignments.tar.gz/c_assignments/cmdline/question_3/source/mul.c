#include"header.h"

int mul1(int num1,int num2)
{
        return (num1*num2);
}
