#include"header.h"

int add1(int number1,int number2)
{
	return (number1+number2);
}
