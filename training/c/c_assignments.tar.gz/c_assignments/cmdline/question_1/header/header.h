#include<stdio.h>

int str_len(char *);
