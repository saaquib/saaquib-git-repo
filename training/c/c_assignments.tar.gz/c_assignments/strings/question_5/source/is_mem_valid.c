#include"header.h"

void is_mem_valid(char *s)
{
        if(s == NULL)   {
                printf("NO MEMORY");
                exit(0);
        }
}
