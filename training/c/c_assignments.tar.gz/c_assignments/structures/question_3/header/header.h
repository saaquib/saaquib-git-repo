#include<stdio.h>

union u
{
	int a;
	char ch;
};
