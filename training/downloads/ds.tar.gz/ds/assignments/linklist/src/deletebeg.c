#include "header.h" //include header

sl *deletebeg(sl *head)
{
	head = head -> next;
	return head;
}
