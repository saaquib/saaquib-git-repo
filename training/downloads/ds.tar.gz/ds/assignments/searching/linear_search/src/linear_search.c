#include "header.h"
	
int linear_search(int a[20],int key)
{
	int i = 0;
	while (n) {
		if ( a[i] == key )
			return 1;
	i++;
	n--;
	}
	return 0;
}
