#include <stdio.h> //include stdio header

#include <stdlib.h> //include standard library

#define MAX 64 //macro to define MAX value

int linear_search(int a[20],int key);
int n;
