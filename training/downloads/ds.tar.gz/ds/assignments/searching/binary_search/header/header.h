#include <stdio.h>
#include <stdlib.h>

#define MAX 64

int n;

int binary_search(int a[20],int key);
