#include <stdio.h> //include stdio.h

#include <stdlib.h> //include standard library

#define MAX 64 //macro to define MAX value

int *bubblesort(int a[20]); //bubble sort function declaration
int n; //variable holding the number of elements

