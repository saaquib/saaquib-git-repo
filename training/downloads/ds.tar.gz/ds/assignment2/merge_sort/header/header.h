#include <stdio.h> //include stdio.h                                            
                                                                                
#include <stdlib.h> //include standard library                                  
                                                                                
#define MAX 64 //macro to define value of MAX                                   
                                                                                
int n; 

void merge_sort(int a[20],int first,int last);

void merge(int a[20],int first,int mid,int last);
int b[20];
