#include <stdio.h> //include stdio.h                                            
                                                                                
#include <stdlib.h> //include standard library                                  
                                                                                
#define MAX 64 //macro to define value of MAX                                   
                                                                                
int n; 

void insertion_sort(int a[MAX]);

