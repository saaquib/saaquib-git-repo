#include <stdio.h> //include stdio.h                                            
                                                                                
#include <stdlib.h> //include standard library                                  
                                                                                
#define MAX 64 //macro to define value of MAX                                   
                                                                                
int n;                                                                          
                                                                                
void quick_sort(int a[20],int first,int last);    
