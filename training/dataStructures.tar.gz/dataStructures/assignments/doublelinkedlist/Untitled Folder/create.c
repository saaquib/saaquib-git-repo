#include"header.h"

void create(NODE *node)
{
	node = (NODE*)malloc(sizeof(NODE));
//	node->link = NULL;

}


