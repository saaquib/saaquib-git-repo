#include"header.h"

void display(void)
{
	int i;
	NODE *traverse;
	traverse = head;
	while(traverse->next != NULL)
	{
		printf("%d\t",traverse->data);
		traverse = traverse->next;
	}
	printf("%d\t",traverse->data);
}
