#include<stdio.h>

#define MAX 32

void swap(int *, int *);

void selection_sort(int *, int);

void des_selection_sort(int *, int);
