#include<stdio.h>

#define MAX 32

void swap(int *, int *);

void asc_merge_sort(int *, int, int);

void des_merge_sort(int *, int, int);

void asc_merge(int *, int, int, int);

void des_merge(int *, int, int, int);
