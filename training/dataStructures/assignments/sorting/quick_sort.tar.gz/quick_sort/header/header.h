#ifndef HEADER_H
#define HEADRR_H

#include<stdio.h>
#include<string.h>
#include<stdlib.h>

#define MAX 5

void quicksort(int *, int, int);
int partition(int *, int, int);

#endif
