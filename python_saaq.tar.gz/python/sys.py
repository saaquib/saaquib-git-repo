import os, sys
while True:
	option = input("enter command : ")
	if option == 'end' :
		exit(0)
	os.system(option)
