doors = int(input ("number of doors : "))
for i in range (1, doors) :
	factors = []
	for odd in range (1,i+1) :
		if (i % odd == 0) :
			factors.append(odd)
	if not (len(factors) % 2 == 0) :
		print (i)
