for i in range(10, 100) :
	count = 0
	for j in range (1, i) :
		#nonlocal count
		if (i % j == 0) :
			count=count+1
	if count == 1 :
		count=0
		print (i) 
