#include<stdio.h>
int main (void) {
	int i=0,j=0,k,r,c;
	printf("enter row and column : \n");
	scanf ("%d %d",&r,&c);
	int a[r][c];
	printf("enter elements\n");
	for (i = 0; i < c; i++) {
		for (j = 0; j < r; j++) {
			scanf ("%d", &a[i][j]);
		}
	}
	printf("Actual matrix \n");
	printf("--------------\n");
	for (i = 0; i < c; i++) {
		for (j = 0; j < r; j++) {
			printf ("%d\t", a[i][j]);
		}
		printf("\n");
	}
	printf("spiral print \n");
	printf("-------------\n");
	i = 0;
	j = 0;
	for (k =0; k < r-1; k++) {
		while (j < r-k) {
			printf ("%d ",a[i][j]);
			j++;
		}
		j--;
		i++;
		while (i < c-k) {
			printf ("%d ",a[i][j]);
			i++;
		}
		i--;
		j--;
		while (j >= k) {
			printf ("%d ",a[i][j]);
			j--;
		}
		j++;
		i--;
		while (i > k) {
			printf ("%d ",a[i][j]);
			i--;
		}
		i++;
		j++;
	}
	return 0;
}
