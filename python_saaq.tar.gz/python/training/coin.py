count = 0
number = int (input("Enter number of dinominations : "))
coin = [0 for i in range(1, number+1)]
din = [0 for i in range(1, number+1)]
print (coin)
print (din)

for j in range(number) :
	din[j] = int (input())
print (din)

amount = int(input("enter amount : "))
for k in range(number) :
	amount = amount // din[k]
	while (amount > 0) :
		print (amount // din[k])
		amount = amount // din[k]
		count = count + 1
	coin[k] = coin[k] + count
	count = 0
	if (amount < 0) :
		break
print (coin)
