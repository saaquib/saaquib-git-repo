num = int(input("Enter num : "))
print (num)
reference = num
reverse = 0
count = 0

#checking for prime
for i in range(1,num+1) :
	if num % i == 0 :
		count =count + 1
if count == 2 :
	print ("number is prime",end =' ')
else :
	print ("Number is not prime",end = ' ')

#checking palindrome
while (num > 0) :
	remainder = num % 10
	reverse = (reverse*10) + remainder
	num = num//10
if reverse ==  reference :
	print ("and it is palindrome")
else :
	print ("and it is not palindrome")

