#number of occurence of characters in a string
alphabet = [0 for i in range(1, 27)]

y = str(input ("enter string : "))
y = y.lower()
for i in y:
	if ((ord(i) >= 97) and (ord(i) <= 122)) :
		alphabet[ord(i) - 97] = alphabet[ord(i) - 97] + 1
for i in y :
	print (i,alphabet[ord(i) - 97])
