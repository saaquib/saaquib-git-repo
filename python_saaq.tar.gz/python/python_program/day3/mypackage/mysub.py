def mysub(num1, num2) :
	"return subtraction of num1 and num2"
	return (num1-num2)
