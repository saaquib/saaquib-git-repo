def mymul(num1, num2) :
	"return multiplication of num1 and num2"
	return (num1*num2)
