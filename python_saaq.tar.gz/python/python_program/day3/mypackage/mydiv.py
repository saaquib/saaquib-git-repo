def mydiv(num1, num2) :
	"return division of num1 by num2"
	return (num1/num2)
