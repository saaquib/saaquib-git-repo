def myadd(num1, num2) :
	"return addition of num1 and num2"
	return (num1+num2)
