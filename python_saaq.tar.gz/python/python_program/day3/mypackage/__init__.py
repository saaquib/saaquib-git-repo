from myadd import myadd
from mysub import mysub
from mymul import mymul
from mydiv import mydiv

