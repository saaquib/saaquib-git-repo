import xlrd, sys, os
fp = xlrd.open_workbook (sys.argv[1])
print fp.nsheets
index_sheet = fp.sheet_by_index(0)
print index_sheet.row_values(0)
