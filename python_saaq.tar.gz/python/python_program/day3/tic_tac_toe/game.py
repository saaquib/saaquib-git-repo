import operation, os
game = [['_','_','_'],['_','_','_'],['_','_','_']]
print "player 1 : enter 1"
print "player 2 : enter 0"

while True :
	operation.display (game)
#	option = raw_input ("Enter option : ") 
	option = 1
	print "player 1 enter position"
	while True :
		row, col  = input ("Enter row, column : ")
		if (game[row][col] == '_') :
			game[row][col] = option
			operation.check (game, option)
			operation.draw (game)
			break
		else :
			print ("invalid input")
	os.system('clear')
	operation.display (game)
	option = 0
	print "player 2 enter position"
	while True :
		row, col  = input ("Enter row, column : ")
		if (game[row][col] == '_') :
			game[row][col] = option
			operation.check (game, option)
			operation.draw (game)
			break
		else :
			print ("invalid input")
	os.system('clear')

