import os,sys
def check (lst, x) :
	for rele in range (3) :
		count = 0
		for cele in range (3) :
			if (lst[rele][cele] == x) :
				count += 1
			else : 
				break
		if (count == 3) :
			os.system('clear')
			display (lst)
			print "\'%d\' wins "%x
			exit (1) 
	for rele in range (3) :
		count = 0
		for cele in range (3) :
			if (lst[cele][rele] == x) :
				count += 1
			else : 
				break
		if (count == 3) :
			os.system('clear')
			display (lst)
			print "\'%d\' wins "%x
			exit (1) 
	count = 0
	for ele in range (3) :
		if (lst[ele][ele] == x) :
			count += 1
	if (count == 3) :
		os.system('clear')
		display (lst)
		print ("\'%d\' wins "%x)	
		exit (1)
	count = 0
	for rele in range (2, -1, -1) :
		if (lst[rele][2 - rele] == x) :
			count += 1
	if (count == 3) :
		os.system('clear')
		display (lst)
		print "\'%d\' wins"%x
		exit(1)
	return None

def display (lst) :
	for ele in lst :
		print ele[0],ele[1],ele[2] 

def draw (lst)	:
	count = 0 
	for rele in range(3) :
		for cele in range (3) :
			if (lst[rele][cele] == '_') :
				count += 1
	if (count == 0) :
		print "match draw"
		display (lst)
		exit (1)
	return None
