#!/usr/bin/python
#copy command
import sys,os
if (len (sys.argv[1:]) > 2) :
	print "more than two files are given as input"
elif (len (sys.argv[1:]) == 1) :
	print "destination file is needed"
elif (len (sys.argv[1:]) == 0) :
	print "input files are needed"
else :
	if (os.path.isfile (sys.argv[1]) == False ) :
		print "file does not exist"
		exit (1)
	else :
		fps = open (sys.argv[1], "r")
		buff = fps.read() 
		fpd = open (sys.argv[2], "w")
		fpd.write (buff)
		
