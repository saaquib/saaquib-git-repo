#!/usr/bin/python
#wc command
import sys,os
if (len (sys.argv[1:]) > 1) :
	print "more than one file is given as input"
elif (len (sys.argv[1:]) < 1) :
	print "no input is given"
else :
	if (os.path.isfile (sys.argv[1]) == False ) :
		print "file does not exist"
		exit (1)
	else :
		fp = open (sys.argv[1], "r")
		buf = fp.read() 
		print buf,"\n"
		char = list (buf)
		print "number of char : ", len(char)
		words = buf.split()
		print "number of  words : ",len(words)
		lines = buf.split('\n')
		print "number of lines : ",len(lines)


