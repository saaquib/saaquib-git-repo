#write and readback
import sys,os
if (len (sys.argv[1:]) > 1) :
	print "more than one files is given as input"
elif (len (sys.argv[1:]) == 0) :
	print "file is needed"
else :
	if (os.path.isfile (sys.argv[1]) == True ) :
		print "file already exist give other name"
	else :
		fps = open (sys.argv[1], "w+")
		buff = sys.argv[1]
		print "type $$$ to stop writing"
		while True :
			buff = raw_input ()  
			if ( buff == "$$$") :
				break
			fps.write (buff)
			fps.write ('\n')
		fps.seek(0,0)			
		print "your file is :"
		print fps.read()

		
