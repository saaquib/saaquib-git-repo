lst = [1, 2, 3, 4, 5, 6, 7, 8, 9]
print "a) print the whole list"
print lst
print "------------------------------"
print "b) print ele be ele using for"
for ele in lst :
	print ele,
print '\n'
print "------------------------------"

print "c) insert 30 at beg"
lst.insert(0, 30)
print lst
print "------------------------------"

print "d) insert 40 at pos 1"
lst.insert(1, 40)
print lst
print "------------------------------"

print "e) insert 50 at end"
lst.append(50)
print lst
print "------------------------------"

print "f) del ele at pos 1"
lst.pop(1)
print lst
print "------------------------------"

print "g) del ele at pos 1 and print del item"
lst.pop(1)
print lst
print "------------------------------"

print "h) del ele by value"
val = input("enter the value : ")
'''i = 0
for ele in lst :
	if ele == val :
		lst.pop(i)
		break
	else :
		i += 1
'''
lst.remove(val)
print lst
print "------------------------------"
print "i) print length of ele"
print len(lst)
