#!/usr/bin/python
while True :
	print "(1). check ><= 100\t(2). print 10 number\t(3). print 5 number\n(4). print 10 num excet 5\t(5). working day or not\t100. Exit"
	option = int (input("Enter option : "))
	#to check number is greater than or less than 100
	if option == 1 :
		num = int(input("enter the number : "))
		if num > 100 :
			print "greatr than 100"
			print '\n'
		elif num < 100 :
			print "less than 100"
			print '\n'
		else :
			print "equal to 100" 
			print '\n'
	#to print first 10 number
	elif option == 2 :
		a = 0
		while a < 10 :
			a = a + 1
			print a,
		print '\n'

	#to print 5 number with break
	elif option == 3 :
		a = 0
		while a < 10 :
			a += 1
			if a>5 :
				break
			print a,
		print'\n'

	#to print first 10 number except 5
	elif option == 4 :
		a = 0
		while a < 10 :
			a += 1
			if a==5 :
				continue
			print a,
		print '\n'
	#to check if today is working day or not
	elif option == 5 :
		day = raw_input("Enter the day : ") 
		if day == 'monday' or day == 'tuesday' or day == 'wednesday' or day == 'thursday' or day == 'friday' :
			print "go to office"
			print '\n'
		elif day == 'saturday' or day == 'sunday' : 
			print "holiday..."
			print '\n'
		else :
			print "enter correct day"
			print '\n'
	elif option == 100 :
		exit(1)
