number = input ("enter number : ")
x = [0, 1]
for i in range(number) :
	if (x[i] + x[i+1]) > number :
		break
	x.append(x[i] + x[i+1]) 
print x
