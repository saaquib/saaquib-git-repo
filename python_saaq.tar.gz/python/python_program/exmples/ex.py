# Python code to demonstrate working of 
# find() and rfind()
str1 = "saaquib podikar hussain podikar"
str2 = "podikar"
 
# using find() to find first occurrence of str2
# returns 8
print ("The first occurrence of str2 is at : ", )
print (str1.find( str2, 9) )
 
# using rfind() to find last occurrence of str2
# returns 21
print ("The last occurrence of str2 is at : ", )
print ( str1.rfind( str2, 0,23) )
