#calculator
import operations, sys, os, math
print 'CALCULATOR'.center(80,'-')
while True :
	os.system ('clear')
	print 'CALCULATOR'.center(80,'-')
	print ("1. SIMPLE\t2. SCIENTIFIC\t3. EXIT")
	option = input ("Enter option : ")
	if (option == 1) :
		os.system('clear')
		print 'SIMPLE'.center(80)
		while True :
			operation = input ("1. ADDITION\t\t2. SUBTRACTION\n3. MULTIPLICATION\t4. DIVISION\n5. CLEAR SCREEN\t\t6. GO BACK\noption : ")
			if (operation == 1) :
				num1, num2 = input ("Enter two  numbers : ")
				print "result : ", operations.myadd (num1, num2) 
				print "\n"
			elif (operation == 2) :
				num1, num2 = input ("Enter two  numbers : ")
				print "result : ", operations.mysub (num1, num2)
				print "\n"
			elif (operation == 3) :
				num1, num2 = input ("Enter two  numbers : ")
				print "result : ", operations.mymul (num1, num2) 
				print "\n"
			elif (operation == 4) :
				num1, num2 = input ("Enter two  numbers : ")
				print "result : ", operations.mydiv (num1, num2)
				print "\n"
			elif (operation == 5) :
				os.system ('clear')
			elif (operation == 6) :
				break
			else :
				print "invalid input"
	elif (option == 2) :
		print 'SCIENTIFIC'.center(80)
		os.system('clear')
		while True :
			operation = input ("1. SINE\t\t2. COSINE\t3. SQUARE ROOT\n4. POWER\t5. CLEAR SCREEN\t6. GO BACK\noperation : ")
			if (operation == 1) :
				in_option = input ("1. DEGREE\t2. RADIANS\noption : ") 
				angle = input ("Enter angle : ")
				if (in_option == 1) :
					print "sin%d : "%angle, operations.mysin(angle*math.pi/180)
					print "\n"
				elif (in_option == 2) :
					print "sin%d : "%angle, operations.mysin(angle)
					print "\n"
				else :
					print "invalid input"	
			elif (operation == 2) :
				in_option = input ("1. DEGREE\t2. RADIANS\noption : ") 
				angle = input ("Enter angle : ")
				if (in_option == 1) :
					print "cos%d : "%angle, operations.mycos (angle*math.pi/180)
					print "\n"
				elif (in_option == 2) :
					print "cos%d : "%angle, operations.mycos (angle) 
					print "\n"
				else :
					print "invalid input"	
			elif (operation == 3) :
				number = input ("enter the number : ")
				print "square root of %d : "%number, operations.mysqrt (number) 
				print "\n"
			elif (operation == 4) :
				number = input ("enter the number : ")
				power = input ("enter the power : ")
				print "%d^%d : "%(number, power), operations.mypower (number, power)
				print "\n"
			elif (operation == 5) :
				os.system ('clear')
			elif (operation == 6) :
				break
		
	elif (option == 3)	 :
			break
