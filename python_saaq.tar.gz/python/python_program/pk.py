import os, sys
sys.path.append("/home/saaquibh/python/python_program/day3")
from mypackage import myadd
print myadd(5, 6)
