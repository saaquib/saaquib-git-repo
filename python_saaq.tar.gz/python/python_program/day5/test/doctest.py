import doctest
def myAverage (a, b) :
	"""
	>>> myAverage (10, 30)
	20
	>>> myAverage (40, 60)
	5
	"""
	return (a+b)/2
doctest.testmod ()
