import unittest

def mymultiply (x, y) :
	return x*y

class TestStringMethods (unittest.TestCase) :
	def test_mymultiply_integers (self) :
		self.assertEqual (mymultiply (3, 4), 12)
	def test_mymultiply_strings (self) :
		self.assertEqual (mymultiply ('a', 2), 'aa')

if __name__ == '__main__' :
	unittest.main()
