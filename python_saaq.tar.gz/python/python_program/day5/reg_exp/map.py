items = [1, 2, 3, 4]
def sqr (x) :
	return x*x
def myadd (x, y) :
	return x+y
#returns the list of results in iterated manner
print "simple map : ",map (sqr, items)
#lambda keyword is used to create the function (similar to macro in c)
print "map with lambda : ",map (lambda x : x*x, items)

#filter is used to filter the result based on given conditions
print "simple filter : ",filter (lambda x:x>1, items)

#reduce is similar to recursion with result of current function is input to next   
print "reduce : ",reduce (lambda x, y:x*y, items,"saaquib")

