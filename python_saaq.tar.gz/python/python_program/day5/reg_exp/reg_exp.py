import re
str1 = "abc def abc"
print re.findall ("abc",str1)
print re.findall ("aBc",str1)
print re.findall ("aBc",str1,re.I) #re.I ignore
print re.sub ("abc","mno",str1) #re.sub --> substitute
#3 argument compusary...
#1. pattern to be find 2. to be replace 3. from 4. count 5. flag
print re.sub ("aBc","mno",str1,1,re.I) #re.sub --> substitute
