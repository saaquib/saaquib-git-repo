class Shape () :
	def __init__(self, x, y) :
		self.x = x
		self.y = y
	def area (self) :
		return self.x*self.y
	def perimeter (self) :
		return 2*self.x*self.y

myShape = Shape (20, 30)
print "area :",myShape.area ()
print  "perimeter :",myShape.perimeter ()
