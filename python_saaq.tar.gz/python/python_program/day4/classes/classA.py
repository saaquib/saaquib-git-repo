class A ():
	def __init__(self, a) :
#		self.x = input ("enter x in A : ")
		self.x = a
	def area (self) :
		self.aa = self.x 
		return (self.aa * self.aa)

	
