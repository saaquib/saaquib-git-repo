from shape import Shape
class Square (Shape) :
	def __init__(self, x) :
		Shape.__init__(self,x,x)
		self.x = x
		self.y = x
mySquare = Square (25)
print mySquare.area ()
print mySquare.perimeter ()
