class B ():
	def __init__(self, b) :
#		self.b = input ("enter y in B : ")
		self.b = b
	def perimeter (self) :	
		self.bb =self.b 
		return 4*self.bb

	
