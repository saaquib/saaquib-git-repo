class A :
	s = 25
	def __init__(self) :
		self.x = 10
		self._y = 20
		self.__z = 30
	def fn1 (self) :
		print "in fun1 :",self.x, self.s
		print "in fn1"
	def _fn2 (self) :
		self.__fn3()
		print "in fn2"
	def __fn3 (self) :
		print "in fn3"

m = A()
print "m.x :",m.x
print "m._y :",m._y
print m.s
#print "m.__z :",_A()__z
m.fn1()
m._fn2()
#m.__fn3()
print A().x

