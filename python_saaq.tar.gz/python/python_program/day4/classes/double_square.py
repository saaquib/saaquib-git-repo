from square import Square
class DoubleSquare (Square) :
	def __init__(self, z) :
		self.x = z
		self.y = 2*z
	def perimeter (self) :
		return 2*self.x + 3*self.y
mySquare = Square (45)
print mySquare.area ()
print mySquare.perimeter ()
