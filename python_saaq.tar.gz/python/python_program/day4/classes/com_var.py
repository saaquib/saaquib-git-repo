class Employee() :
	empcount = 0
	def __init__(self, sal):
		Employee.empcount += 1
		self.sal = sal 
	def displaycount (self) :
		print self.sal
		return Employee.empcount
emp1 = Employee (25000)
print emp1.displaycount ()
emp2 = Employee (35000)
print emp2.displaycount ()
print emp1.displaycount ()
