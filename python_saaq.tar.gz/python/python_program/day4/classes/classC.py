from classA import A
from classB import B
class C (A, B) :
	def __init__ (self, a, b) :
		A.__init__(self, a)
		B.__init__(self, b)
		self.z = self.x  + self.b
		print "in __init__"
a, b = input ("enter value for area and perimeter : " )
obj = C(a, b)
print "z : ",obj.z
print "area : ",obj.area ()
print "perimeter : ",obj.perimeter ()
