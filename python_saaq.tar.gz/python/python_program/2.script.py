#! /usr/bin/python
print "Happy scripting..."
