#include<stdio.h>
int main(void) {
printf("\n");
return 0 }
abcdefghijkl
