#include<stdio.h>
int main(void) {
printf("def\n");
return 0 }
#include<stdio.h>
hemanth
