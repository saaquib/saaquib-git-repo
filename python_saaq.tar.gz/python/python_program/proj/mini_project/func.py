import os, sys, datetime, shutil 
def check (str1, dest1) :
	if os.path.isdir(str1) :
		if not os.path.isdir(dest1) :
			shutil.copytree (str1, dest1)
		else :
			files = os.listdir (str1)
			for f in files :
				if os.path.isdir (os.path.join(str1,str (f))) :
					if not os.path.isdir (os.path.join(dest1,str (f))) :
						os.mkdir(os.path.join(dest1,str (f)))
					check (os.path.join(str1,str (f)), os.path.join(dest1,str (f)))
				else :
					if not os.path.isfile (dest1) :
						shutil.copy (os.path.join(str1,str (f)), os.path.join(dest1,str (f)))
					else : 
						if (os.path.getmtime(dest1) < os.path.getmtime(str1)):
							copy (str1, dest1)
					
	else :  
		if (os.path.getmtime(dest1) < os.path.getmtime(str1)):
			copy (str1, dest1)
