import os, datetime, shutil, func
import dirsync
from shutil import copytree, ignore_patterns
import time 
elapse_time = ""
def sample(source_path,dest_path):
	start_time = time.time()
        print "start_time",start_time
	files = os.listdir ('/home/test/smita/proj/pendrive')
	try :
		for f in files :
		#	source ='/home/test/smita/proj/pendrive/%s'%f
		#	dest ='/home/test/smita/proj/folder/%s'%f
			func.check (source_path, dest_path)
		elapse_time= str(time.time() -start_time)
		print "elapse_time",elapse_time		
		print "Copied successfully"
		
	except Exception as e :
		print e

def sync(source_path,dest_path):
	start_time = time.time()
        print "start_time",start_time

#	source ='/home/test/smita/proj/pendrive2'
#	dest ='/home/test/smita/proj/folder2'
	dirsync.sync(source_path,dest_path,'sync')
	elapse_time= time.time() -start_time
        print "elapse_time",elapse_time
	print "sync succesful"
