import os, datetime, shutil, func

from shutil import copytree, ignore_patterns

files = os.listdir ('/home/saaquibh/python/python_program/mini_project/pendrive')
print files
try :
	for f in files :
		source ='/home/saaquibh/python/python_program/mini_project/pendrive/%s'%f
		dest ='/home/saaquibh/python/python_program/mini_project/folder/%s'%f
		func.check (source, dest)		
except Exception as e :
	print e
