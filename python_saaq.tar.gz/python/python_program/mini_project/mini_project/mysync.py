import os
import sys
import datetime
import shutil 

def mysync (src, dst) :
	if os.path.isdir(src) :
		if not os.path.isdir(dst) :
			shutil.copytree (src, dst)
			
			print (src.split('/')[-1]),"directory is copied"
		else :
			dir_files = os.listdir (src)
			for element in dir_files :
				if os.path.isdir (os.path.join(src, str (element))) :
					if not os.path.isdir (os.path.join(dst, str (element))) :
						os.mkdir(os.path.join(dst,str (element)))
					mysync (os.path.join(src,str (element)), os.path.join(dst,str (element)))
				else :
					if not os.path.isfile (os.path.join(dst, str (element))) :
						shutil.copy (os.path.join(src,str (element)), os.path.join(dst, str (element)))
						print element,"is copied"
					else : 
						if (os.path.getmtime(os.path.join(dst, str (element))) < os.path.getmtime(os.path.join(src, str (element)))) :
							shutil.copy (os.path.join(src, str (element)), os.path.join(dst,str (element)))
							print element,"is copied"
	else :  
		if (os.path.getmtime(dst) < os.path.getmtime(src)):
			shutil.copy (src, dst)
			print (src.split('/')[-1]),"is copied"
