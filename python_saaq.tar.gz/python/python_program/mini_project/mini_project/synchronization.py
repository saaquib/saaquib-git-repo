import os
import datetime
import mysync
import shutil
from shutil import copytree
from shutil import  ignore_patterns

while True :
	src_path = raw_input ("Enter source path : ")
	if os.path.isdir (src_path) :
		break
	else :
		print "source path doesn't exist"
while True :
	dst_path = raw_input ("Enter destination path : ")
	if os.path.isdir(dst_path)  :
		break
	else :
		print "destination path doesn't exist"

media_files = os.listdir (src_path)

print "files in media : ",
for files in media_files :
	print files
print "\n"
try :
	for element in media_files :
		source = os.path.join (src_path, str (element))
		destination = os.path.join (dst_path, str (element))
		mysync.mysync (source, destination)		
except Exception as handle :
	print handle
