#personnel details as dictionary
s_detail = {'name' : 'saaquib', 'idn' : 30860, 'ph' : 9700742027}
v_detail = {'name' : 'venkat', 'idn' : 30861, 'ph' : 8600742027}
k_detail = {'name' : 'kasai', 'idn' : 30862, 'ph' : 7800742027}
#employment details
emp_details = {'saaquib' : s_detail, 'venkat' : v_detail, 'kasai' : k_detail}

print "employmen details "
for index in emp_details :
	print emp_details[index]
print "\n"

print "dictionary items"
print emp_details.items()
print "\n"

