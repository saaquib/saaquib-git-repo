#assignment1.txt

import os, sys, math
def myprime (num) :
	count = 0
	for ref in range (1, num) :
		if num % ref == 0 :
			count += 1
		if count > 1 :
			break
	if count == 1 :
		print ("number is prime")
	else :
		print ("number is not prime")

while True :
	print ("1. number system\t2. pi and sin90\n3. clear screen\t\t4. python version\n5. change directory\t6. command line argument\n7. prime number\t\t100. Exit")
	option = input ("enter option : ")

	if (option == 1) :
		number = input ("Enter the number in decimal form : ")
		print "binary :", bin(number)
		print "octal :", oct(number)
		print "hexa :", hex(number)
		print "\n"

	elif (option == 2) :
		print "value of pi :",math.pi
		print "value of sin 90 :",math.sin(90*math.pi/180)
		print "\n"
	elif (option == 3) :
		os.system('clear')
	elif (option == 4) :
		print "version is : "
		print sys.version
		print "\n"
	elif (option == 5) :
		path = raw_input("Enter path : ")
		print "before : ",os.getcwd()
		os.chdir(path)
		print "after :",os.getcwd()
	elif (option == 6) :
		mysum = 0
		for ele in sys.argv[1:] :
			mysum += int (ele)
		print "result : %d"%mysum
		print "\n"
	elif (option == 7) :
		number = input ("Enter number to be checked : ")
		myprime (number)
		print ("\n")
	elif (option == 100) :
		exit(1)

