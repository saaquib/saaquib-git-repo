lst = [1,2,3,4,5]
dic = {"saa":"hu","tring":"trong"}
def func (l_lst) :
#	l_lst[1] = 4
	l_lst['saa'] = "huss"
	return l_lst
print dic
func (dic)
print dic
