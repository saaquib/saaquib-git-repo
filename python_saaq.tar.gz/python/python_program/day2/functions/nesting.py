def outside (number) :
	print "IN outside before calling inside(): ",number 

	def inside (number) :
		print "IN inside before modifying : ",number
		global num
		num = number
		print "IN inside after modifying : ",num
		return number

	return_inside = inside (20)
	print "return_inside : ",return_inside
	print "IN outside after calling inside(): ",number 
	return number 

num = input ("enter number : ")	
print "IN main before calling outside(): ",num
return_outside = outside (num) 
print "return_inside : ",return_outside
print "IN main after calling outside(): ",num


		
