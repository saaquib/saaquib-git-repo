#finding factorial 
def myfact (num) :
	if num > 0 :
		return num * myfact (num-1)
	else :
		return 1
option = 'y'
while True :
	if option == 'y' : 
		number = input ("Enter number : ")
		print "factorial of %d is : "%number, myfact(number)
	elif option == 'n' :
		break
	else :
		print "enter 'y' for yes and 'n' for no"
	option = raw_input ("continue ? y/n : ")
