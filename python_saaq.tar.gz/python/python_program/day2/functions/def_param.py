#functions in python

def type1 (a1, b1) :
	"type1 function"
	print ("in function : ",a1, b1)
	return (a1, b1)
def type2 (a2 = 10, b2=20) :
	"type2 function"
	print ("in function : ",a2, b2)
	return (a2, b2)
def type3 (a3, b3 = 20) :
	"type3 function"
	print ("in function : ",a3, b3)
	return (a3, b3)

ret = type1(11,12)
print ret
print ("--------------")
print type2(21,22)
ret2 = type2(21)
print ret2
ret2 = type2(b2=22)
print ret2
print ("--------------")

print type3(31,32)
ret3 = type3(31)
print ret3
ret3 = type3(a3=31)
print ret3
