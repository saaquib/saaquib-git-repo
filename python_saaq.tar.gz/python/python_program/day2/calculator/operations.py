#myadd(), mysub(), mymul(), mydiv(), mysin(), mycos(), mysqrt(), mypower()
import os,sys,math
def myadd (num1, num2) :
	"adds two number num1, num2 and return result"
	return (num1 + num2)

def mysub (num1, num2) :
	"subtracts two number num1, num2 and return result"
	return (num1 - num2)

def mymul (num1, num2) :
	"multiply two number num1, num2 and return result"
	return (num1 * num2)

def mydiv (num1, num2) :
	"divide number num1 by num2 and return result"
	try :
		return (num1 / num2)
	except ZeroDivisionError :
		print "num2 should not be zero"

def mysin (angle) :
	"returns sine of angle"
	return math.sin(angle)

def mycos (angle) :
	"returns cosine of angle"
	return math.sin(angle)

def mysqrt (number) :
	"return square root value of number"
	return math.sqrt(number) 

def mypower (number, power) :
	"returns 'number' to the power of 'power'"
	return math.pow(number, power) 
