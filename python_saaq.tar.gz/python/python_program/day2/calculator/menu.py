#calculator
import operations, sys, os, math
print 'CALCULATOR'.center(80,'-')
while True :
	os.system ('clear')
	print 'CALCULATOR'.center(80,'-')
	print ("1. SIMPLE\t2. SCIENTIFIC\t3. EXIT")
	while True :
		try :
			option = input ("Enter option : ")
			break
		except NameError :
			print "NameError : expected int option"
		except ValueError :
			print "ValueError : please enter correct option"
	if (option == 1) :
		os.system('clear')
		print 'SIMPLE'.center(80)
		while True :
			try :
				operation = input ("1. ADDITION\t\t2. SUBTRACTION\n3. MULTIPLICATION\t4. DIVISION\n5. CLEAR SCREEN\t\t6. GO BACK\noption : ")
				break
			except NameError :
				print "NameError : expected int option"
			except ValueError :
				print "ValueError : please enter correct option"
		print operation	
		if (operation == 1) :
			while True :
				try :
					num1, num2 = input ("Enter two  numbers : ")
					break
				except NameError :
					print "NameError : expected int option"
				except ValueError :
					print "ValueError : please enter correct option"
				except TypeError :
					print "TypeError : please enter 2 option separated by ,"
				print num1,num2
				print "result : ", operations.myadd (num1, num2) 
				print "\n"
		elif (operation == 2) :
			while True :
				try :
					num1, num2 = input ("Enter two  numbers : ")
					break
				except NameError :
					print "NameError : expected int option"
				except ValueError :
					print "ValueError : please enter correct option"
				except TypeError :
					print "TypeError : please enter 2 option separated by ,"
			print "result : ", operations.mysub (num1, num2)
			print "\n"
		elif (operation == 3) :
			while True :
				try :
					num1, num2 = input ("Enter two  numbers : ")
					break
				except NameError :
					print "NameError : expected int option"
				except ValueError :
					print "ValueError : please enter correct option"
				except TypeError :
					print "TypeError : please enter 2 option separated by ,"
			print "result : ", operations.mymul (num1, num2) 
			print "\n"
		elif (operation == 4) :
			while True :
				try :
					num1, num2 = input ("Enter two  numbers : ")
					break
				except NameError :
					print "NameError : expected int option"
				except ValueError :
					print "ValueError : please enter correct option"
				except TypeError :
					print "TypeError : please enter 2 option separated by ,"
			print "result : ", operations.mydiv ((num1*1.0), (num2*1.0))
			print "\n"
		elif (operation == 5) :
			os.system ('clear')
		elif (operation == 6) :
			break
		else :
			print "invalid input"
	elif (option == 2) :
		print 'SCIENTIFIC'.center(80)
		os.system('clear')
		while True :
			while True :
				try :
					operation = input ("1. SINE\t\t2. COSINE\t3. SQUARE ROOT\n4. POWER\t5. CLEAR SCREEN\t6. GO BACK\noperation : ")
					break
				except NameError :
					print "NameError : expected int option"
				except ValueError :
					print "ValueError : please enter correct option"
				
			if (operation == 1) :
				while True :
					try :
						in_option = input ("1. DEGREE\t2. RADIANS\noption : ") 
						break
					except NameError :
						print "NameError : expected int option"
					except ValueError :
						print "ValueError : please enter correct option"
				while True :
					try :
						angle = input ("Enter angle : ")
						break
					except NameError :
						print "NameError : expected int option"
					except ValueError :
						print "ValueError : please enter correct option"
					
				if (in_option == 1) :
					print "sin%d : "%angle, operations.mysin(angle*math.pi/180)
					print "\n"
				elif (in_option == 2) :
					print "sin%d : "%angle, operations.mysin(angle)
					print "\n"
				else :
					print "invalid input"	
			elif (operation == 2) :
				while True :
					try :
						in_option = input ("1. DEGREE\t2. RADIANS\noption : ") 
						break
					except NameError :
						print "NameError : expected int option"
					except ValueError :
						print "ValueError : please enter correct option"
				while True :
					try :
						angle = input ("Enter angle : ")
						break
					except NameError :
						print "NameError : expected int option"
					except ValueError :
						print "ValueError : please enter correct option"
					
				if (in_option == 1) :
					print "cos%d : "%angle, operations.mycos (angle*math.pi/180)
					print "\n"
				elif (in_option == 2) :
					print "cos%d : "%angle, operations.mycos (angle) 
					print "\n"
				else :
					print "invalid input"	
			elif (operation == 3) :
				while True :
					try :
						number = input ("enter the number : ")
						break
					except NameError :
						print "NameError : expected int option"
					except ValueError :
						print "ValueError : please enter correct option"
					
				print "square root of %d : "%number, operations.mysqrt (number) 
				print "\n"
			elif (operation == 4) :
				while True :
					try :
						number = input ("enter the number : ")
						break
					except NameError :
						print "NameError : expected int option"
					except ValueError :
						print "ValueError : please enter correct option"
				while True :		
					try :
						power = input ("enter the power : ")
						break
					except NameError :
						print "NameError : expected int option"
					except ValueError :
						print "ValueError : please enter correct option"

				print "%d^%d : "%(number, power), operations.mypower (number, power)
				print "\n"
			elif (operation == 5) :
				os.system ('clear')
			elif (operation == 6) :
				break
		
	elif (option == 3)	 :
			break
