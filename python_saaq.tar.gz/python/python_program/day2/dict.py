emp1_details = {}
emp2_details = {}
while True :
	print "1. Insert\t2. Delete\t3. Display\t100. Exit"
	option = input ("Enter the option : ")

	if (option == 1) :
		name = raw_input ("enter name : ")
	
		identity = input ("enter idn : ")
		emp2_details['idn'] = identity
		phone = input ("enter phn number : ")
		emp2_details['phn'] = phone
		emp1_details[name] = emp2_details

	elif (option == 2) :
		name = raw_input ("Enter name to be deleted : ")
		del (emp1_details[name])
	elif (option == 3) :
		for index in emp1_details :
			print "name :",index
			print "id :",emp2_details['idn']
			print "phone :",emp2_details['phn']
			print "-----------------------------"

	elif (option == 100) :
		exit(1)
