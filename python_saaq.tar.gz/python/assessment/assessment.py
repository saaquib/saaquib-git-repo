#26.
if (0) :
	silly = "newlyformed bland ideas are inexpensible in an infuriating way"    
	bland = silly.split()
	print bland
	second = ''
	for ele in bland:
		second = second + ele[1]
	print second
	jn = ' '.join(bland)
	for ele in sorted(bland) :
		print ele
#--------------------------------------------------------
#25.
if (0) :
	lst = ['After','all','how','why','']
	length = []
	for ele in lst :
		length.append(len(ele))
	print length
#--------------------------------------------------------
#22.
if (0) :
	import test
	print test.monty
	from test import monty
	print monty
#---------------------------------------------------------
#21.
if (0) :
	words = ['mama','kasai','saaquib']
	srtd = sorted (words)
#sorted will not modify the source
	print srtd
	print words
	srt = words.sort()
#words.sort will return none and modifies the source
	print srt
	print words
#---------------------------------------------------------
#20.
if (0) :
	import urllib
	fp = urllib.urlopen (raw_input ("enter url : "))
	print fp.read()
#---------------------------------------------------------
#19.
if (0) :
	import re
	str1 = "India is a the an or that"
#--------------------------------------------------------
#18.
#-------------------------------------------------------
#17.
if (0) :
	s = 'colorless'
	res = s[:4]+'u'+s[4:]
	print res
#-------------------------------------------------------
#16. 
if (0) :
	s1 = "abcdef"
	t1 = "ab"
	print "is s1 subset of t1 : ",(set(s1) > set(t1))
#---------------------------------------------------------
#15.
if (0) :
	def percent (word, text) :
		length = len (text.split())
		return text.count (word)*100/length
	test = "mama, kasai, saaquib, saaquib, mama, mama"
	print "mama : ",percent ('mama',test)
#---------------------------------------------------------
#14.
if (0) :
	import enchant
	eng_dict = enchant.Dict ('en_US')
	def vocab_size (test) :
		count = 0
		lst_test = test.split()
		for ele in lst_test :
			if eng_dict.check(ele) :
				print ele,
				count += 1
		return count
	test = "kasai and mama is a global edge employee"
	print "vocab_size : ", vocab_size (test)
	
#---------------------------------------------------------
#13.
if (0) :
	text1 = "mama saaquib kasai venkat"
	res = sum ([len(w) for w in text1.split()])
	avg = res/len(text1.split())
	print "number of letters : ",res,"\n","average word length : ",avg
#---------------------------------------------------------
#12.
if (1) :
	lst = ['she', 'shells','sea', 'by', 'the','sea','shore']
	for w in lst:
		if w.startswith('sh'):
			print w
	for w in lst:
		if(len(w) >  4):
			print w
#---------------------------------------------------------
#11.
if (0) :
	lst = ['size','price','zebra','adopt','apt', 'pt']
	print lst
	l = []
	z = []
	print "Ending in ize"
	for w in lst:
	    if w.endswith('ize'):
			l.append(w)
	print l
	print "containing the letter z"
	for w in lst:
	    if 'z' in w:
			z.append(w)
	print z
	print "containing the sequence of letters pt"
	for w in lst :
		if 'pt' in w:
			print w
	print "title case"
	for w in lst:
		if w.istitle():
			print w
	import re
	lst = "size price Preethi zebra Ppt ptpt pttttt ize izy"
	print "ending with ize :", re.findall('[a-zA-Z]*ize', lst)
	print "containing the letter z", re.findall('[a-zA-Z]*z+[a-zA-Z]*', lst)    
	print "containing the sequence of pt", re.findall('[a-zA-Z]*pt+[a-zA-Z]*',lst)
	print "titlecase", re.findall('[A-Z][a-z]*',lst)
#---------------------------------------------------------
#10.
if (0) :
	t = "mama kasai venkat saaquib"
	print t.split()[-2:]
#---------------------------------------------------------
#9.
if (0) :
	pass
#---------------------------------------------------------
#8.
if (0) :
	pass
#	in case'b' number of elements will be more because,
#	in case b set(text1) will take 'a' and 'A' separately and then it will convert into lower case.. so that 'a' will be twice
#   but in case 'a' first 'a' and 'A' will be taken separately and 'A' will be changed to 'a' so that when we perform set() only one 'a' will be taken
#---------------------------------------------------------
#7.
if (0) :
	pass
#len(phrase1) + len(phrase2) = len(phrase1+phrase2)
#---------------------------------------------------------
#6.
if (1) :
	my_sent = ["My","sent"]
	y = ' '.join(my_sent)
	print y
	print y.split()
#---------------------------------------------------------
#5.
if (0) :
	s = "saaquib"
	print s
	s =  s+s
	print s
	s = "saaquib"
	s = s+' ' + s
	print s
	s = 'saaquib'
	s = s*3
	print s
	s = "saaquib"
	print (s + " ") *3
#---------------------------------------------------------
#4.
if (0) :
	pass
#	to find number of different elements used in text4
#	two operations:
#       set--> which gives different elements of text4
#       len--> number of elements in set(text4)
#---------------------------------------------------------
#3.
if (0) :
	print ["month" "python"] #print the list  20 time
	print 3*"saaquib"  #saaquib is printed 3 times
#---------------------------------------------------------
#2.
if (0) :
	print 26 ** 10
	print 26 **100
#---------------------------------------------------------
#1.
if (0) :                                    
	print 12/(4+1) #gives integer value as output
