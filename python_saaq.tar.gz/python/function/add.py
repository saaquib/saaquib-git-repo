def add (num1, num2) :
	'''addition function '''
	return num1+num2

num1 = input ("Enter first number : ")
num2 = input ("Enter second number : ")

result = add (num1, num2)

print "result : ",
print result
