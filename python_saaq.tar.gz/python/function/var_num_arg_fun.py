def add (var, *arg) :
    '''variable length arguments '''
	l=len(var)
	for i in range(l)) :
		res = res + var[i]
    return res
num = input ("enter number of arguments : ") 
var = []
for loop in range(num) :
	var[i] = input ("Enter number : ")

result = add (var)

print "result : ",
print result

