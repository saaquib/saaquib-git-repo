fp = open ('text1.txt', 'r')
line = fp.readline()
print (line)
line = line.split()
print (line)
while not (line == '') :
	line = fp.readline()
	print (line)
	line = line.split()
	print (line)
	add = 0
	for i in line :
		add = add + int(i)
	print (add)
		
