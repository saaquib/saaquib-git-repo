class Nature :
	def __init__(nat, category, types, name) :
		nat.cat = category
		nat.typ = types
		nat.nam = name
	
	def about(nat) :
		print "given input is a", nat.cat, "of type", nat.typ, "whose name is", nat.nam

	def walk(nat) :
		print nat.nam,"can walk..."

	def talk(nat) :
		print nat.nam,"can talk..."

	def sleep(nat) :
		print nat.nam,"can sleep..."
option = 1
while option :
	category = input ("Enter category : ")
	types = input ("Enter type : ")
	name = input ("Enter name : ")

	nature = Nature (category, types, name)
	nature.about()
	nature.walk()
	nature.talk()
	nature.sleep()
	more = input ("Do you want to enter new category (y/n) : ")
	if (more == 'n') :
		break


		
