import nature

nature2 = nature.Nature ("animal2","tiger","sharu")
nature2.walk()

