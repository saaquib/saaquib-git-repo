#wc command
import sys,os,re
if (len (sys.argv[1:]) > 1) :
	print "more than one file is given as input"
elif (len (sys.argv[1:]) < 1) :
	print "no input is given"
else :
	if (os.path.isfile (sys.argv[1]) == False ) :
		print "file does not exist"
		exit (1)
	else :
		fp = open (sys.argv[1], "r")
		buf = fp.read() 
		print buf,"\n"
		char = (re.findall('[a-zA-Z0-9]+',buf))
		print "number of char :",len(''.join(char))
		words = re.findall('[^,:\n ]+',buf)
		print words,"number of  words : ",len(words)+char.count(',')+char.count(':') 
		lines = buf.split('\n')
		print "number of lines : ",len(lines)-1


