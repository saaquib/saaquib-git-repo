def f1 (*p, **k) :
	print p[0]
	print k['a']

f1 (1,6,a=20)
