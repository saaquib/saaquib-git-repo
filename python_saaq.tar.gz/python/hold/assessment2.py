#1.)------------------------------------
if (1) :
	print "1."
	var1 = "5"
	print "var1 value is"+var1
# the above print statement works only if var1 is a string...
	
	var1 = 5;
	print "var1 value is",var1
# the above print statement works fine ...

#2.)------------------------------------
if (1) :
	print "2."
	a =1/0
	print a

#3.)------------------------------------
if (1) :
	print "3."
	t1 = (1, 2 ,3)
	print t1
	t2 = tuple(x for x in range (3))
	print t2

#4.)------------------------------------
if (1) :
	print "4."
	lst2 = [1, 2]
	lst1=[10,20,30]
	tup1=(40,50)
	print lst1.append(lst2) #append adds the lst2 as a single element to lst1
	print lst1
	print lst1.extend(lst2) #extends adds each element of lst2 as individual element of lst1
	print lst1
#5.)------------------------------------
if (1) :
	print "5."
#indentation error
	print "Global"
#		print "edge"

#6.)------------------------------------
if (1) :
	print "6."
	import os
	if (os.name == 'posix') :
		os.system ('mv x y')
	else :
		os.system ('rename x y')

#8.)------------------------------------
if (1) :
	print "8."
	lst1 = [10, 'Hi','20']
	for i in range(3) :
		print "lst1[%d] = "%i,lst1[i]
#9.)------------------------------------
if (1) :
	print "9."
#	import os
#	print dir(__builtins__)
	print "help","dir","type"

