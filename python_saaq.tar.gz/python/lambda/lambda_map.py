def number (x) :
	return x
def square(x):
	return (x**2)
def cube(x):
	return (x**3)

funcs = [number, square, cube]
for r in range(5):
    value = list(map(lambda x: x(r), funcs))
    print (value)
