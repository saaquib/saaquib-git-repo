def add (num1, num2) :
	return num1+num2
def sub (num1, num2) :
	return num1-num2
def mul (num1, num2) :
	return num1*num2
def div (num1, num2) :
	return num1/num2
while True :
	print ("1.add\t2.sub\t3.mul\t4.div\t5.exit")
	option = int(input("enter option : "))
	if option == 5 :
		exit(0)
	num1 = int(input("enter num1 : "))
	num2 = int(input("enter num2 : "))
	result = lambda x : (x==1 and add(num1, num2)) \
						or (x==2 and sub(num1, num2)) \
						or (x==3 and mul(num1, num2)) \
						or (x==4 and div(num1, num2))
	print ("result",result(option))
					
