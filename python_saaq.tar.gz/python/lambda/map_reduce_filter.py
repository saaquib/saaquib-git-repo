def tring (n1) :
	return (n1**2)%3
def tringtrong (n1, n2) :
	return n1+n2
l1 = [ele for ele in range(15) if ele % 2 == 0]
l2 = [ele*ele for ele in l1]
l3 = [ele**3 for ele in l1]
print ("l1 : ",l1)
print ("l2 : ",l2)
print ("l3 : ",l3)

mapped_l1 = list(map (tring,l1))
reduced_l2 = reduce(tringtrong, l2)
filtered_l3 = list(filter (tring, l3))
print ("mapped :", mapped_l1)
print ("reduced :", reduced_l2)
print ("filtered :", filtered_l3)
