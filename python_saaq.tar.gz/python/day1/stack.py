stack = []
while True :
	option = input ("enter option \n1. PUSH\t2. POP\t3. DISPLAY\t4. EXIT\n")
	if (option == 1) :
#		length = (len (stack)) - 1 
		push = input ("Enter value to be pushed : ")
#		stack.insert (length, push)
		stack.append (push)
	elif (option == 2) :
		stack.pop ()
	elif (option == 3) :
		print stack
	elif (option == 4) :
		break

