x = input ("enter x value : ")
print x
y = input ("enter y value : ")
print y
print "result : "
print x + y



