from glob import glob

files = glob("*.py") 
print files

for loop in files :
	with open (loop, 'r') as fp :
		read_data = fp.read ()
		print read_data
		print "----------------------------------------------"	
