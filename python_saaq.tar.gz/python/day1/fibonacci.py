z = 0
x=0
y=1
limit = input ("enter range : ")
while z<limit:
	print z,
	z = y+x
	if z==1:
		print 1,
	x = y 
	y = z
