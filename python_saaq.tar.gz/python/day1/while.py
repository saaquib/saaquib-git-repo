print "welcome to string's index"
i =0;
s = raw_input("Enter string : ")
a = raw_input("Enter char : ")
while s[i]!=a[0] :
	i+=1
print s[i],"is in position",i
